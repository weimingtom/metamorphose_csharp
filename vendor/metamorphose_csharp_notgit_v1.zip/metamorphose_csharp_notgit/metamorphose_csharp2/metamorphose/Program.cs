﻿using System;
using System.Windows.Forms;

namespace metamorphose
{
    static class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Form form1 = new Form();
            form1.Text = "hello";
            Application.Run(form1);
        }
    }
}
