﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Diagnostics import *
from metamorphose.lua import *

class Test001(object):
	def __init__(self):
		test001 = "n = 99 + (1 * 10) / 2 - 0.5;\n" + "if n > 10 then return 'Oh, 真的比10还大哦:'..n end\n" + "return n\n"
		test002 = "return _VERSION"
		test003 = "return nil"
		isLoadLib = True
		try:
			System.Diagnostics.Debug.WriteLine("Start test...")
			L = Lua()
			if isLoadLib:
				BaseLib.open(L)
				PackageLib.open(L)
				MathLib.open(L)
				OSLib.open(L)
				StringLib.open(L)
				TableLib.open(L)
			status = L.doString(test002)
			if status != 0:
				errObj = L.value(1)
				tostring = L.getGlobal("tostring")
				L.push(tostring)
				L.push(errObj)
				L.call(1, 1)
				errObjStr = L.toString(L.value(-1))
				raise Exception("Error compiling : " + L.value(1))
			else:
				result = L.value(1)
				tostring_ = L.getGlobal("tostring")
				L.push(tostring_)
				L.push(result)
				L.call(1, 1)
				resultStr = L.toString(L.value(-1))
				System.Diagnostics.Debug.WriteLine("Result >>> " + resultStr)
		except Exception, e:
			System.Diagnostics.Debug.WriteLine(e.StackTrace)
		finally:
			pass