﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class SystemUtil(object):
	def __init__(self):
		self._Out = PrintStream()

	def arraycopy(src, srcPos, dest, destPos, length):
		if src != None and dest != None and  isinstance(src, array) and isinstance(dest, array):
			i = destPos
			while i < destPos + length:
				(dest)[i] = (src)[i]
				i += 1

	arraycopy = staticmethod(arraycopy)

	#trace("arraycopy:", i, (src as Array)[i]); 
	def gc():
		pass

	gc = staticmethod(gc)

	def identityHashCode(obj):
		return 0

	identityHashCode = staticmethod(identityHashCode)

	def getResourceAsStream(s):
		return None

	getResourceAsStream = staticmethod(getResourceAsStream)

	def currentTimeMillis():
		return 0

	currentTimeMillis = staticmethod(currentTimeMillis)

	def getenv(name):
		return None

	getenv = staticmethod(getenv)