﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Diagnostics import *
# *
# *
# * 此抽象类是表示字节输入流的所有类的超类。
# * 需要定义 InputStream 的子类的应用程序
# * 必须始终提供返回下一个输入字节的方法。
# *
# 
class InputStream(object):
	def __init__(self):
		pass
	def read(self, bytes):
		self.throwError("InputStream.readBytes() not implement")
		return 0

	#从输入流读取下一个数据字节。
	def read(self):
		self.throwError("InputStream.readChar() not implement")
		return 0

	def reset(self):
		self.throwError("InputStream.reset() not implement")

	def mark(self, i):
		self.throwError("InputStream.mark() not implement")

	def markSupported(self):
		self.throwError("InputStream.markSupported() not implement")
		return False

	def close(self):
		self.throwError("InputStream.close() not implement")

	def available(self):
		self.throwError("InputStream.available() not implement")
		return 0

	def skip(self, n):
		self.throwError("InputStream.skip() not implement")
		return 0

	def read(self, bytes, off, len):
		self.throwError("InputStream.readBytes() not implement")
		return 0

	def throwError(self, str):
		Debug.WriteLine(str)
		raise Exception(str)