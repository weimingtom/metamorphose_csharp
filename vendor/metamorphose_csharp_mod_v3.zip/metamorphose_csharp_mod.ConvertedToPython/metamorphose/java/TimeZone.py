﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class TimeZone(object):
	def __init__(self):
		self._tz = TimeZone()
		self._tzGMT = TimeZone()

	def getDefault():
		if self._tz._id == None:
			self._tz._id = "default"
		return self._tz

	getDefault = staticmethod(getDefault)

	def getTimeZone(ID):
		return None

	getTimeZone = staticmethod(getTimeZone)

	def useDaylightTime(self):
		return True

	def getID(self):
		return None