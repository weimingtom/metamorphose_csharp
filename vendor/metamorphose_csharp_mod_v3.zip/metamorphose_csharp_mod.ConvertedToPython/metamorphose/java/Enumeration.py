﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class Enumeration(object):
	def hasMoreElements(self):
		pass

	def nextElement(self):
		pass