﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Diagnostics import *

class Runtime(object):
	def __init__(self):
		self.__instance = Runtime()

	def getRuntime():
		return Runtime._instance

	getRuntime = staticmethod(getRuntime)

	def totalMemory(self):
		#return flash.system.System.totalMemory;
		return 0

	def freeMemory(self):
		Debug.WriteLine("Runtime.freeMemory() not implement")
		return 0