﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Diagnostics import *

class Calendar(object):
	def __init__(self):
		self._SECOND = 1
		self._MINUTE = 2
		self._HOUR = 3
		self._DAY_OF_MONTH = 4
		self._MONTH = 5
		self._YEAR = 6
		self._DAY_OF_WEEK = 7
		self._SUNDAY = 8
		self._MONDAY = 9
		self._TUESDAY = 10
		self._WEDNESDAY = 11
		self._THURSDAY = 12
		self._FRIDAY = 13
		self._SATURDAY = 14
		self._JANUARY = 15
		self._FEBRUARY = 16
		self._MARCH = 17
		self._APRIL = 18
		self._MAY = 19
		self._JUNE = 20
		self._JULY = 21
		self._AUGUST = 22
		self._SEPTEMBER = 23
		self._OCTOBER = 24
		self._NOVEMBER = 25
		self._DECEMBER = 26
		self.__instance = Calendar()

	def _get(self, field):
		if field == self._SECOND:
			return self.__date.Second
		elif field == self._MINUTE:
			return self.__date.Minute
		elif field == self._HOUR:
			return self.__date.Hour
		elif field == self._MONTH:
			return self.__date.Month
		elif field == self._YEAR:
			return self.__date.Year
		elif field == self._DAY_OF_WEEK:
			Debug.WriteLine("DAY_OF_WEEK not implement")
			return 0
		elif field == self._DAY_OF_MONTH:
			return self.__date.Day
		Debug.WriteLine("Calendar._get(): field not implement")
		return 0

	def _set(self, field, value):
		#FIXME:
		Debug.WriteLine("Calendar._set(): field not implement")

	def getInstance(t):
		return Calendar._instance

	getInstance = staticmethod(getInstance)

	def setTime(self, d):
		self.__date = d

	def getTime(self):
		return self.__date