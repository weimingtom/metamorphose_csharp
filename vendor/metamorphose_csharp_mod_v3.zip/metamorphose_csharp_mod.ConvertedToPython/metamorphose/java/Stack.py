﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Collections import *
# *
# * Stack 类表示后进先出（LIFO）的对象堆栈。
# * 它通过五个操作对类 Vector 进行了扩展 ，
# * 允许将向量视为堆栈。
# * 它提供了通常的 push 和 pop 操作，
# * 以及取栈顶点的 peek 方法、
# * 测试堆栈是否为空的 empty 方法、
# * 在堆栈中查找项并确定到栈顶距离的 search 方法。
# * 首次创建堆栈时，它不包含数据项。
# *
# * 在Java中Stack继承Vector，需要注意转换问题。
# 
class Stack(object):
	def __init__(self):
		self.__arr = ArrayList()

	# *
	# *  相当于push
	# 
	def addElement(self, o):
		self.__arr.Add(o)
		return o

	def lastElement(self):
		len = self.__arr.Count
		if len > 0:
			#trace("lastElement:", this._arr[len - 1]);
			return self.__arr[len - 1]
		return None

	def getSize(self):
		return self.__arr.Count

	# *
	# * 设置此向量的大小。
	# * ]如果新大小大于当前大小，则会在向量的末尾添加相应数量的 null 项。
	# * 如果新大小小于当前大小，
	# * 则丢弃索引 newSize 处及其之后的所有项。
	# 
	#TODO:
	def setSize(self, size):
		len = self.__arr.Count
		if size >= 0:
			if size > len:
				i = 0
				while i < size - len:
					#this._arr.push(new Object());
					self.__arr.Add(None)
					i += 1
			else:
				i = 0
				while i < len - size:
					self.__arr.RemoveAt(self.__arr.Count - 1)
					i += 1

	def pop(self):
		obj = self.__arr[self.__arr.Count - 1]
		self.__arr.RemoveAt(self.__arr.Count - 1)
		return obj

	def elementAt(self, i):
		obj = self.__arr[i]
		return obj