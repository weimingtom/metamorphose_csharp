﻿from System import *
from System.Collections.Generic import *
from System.Text import *
# *
# * 数据输出流允许应用程序以适当方式将基本 Java 数据类型写入输出流中。
# * 然后，应用程序可以使用数据输入流将数据读入。
# *
# * 封装构造函数中的OutputStream，而这个类的特点是统计了写入字节数。
# * 实现这个类，基本上只用writeByte处理
# 
class DataOutputStream(object):
	def __init__(self, writer):
		pass
	def flush(self):
		pass

	def write(self, b, off, len):
		pass

	def writeInt(self, v):
		pass

	def writeDouble(self, v):
		pass

	def writeByte(self, v):
		pass

	def writeBoolean(self, v):
		pass