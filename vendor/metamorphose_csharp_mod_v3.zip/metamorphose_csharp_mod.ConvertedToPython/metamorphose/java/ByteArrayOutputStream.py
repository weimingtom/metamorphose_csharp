﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class ByteArrayOutputStream(OutputStream):
	def __init__(self):
		self.__bytes = ByteArray()

	def toByteArray(self):
		return self.__bytes

	def close(self):
		self.__bytes.clear()

	def flush(self):
		pass

	def write(self, b):
		self.__bytes.writeBytes(b)

	def writeBytes(self, b, off, len):
		self.__bytes.writeBytes(b, off, len)

	#TODO: 这个方法有待修改
	#Writes a char to the underlying output stream as a 2-byte value, high byte first
	def writeChar(self, b):
		bytes = ByteArray()
		bytes.writeMultiByte("" + b, "")
		self.__bytes.writeBytes(bytes)