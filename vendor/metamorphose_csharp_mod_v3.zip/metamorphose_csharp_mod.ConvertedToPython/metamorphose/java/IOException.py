﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class IOException(Exception):
	def __init__(self, str):
		pass
	def __init__(self, str):
		pass