﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Collections import *

class Hashtable(object):
	#Dictionary支持用Object作为键，而Array会对键进行toString的转换
	def __init__(self, initialCapacity):
		self.__dic = Dictionary[Object, Object]()

	def rehash(self):
		pass

	def keys(self):
		enum_ = HashtableEnum()
		arr = Array.CreateInstance(Object, self.__dic.Keys.Count)
		i = 0
		enumerator = self.__dic.Keys.GetEnumerator()
		while enumerator.MoveNext():
			key = enumerator.Current
			arr[i] = key
			i += 1
		enum_.setArr(arr)
		return enum_

	def _get(self, key):
		if self.__dic.ContainsKey(key):
			return self.__dic[key]
		else:
			return None

	def put(self, key, value):
		pre = None
		if self.__dic.ContainsKey(key):
			pre = self.__dic[key]
		self.__dic[key] = value
		return pre

	def remove(self, key):
		pre = None
		if self.__dic[key] != None:
			pre = self.__dic[key]
			self.__dic.Remove(key)
		#this._dic[key] = null;
		#delete this._dic[key];
		return pre