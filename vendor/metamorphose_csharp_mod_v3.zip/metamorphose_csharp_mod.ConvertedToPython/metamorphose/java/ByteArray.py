﻿from System import *
from System.Collections.Generic import *
from System.Text import *
#FIXME:
class ByteArray(object):
	def clear(self):
		pass

	def writeBytes(self, b, off, len):
		pass

	def writeMultiByte(self, str, encode):
		pass

	def getLength(self):
		return 0

	def get(self, index):
		return 0