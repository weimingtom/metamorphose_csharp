﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class MathUtil(object):
	def toRadians(degrees):
		return degrees * (Math.PI / 180.0)

	toRadians = staticmethod(toRadians)

	def toDegrees(radians):
		return radians * (180.0 / Math.PI)

	toDegrees = staticmethod(toDegrees)