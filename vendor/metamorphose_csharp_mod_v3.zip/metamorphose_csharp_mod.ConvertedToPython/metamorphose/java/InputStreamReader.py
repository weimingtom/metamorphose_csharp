﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class InputStreamReader(Reader):
	def __init__(self, i, charsetName):
		pass