﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from System.Diagnostics import *
# *
# *	用于读取字符流的抽象类。
# *	子类必须实现的方法只有 read(char[], int, int) 和 close()。
# *	但是，多数子类将重写此处定义的一些方法，
# *	以提供更高的效率和/或其他功能。
# 
class Reader(object):
	def __init__(self):
		pass
	def close(self):
		self.throwError("Reader.close() not implement")

	def mark(self, readAheadLimit):
		self.throwError("Reader.mark() not implement")

	def markSupported(self):
		self.throwError("Reader.markSupported() not implement")
		return False

	def read(self):
		self.throwError("Reader.read() not implement")
		return 0

	def read(self, cbuf):
		self.throwError("Reader.readBytes() not implement")
		return 0

	def read(self, cbuf, off, len):
		self.throwError("Reader.readMultiBytes() not implement")
		return 0

	def ready(self):
		self.throwError("Reader.ready() not implement")
		return False

	def reset(self):
		self.throwError("Reader.reset() not implement")

	def skip(self, n):
		self.throwError("Reader.skip() not implement")
		return 0

	#新增
	def throwError(self, str):
		Debug.WriteLine(str)
		raise Exception(str)