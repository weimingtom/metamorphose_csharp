﻿from System import *
from System.Text import *
from System.Collections import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Lua.java#3 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Lua(object):
	""" <summary>
	 <para>
	 Encapsulates a Lua execution environment.  A lot of Jill's public API
	 manifests as public methods in this class.  A key part of the API is
	 the ability to call Lua functions from Java (ultimately, all Lua code
	 is executed in this manner).
	 </para>
	 
	 <para>
	 The Stack
	 </para>
	 
	 <para>
	 All arguments to Lua functions and all results returned by Lua
	 functions are placed onto a stack.  The stack can be indexed by an
	 integer in the same way as the PUC-Rio implementation.  A positive
	 index is an absolute index and ranges from 1 (the bottom-most
	 element) through to <var>n</var> (the top-most element),
	 where <var>n</var> is the number of elements on the stack.  Negative
	 indexes are relative indexes, -1 is the top-most element, -2 is the
	 element underneath that, and so on.  0 is not used.
	 </para>
	 
	 <para>
	 Note that in Jill the stack is used only for passing arguments and
	 returning results, unlike PUC-Rio.
	 </para>
	 
	 <para>
	 The protocol for calling a function is described in the <seealso cref="#call"/>
	 method.  In brief: push the function onto the stack, then push the
	 arguments to the call.
	 </para>
	 
	 <para>
	 The methods <seealso cref="#push"/>, <seealso cref="#pop"/>, <seealso cref="#value"/>,
	 <seealso cref="#getTop"/>, <seealso cref="#setTop"/> are used to manipulate the stack.
	 </para>
	 </summary>
	"""
	def InitializeInstanceFields(self):
		self._civ.addElement(CallInfo())

	# <summary>
	# Version string. </summary>
	#FIXME:added
	# <summary>
	# http://www.ravenbrook.com </summary>
	# <summary>
	# Table of globals (global variables).  This actually shared across
	# all threads (with the same main thread), but kept in each Lua
	# thread as an optimisation.
	# </summary>
	# <summary>
	# Reference the main Lua thread.  Itself if this is the main Lua
	# thread.
	# </summary>
	# <summary>
	# VM data stack.
	# </summary>
	# <summary>
	# One more than the highest stack slot that has been written to
	# (ever).
	# Used by <seealso cref="#stacksetsize"/> to determine which stack slots
	# need nilling when growing the stack.
	# </summary> # = 0;
	# <summary>
	# Number of active elemements in the VM stack.  Should always be
	# <code><= stack.length</code>.
	# </summary> # = 0;
	# <summary>
	# The base stack element for this stack frame.  If in a Lua function
	# then this is the element indexed by operand field 0; if in a Java
	# functipn then this is the element indexed by Lua.value(1).
	# </summary> # = 0; # = 0;
	# <summary>
	# Instruction to resume execution at.  Index into code array. </summary> # = 0;
	# <summary>
	# Vector of CallInfo records.  Actually it's a Stack which is a
	# subclass of Vector, but it mostly the Vector methods that are used.
	# </summary>
	def __ci(self):
		""" <summary>
		 CallInfo record for currently active function. </summary>
		"""
		return self._civ.lastElement()

	# <summary>
	# Open Upvalues.  All UpVal objects that reference the VM stack.
	# openupval is a java.util.Vector of UpVal stored in order of stack
	# slot index: higher stack indexes are stored at higher Vector
	# positions.
	# </summary>
	# <summary>
	# Number of list items to accumulate before a SETLIST instruction. </summary>
	# <summary>
	# Limit for table tag-method chains (to avoid loops) </summary>
	# <summary>
	# The current error handler (set by <seealso cref="#pcall"/>).  A Lua
	# function to call.
	# </summary>
	# <summary>
	# thread activation status.
	# </summary>
	# <summary>
	# Nonce object used by pcall and friends (to detect when an
	# exception is a Lua error). 
	# </summary>
	# <summary>
	# Metatable for primitive types.  Shared between all threads. </summary>
	# <summary>
	# Maximum number of local variables per function.  As per
	# LUAI_MAXVARS from "luaconf.h".  Default access so that {@link
	# FuncState} can see it.
	# </summary>
	# <summary>
	# Stored in Slot.r to denote a numeric value (which is stored at 
	# Slot.d).
	# </summary>
	# <summary>
	# Spare Slot used for a temporary.
	# </summary>
	# <summary>
	# Registry key for loaded modules.
	# </summary>
	def __init__(self):
		""" <summary>
		 Used to construct a Lua thread that shares its global state with
		 another Lua state.
		 </summary>
		"""
		self._InstanceFieldsInitialized = False
		self._D = False
		self._VERSION = "Lua 5.1 (Jill 1.0.1)"
		self._RELEASE = "Lua 5.1.4 (Jill 1.0.1)"
		self._VERSION_NUM = 501
		self._COPYRIGHT = "Copyright (C) 1994-2008 Lua.org, PUC-Rio (Copyright (C) 2006 Nokia Corporation and/or its subsidiary(-ies))"
		self._AUTHORS = "R. Ierusalimschy, L. H. de Figueiredo & W. Celes (Ravenbrook Limited)"
		self._stack = Array.CreateInstance(Slot, 0)
		self._civ = metamorphose.java.Stack()
		self._openupval = ArrayList()
		self._allowhook = True
		self._LFIELDS_PER_FLUSH = 50
		self._MAXTAGLOOP = 100
		self._LUA_ERROR = ""
		self._MAXVARS = 200
		self._MAXSTACK = 250
		self._MAXUPVALUES = 60
		self._NUMBER = System.Object()
		self._SPARE_SLOT = Slot()
		self._LOADED = "_LOADED"
		# Copy the global state, that's shared across all threads that
		# share the same main thread, into the new Lua thread.
		# Any more than this and the global state should be shunted to a
		# separate object (as it is in PUC-Rio).
		#///////////////////////////////////////////////////////////////////
		# Public API
		# <summary>
		# Creates a fresh Lua state.
		# </summary>
		# <summary>
		# Equivalent of LUA_MULTRET.
		# </summary>
		# Required, by vmPoscall, to be negative.
		self._MULTRET = -1
		# <summary>
		# The Lua <code>nil</code> value.
		# </summary>
		self._NIL = System.Object()
		# Lua type tags, from lua.h
		# <summary>
		# Lua type tag, representing no stack value. </summary>
		self._TNONE = -1
		# <summary>
		# Lua type tag, representing <code>nil</code>. </summary>
		self._TNIL = 0
		# <summary>
		# Lua type tag, representing boolean. </summary>
		self._TBOOLEAN = 1
		# TLIGHTUSERDATA not available.  :todo: make available?
		# <summary>
		# Lua type tag, representing numbers. </summary>
		self._TNUMBER = 3
		# <summary>
		# Lua type tag, representing strings. </summary>
		self._TSTRING = 4
		# <summary>
		# Lua type tag, representing tables. </summary>
		self._TTABLE = 5
		# <summary>
		# Lua type tag, representing functions. </summary>
		self._TFUNCTION = 6
		# <summary>
		# Lua type tag, representing userdata. </summary>
		self._TUSERDATA = 7
		# <summary>
		# Lua type tag, representing threads. </summary>
		self._TTHREAD = 8
		# <summary>
		# Number of type tags.  Should be one more than the
		# last entry in the list of tags.
		# </summary>
		self._NUM_TAGS = 9
		# <summary>
		# Names for above type tags, starting from <seealso cref="#TNIL"/>.
		# Equivalent to luaT_typenames.
		# </summary>
		self._TYPENAME = Array[str](("nil", "boolean", "userdata", "number", "string", "table", "function", "userdata", "thread"))
		# <summary>
		# Minimum stack size that Lua Java functions gets.  May turn out to
		# be silly / redundant.
		# </summary>
		self._MINSTACK = 20
		# <summary>
		# Status code, returned from pcall and friends, that indicates the
		# thread has yielded.
		# </summary>
		self._YIELD = 1
		# <summary>
		# Status code, returned from pcall and friends, that indicates
		# a runtime error.
		# </summary>
		self._ERRRUN = 2
		# <summary>
		# Status code, returned from pcall and friends, that indicates
		# a syntax error.
		# </summary>
		self._ERRSYNTAX = 3
		# <summary>
		# Status code, returned from pcall and friends, that indicates
		# a memory allocation error.
		# </summary>
		self._ERRMEM = 4
		# <summary>
		# Status code, returned from pcall and friends, that indicates
		# an error whilst running the error handler function.
		# </summary>
		self._ERRERR = 5
		# <summary>
		# Status code, returned from loadFile and friends, that indicates
		# an IO error.
		# </summary>
		self._ERRFILE = 6
		# Enums for gc().
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that requests the GC to stop. </summary>
		self._GCSTOP = 0
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that requests the GC to restart. </summary>
		self._GCRESTART = 1
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that requests a full collection. </summary>
		self._GCCOLLECT = 2
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that returns amount of memory
		# (in Kibibytes) in use (by the entire Java runtime).
		# </summary>
		self._GCCOUNT = 3
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that returns the remainder of
		# dividing the amount of memory in use by 1024.
		# </summary>
		self._GCCOUNTB = 4
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that requests an incremental
		# garbage collection be performed.
		# </summary>
		self._GCSTEP = 5
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that sets a new value for the
		# <var>pause</var> of the collector.
		# </summary>
		self._GCSETPAUSE = 6
		# <summary>
		# Action, passed to <seealso cref="#gc"/>, that sets a new values for the
		# <var>step multiplier</var> of the collector.
		# </summary>
		self._GCSETSTEPMUL = 7
		# Some of the hooks, etc, aren't implemented, so remain private.
		self._HOOKCALL = 0
		self._HOOKRET = 1
		self._HOOKLINE = 2
		# <summary>
		# When <seealso cref="Hook"/> callback is called as a line hook, its
		# <var>ar.event</var> field is <code>HOOKCOUNT</code>.
		# </summary>
		self._HOOKCOUNT = 3
		self._HOOKTAILRET = 4
		self._MASKCALL = 1 << self._HOOKCALL
		self._MASKRET = 1 << self._HOOKRET
		self._MASKLINE = 1 << self._HOOKLINE
		# <summary>
		# Bitmask that specifies count hook in call to <seealso cref="#setHook"/>.
		# </summary>
		self._MASKCOUNT = 1 << self._HOOKCOUNT
		# <summary>
		# Calls a Lua value.  Normally this is called on functions, but the
		# semantics of Lua permit calls on any value as long as its metatable
		# permits it.
		# 
		# In order to call a function, the function must be
		# pushed onto the stack, then its arguments must be
		# <seealso cref="#push pushed"/> onto the stack; the first argument is pushed
		# directly after the function,
		# then the following arguments are pushed in order (direct
		# order).  The parameter <var>nargs</var> specifies the number of
		# arguments (which may be 0).
		# 
		# When the function returns the function value on the stack and all
		# the arguments are removed from the stack and replaced with the
		# results of the function, adjusted to the number specified by
		# <var>nresults</var>.  So the first result from the function call will
		# be at the same index where the function was immediately prior to
		# calling this method.
		# </summary>
		# <param name="nargs">     The number of arguments in this function call. </param>
		# <param name="nresults">  The number of results required. </param>
		# <summary>
		# Closes a Lua state.  In this implementation, this method does
		# nothing.
		# </summary>
		# <summary>
		# Concatenate values (usually strings) on the stack.
		# <var>n</var> values from the top of the stack are concatenated, as
		# strings, and replaced with the resulting string. </summary>
		# <param name="n">  the number of values to concatenate. </param> # push empty string # else n == 1; nothing to do
		# <summary>
		# Creates a new empty table and returns it. </summary>
		# <param name="narr">  number of array elements to pre-allocate. </param>
		# <param name="nrec">  number of non-array elements to pre-allocate. </param>
		# <returns> a fresh table. </returns>
		# <seealso cref= #newTable </seealso>
		# <summary>
		# Dumps a function as a binary chunk. </summary>
		# <param name="function">  the Lua function to dump. </param>
		# <param name="writer">    the stream that receives the dumped binary. </param>
		# <exception cref="IOException"> when writer does. </exception>
		# <summary>
		# Tests for equality according to the semantics of Lua's
		# <code>==</code> operator (so may call metamethods). </summary>
		# <param name="o1">  a Lua value. </param>
		# <param name="o2">  another Lua value. </param>
		# <returns> true when equal. </returns>
		# <summary>
		# Generates a Lua error using the error message. </summary>
		# <param name="message">  the error message. </param>
		# <returns> never. </returns>
		# <summary>
		# Control garbage collector.  Note that in Jill most of the options
		# to this function make no sense and they will not do anything. </summary>
		# <param name="what">  specifies what GC action to take. </param>
		# <param name="data">  data that may be used by the action. </param>
		# <returns> varies. </returns>
		# <summary>
		# Returns the environment table of the Lua value. </summary>
		# <param name="o">  the Lua value. </param>
		# <returns> its environment table. </returns>
		# :todo: implement this case.
		# <summary>
		# Get a field from a table (or other object). </summary>
		# <param name="t">      The object whose field to retrieve. </param>
		# <param name="field">  The name of the field. </param>
		# <returns>  the Lua value </returns>
		# <summary>
		# Get a global variable. </summary>
		# <param name="name">  The name of the global variable. </param>
		# <returns>  The value of the global variable. </returns>
		# <summary>
		# Gets the global environment.  The global environment, where global
		# variables live, is returned as a <code>LuaTable</code>.  Note that
		# modifying this table has exactly the same effect as creating or
		# changing global variables from within Lua. </summary>
		# <returns>  The global environment as a table. </returns>
		# <summary>
		# Get metatable. </summary>
		# <param name="o">  the Lua value whose metatable to retrieve. </param>
		# <returns> The metatable, or null if there is no metatable. </returns>
		# <summary>
		# Gets the registry table.
		# </summary>
		# <summary>
		# Indexes into a table and returns the value. </summary>
		# <param name="t">  the Lua value to index. </param>
		# <param name="k">  the key whose value to return. </param>
		# <returns> the value t[k]. </returns>
		# <summary>
		# Gets the number of elements in the stack.  If the stack is not
		# empty then this is the index of the top-most element. </summary>
		# <returns> number of stack elements. </returns>
		# <summary>
		# Insert Lua value into stack immediately at specified index.  Values
		# in stack at that index and higher get pushed up. </summary>
		# <param name="o">    the Lua value to insert into the stack. </param>
		# <param name="idx">  the stack index at which to insert. </param>
		# <summary>
		# Tests that an object is a Lua boolean. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is a Lua boolean. </returns>
		# <summary>
		# Tests that an object is a Lua function implementated in Java (a Lua
		# Java Function). </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is a Lua Java Function. </returns>
		# <summary>
		# Tests that an object is a Lua function (implemented in Lua or
		# Java). </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is a function. </returns> #static
		# <summary>
		# Tests that a Lua thread is the main thread. </summary>
		# <returns> true if and only if is the main thread. </returns>
		# <summary>
		# Tests that an object is Lua <code>nil</code>. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is Lua <code>nil</code>. </returns> #static
		# <summary>
		# Tests that an object is a Lua number or a string convertible to a
		# number. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is a number or a convertible string. </returns> #static
		# <summary>
		# Tests that an object is a Lua string or a number (which is always
		# convertible to a string). </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if object is a string or number. </returns> #static
		# <summary>
		# Tests that an object is a Lua table. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> <code>true</code> if and only if the object is a Lua table. </returns> #static
		# <summary>
		# Tests that an object is a Lua thread. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> <code>true</code> if and only if the object is a Lua thread. </returns>
		# <summary>
		# Tests that an object is a Lua userdata. </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and only if the object is a Lua userdata. </returns>
		# <summary>
		# <para>
		# Tests that an object is a Lua value.  Returns <code>true</code> for
		# an argument that is a Jill representation of a Lua value,
		# <code>false</code> for Java references that are not Lua values.
		# For example <code>isValue(new LuaTable())</code> is
		# <code>true</code>, but <code>isValue(new Object[] { })</code> is
		# <code>false</code> because Java arrays are not a representation of
		# any Lua value.
		# </para>
		# <para>
		# PUC-Rio Lua provides no
		# counterpart for this method because in their implementation it is
		# impossible to get non Lua values on the stack, whereas in Jill it
		# is common to mix Lua values with ordinary, non Lua, Java objects.
		# </para> </summary>
		# <param name="o">  the Object to test. </param>
		# <returns> true if and if it represents a Lua value. </returns>
		# <summary>
		# Compares two Lua values according to the semantics of Lua's
		# <code>&lt;</code> operator, so may call metamethods. </summary>
		# <param name="o1">  the left-hand operand. </param>
		# <param name="o2">  the right-hand operand. </param>
		# <returns> true when <code>o1 < o2</code>. </returns>
		# <summary>
		# <para>
		# Loads a Lua chunk in binary or source form.
		# Comparable to C's lua_load.  If the chunk is determined to be
		# binary then it is loaded directly.  Otherwise the chunk is assumed
		# to be a Lua source chunk and compilation is required first; the
		# <code>InputStream</code> is used to create a <code>Reader</code>
		# using the UTF-8 encoding
		# (using a second argument of <code>"UTF-8"</code> to the
		# {@link java.io.InputStreamReader#InputStreamReader(java.io.InputStream,
		# java.lang.String)}
		# constructor) and the Lua source is compiled.
		# </para>
		# <para>
		# If successful, The compiled chunk, a Lua function, is pushed onto
		# the stack and a zero status code is returned.  Otherwise a non-zero
		# status code is returned to indicate an error and the error message
		# is pushed onto the stack.
		# </para> </summary>
		# <param name="in">         The binary chunk as an InputStream, for example from
		#                   <seealso cref="Class#getResourceAsStream"/>. </param>
		# <param name="chunkname">  The name of the chunk. </param>
		# <returns>           A status code. </returns>
		# <summary>
		# Loads a Lua chunk in source form.
		# Comparable to C's lua_load.  This method takes a {@link
		# java.io.Reader} parameter,
		# and is normally used to load Lua chunks in source form.
		# However, it if the input looks like it is the output from Lua's
		# <code>string.dump</code> function then it will be processed as a
		# binary chunk.
		# In every other respect this method is just like {@link
		# #load(InputStream, String)}. </summary>
		# <param name="in">         The source chunk as a Reader, for example from
		#                   <code>java.io.InputStreamReader(Class.getResourceAsStream())</code>. </param>
		# <param name="chunkname">  The name of the chunk. </param>
		# <returns>           A status code. </returns>
		# <seealso cref= java.io.InputStreamReader </seealso>
		# <summary>
		# Slowly get the next key from a table.  Unlike most other functions
		# in the API this one uses the stack.  The top-of-stack is popped and
		# used to find the next key in the table at the position specified by
		# index.  If there is a next key then the key and its value are
		# pushed onto the stack and <code>true</code> is returned.
		# Otherwise (the end of the table has been reached)
		# <code>false</code> is returned. </summary>
		# <param name="idx">  stack index of table. </param>
		# <returns>  true if and only if there are more keys in the table. </returns>
		# @deprecated Use <seealso cref="#tableKeys"/> enumeration protocol instead. 
		# :todo: api check
		# protocol error which we could potentially diagnose.
		# <summary>
		# Creates a new empty table and returns it. </summary>
		# <returns> a fresh table. </returns>
		# <seealso cref= #createTable </seealso>
		# <summary>
		# Creates a new Lua thread and returns it. </summary>
		# <returns> a new Lua thread. </returns>
		# <summary>
		# Wraps an arbitrary Java reference in a Lua userdata and returns it. </summary>
		# <param name="ref">  the Java reference to wrap. </param>
		# <returns> the new LuaUserdata. </returns>
		# <summary>
		# Return the <em>length</em> of a Lua value.  For strings this is
		# the string length; for tables, this is result of the <code>#</code>
		# operator; for other values it is 0. </summary>
		# <param name="o">  a Lua value. </param>
		# <returns> its length. </returns> #static
		# <summary>
		# <para>
		# Protected <seealso cref="#call"/>.  <var>nargs</var> and
		# <var>nresults</var> have the same meaning as in <seealso cref="#call"/>.
		# If there are no errors during the call, this method behaves as
		# <seealso cref="#call"/>.  Any errors are caught, the error object (usually
		# a message) is pushed onto the stack, and a non-zero error code is
		# returned.
		# </para>
		# <para>
		# If <var>er</var> is <code>null</code> then the error object that is
		# on the stack is the original error object.  Otherwise
		# <var>ef</var> specifies an <em>error handling function</em> which
		# is called when the original error is generated; its return value
		# becomes the error object left on the stack by <code>pcall</code>.
		# </para> </summary>
		# <param name="nargs">     number of arguments. </param>
		# <param name="nresults">  number of result required. </param>
		# <param name="ef">        error function to call in case of error. </param>
		# <returns> 0 if successful, else a non-zero error code. </returns>
		# Most of this code comes from luaD_pcall # close eventual pending closures # close eventual pending closures
		# <summary>
		# Removes (and discards) the top-most <var>n</var> elements from the stack. </summary>
		# <param name="n">  the number of elements to remove. </param>
		# <summary>
		# Pushes a value onto the stack in preparation for calling a
		# function (or returning from one).  See <seealso cref="#call"/> for
		# the protocol to be used for calling functions.  See {@link
		# #pushNumber} for pushing numbers, and <seealso cref="#pushValue"/> for
		# pushing a value that is already on the stack. </summary>
		# <param name="o">  the Lua value to push. </param>
		# see also a private overloaded version of this for Slot.
		# <summary>
		# Push boolean onto the stack. </summary>
		# <param name="b">  the boolean to push. </param>
		# <summary>
		# Push literal string onto the stack. </summary>
		# <param name="s">  the string to push. </param>
		# <summary>
		# Push nil onto the stack. </summary>
		# <summary>
		# Pushes a number onto the stack.  See also <seealso cref="#push"/>. </summary>
		# <param name="d">  the number to push. </param>
		# :todo: optimise to avoid creating Double instance
		# <summary>
		# Push string onto the stack. </summary>
		# <param name="s">  the string to push. </param>
		# <summary>
		# Copies a stack element onto the top of the stack.
		# Equivalent to <code>L.push(L.value(idx))</code>. </summary>
		# <param name="idx">  stack index of value to push. </param>
		# :todo: optimised to avoid creating Double instance
		# <summary>
		# Implements equality without metamethods. </summary>
		# <param name="o1">  the first Lua value to compare. </param>
		# <param name="o2">  the other Lua value. </param>
		# <returns>  true if and only if they compare equal. </returns> #static
		# <summary>
		# Gets an element from a table, without using metamethods. </summary>
		# <param name="t">  The table to access. </param>
		# <param name="k">  The index (key) into the table. </param>
		# <returns> The value at the specified index. </returns> #static
		# <summary>
		# Gets an element from an array, without using metamethods. </summary>
		# <param name="t">  the array (table). </param>
		# <param name="i">  the index of the element to retrieve. </param>
		# <returns>  the value at the specified index. </returns> #static
		# <summary>
		# Sets an element in a table, without using metamethods. </summary>
		# <param name="t">  The table to modify. </param>
		# <param name="k">  The index into the table. </param>
		# <param name="v">  The new value to be stored at index <var>k</var>. </param>
		# <summary>
		# Sets an element in an array, without using metamethods. </summary>
		# <param name="t">  the array (table). </param>
		# <param name="i">  the index of the element to set. </param>
		# <param name="v">  the new value to be stored at index <var>i</var>. </param>
		# <summary>
		# Register a <seealso cref="LuaJavaCallback"/> as the new value of the global
		# <var>name</var>. </summary>
		# <param name="name">  the name of the global. </param>
		# <param name="f">     the LuaJavaCallback to register. </param>
		# <summary>
		# Starts and resumes a Lua thread.  Threads can be created using
		# <seealso cref="#newThread"/>.  Once a thread has begun executing it will
		# run until it either completes (with error or normally) or has been
		# suspended by invoking <seealso cref="#yield"/>. </summary>
		# <param name="narg">  Number of values to pass to thread. </param>
		# <returns> Lua.YIELD, 0, or an error code. </returns>
		# assert errfunc == 0 && nCcalls == 0;
		# This block is equivalent to resume from ldo.c # start coroutine?
		# assert civ.size() == 1 && firstArg > base); # resuming from previous yield
		# assert status == YIELD; # 'common' yield
		# finish interrupted execution of 'OP_CALL'
		# assert ... # complete it... # and correct top # yielded inside a hook: just continue its execution # mark thread as 'dead'
		# <summary>
		# Set the environment for a function, thread, or userdata. </summary>
		# <param name="o">      Object whose environment will be set. </param>
		# <param name="table">  Environment table to use. </param>
		# <returns> true if the object had its environment set, false otherwise. </returns>
		# :todo: consider implementing common env interface for
		# LuaFunction, LuaJavaCallback, LuaUserdata, Lua.  One cast to an
		# interface and an interface method call may be shorter
		# than this mess.
		# :todo: implement this case.
		# <summary>
		# Set a field in a Lua value. </summary>
		# <param name="t">     Lua value of which to set a field. </param>
		# <param name="name">  Name of field to set. </param>
		# <param name="v">     new Lua value for field. </param>
		# <summary>
		# Sets the metatable for a Lua value. </summary>
		# <param name="o">   Lua value of which to set metatable. </param>
		# <param name="mt">  The new metatable. </param>
		# <summary>
		# Set a global variable. </summary>
		# <param name="name">   name of the global variable to set. </param>
		# <param name="value">  desired new value for the variable. </param>
		# <summary>
		# Does the equivalent of <code>t[k] = v</code>. </summary>
		# <param name="t">  the table to modify. </param>
		# <param name="k">  the index to modify. </param>
		# <param name="v">  the new value at index <var>k</var>. </param>
		# <summary>
		# Status of a Lua thread. </summary>
		# <returns> 0, an error code, or Lua.YIELD. </returns>
		# <summary>
		# Returns an <seealso cref="java.util.Enumeration"/> for the keys of a table. </summary>
		# <param name="t">  a Lua table. </param>
		# <returns> an Enumeration object. </returns>
		# NOTREACHED
		# <summary>
		# Convert to boolean. </summary>
		# <param name="o">  Lua value to convert. </param>
		# <returns>  the resulting primitive boolean. </returns>
		# <summary>
		# Convert to integer and return it.  Returns 0 if cannot be
		# converted. </summary>
		# <param name="o">  Lua value to convert. </param>
		# <returns>  the resulting int. </returns>
		# <summary>
		# Convert to number and return it.  Returns 0 if cannot be
		# converted. </summary>
		# <param name="o">  Lua value to convert. </param>
		# <returns>  The resulting number. </returns>
		# <summary>
		# Convert to string and return it.  If value cannot be converted then
		# <code>null</code> is returned.  Note that unlike
		# <code>lua_tostring</code> this
		# does not modify the Lua value. </summary>
		# <param name="o">  Lua value to convert. </param>
		# <returns>  The resulting string. </returns>
		# <summary>
		# Convert to Lua thread and return it or <code>null</code>. </summary>
		# <param name="o">  Lua value to convert. </param>
		# <returns>  The resulting Lua instance. </returns>
		# <summary>
		# Convert to userdata or <code>null</code>.  If value is a {@link
		# LuaUserdata} then it is returned, otherwise, <code>null</code> is
		# returned. </summary>
		# <param name="o">  Lua value. </param>
		# <returns>  value as userdata or <code>null</code>. </returns>
		# <summary>
		# Type of the Lua value at the specified stack index. </summary>
		# <param name="idx">  stack index to type. </param>
		# <returns>  the type, or <seealso cref="#TNONE"/> if there is no value at <var>idx</var> </returns>
		# <summary>
		# Type of a Lua value. </summary>
		# <param name="o">  the Lua value whose type to return. </param>
		# <returns>  the Lua type from an enumeration. </returns>
		# <summary>
		# Name of type. </summary>
		# <param name="type">  a Lua type from, for example, <seealso cref="#type"/>. </param>
		# <returns>  the type's name. </returns>
		# <summary>
		# Gets a value from the stack.
		# If <var>idx</var> is positive and exceeds
		# the size of the stack, <seealso cref="#NIL"/> is returned. </summary>
		# <param name="idx">  the stack index of the value to retrieve. </param>
		# <returns>  the Lua value from the stack. </returns>
		# <summary>
		# Converts primitive boolean into a Lua value. </summary>
		# <param name="b">  the boolean to convert. </param>
		# <returns>  the resulting Lua value. </returns>
		# If CLDC 1.1 had
		# <code>java.lang.Boolean.valueOf(boolean);</code> then I probably
		# wouldn't have written this.  This does have a small advantage:
		# code that uses this method does not need to assume that Lua booleans in
		# Jill are represented using Java.lang.Boolean.
		# <summary>
		# Converts primitive number into a Lua value. </summary>
		# <param name="d">  the number to convert. </param>
		# <returns>  the resulting Lua value. </returns>
		# :todo: consider interning "common" numbers, like 0, 1, -1, etc.
		# <summary>
		# Exchange values between different threads. </summary>
		# <param name="to">  destination Lua thread. </param>
		# <param name="n">   numbers of stack items to move. </param>
		# L.apiCheck(from.G() == to.G());
		# <summary>
		# Yields a thread.  Should only be called as the return expression
		# of a Lua Java function: <code>return L.yield(nresults);</code>.
		# A <seealso cref="RuntimeException"/> can also be thrown to yield.  If the
		# Java code that is executing throws an instance of {@link
		# RuntimeException} (direct or indirect) then this causes the Lua 
		# thread to be suspended, as if <code>L.yield(0);</code> had been
		# executed, and the exception is re-thrown to the code that invoked
		# <seealso cref="#resume"/>. </summary>
		# <param name="nresults">  Number of results to return to <seealso cref="#resume"/>. </param>
		# <returns>  a secret value. </returns> # protect stack slots below
		# Miscellaneous private functions.
		# <summary>
		# Convert from Java API stack index to absolute index. </summary>
		# <returns> an index into <code>this.stack</code> or -1 if out of range. </returns>
		# idx < 0
		# <summary>
		# As <seealso cref="#absIndex"/> but does not return -1 for out of range
		# indexes.  Essential for <seealso cref="#insert"/> because an index equal
		# to the size of the stack is valid for that call.
		# </summary>
		# idx < 0
		#///////////////////////////////////////////////////////////////////
		# Auxiliary API
		# :todo: consider placing in separate class (or macroised) so that we
		# can change its definition (to remove the check for example).
		# <summary>
		# Checks a general condition and raises error if false. </summary>
		# <param name="cond">      the (evaluated) condition to check. </param>
		# <param name="numarg">    argument index. </param>
		# <param name="extramsg">  extra error message to append. </param>
		# <summary>
		# Raise a general error for an argument. </summary>
		# <param name="narg">      argument index. </param>
		# <param name="extramsg">  extra message string to append. </param>
		# <returns> never (used idiomatically in <code>return argError(...)</code>) </returns>
		# :todo: use debug API as per PUC-Rio
		# if (true)
		# return 0;
		# <summary>
		# Calls a metamethod.  Pushes 1 result onto stack if method called. </summary>
		# <param name="obj">    stack index of object whose metamethod to call </param>
		# <param name="event">  metamethod (event) name. </param>
		# <returns>  true if and only if metamethod was found and called. </returns>
		# <summary>
		# Checks that an argument is present (can be anything).
		# Raises error if not. </summary>
		# <param name="narg">  argument index. </param>
		# <summary>
		# Checks is a number and returns it as an integer.  Raises error if
		# not a number. </summary>
		# <param name="narg">  argument index. </param>
		# <returns>  the argument as an int. </returns>
		# <summary>
		# Checks is a number.  Raises error if not a number. </summary>
		# <param name="narg">  argument index. </param>
		# <returns>  the argument as a double. </returns>
		# <summary>
		# Checks that an optional string argument is an element from a set of
		# strings.  Raises error if not. </summary>
		# <param name="narg">  argument index. </param>
		# <param name="def">   default string to use if argument not present. </param>
		# <param name="lst">   the set of strings to match against. </param>
		# <returns> an index into <var>lst</var> specifying the matching string. </returns>
		# <summary>
		# Checks argument is a string and returns it.  Raises error if not a
		# string. </summary>
		# <param name="narg">  argument index. </param>
		# <returns>  the argument as a string. </returns>
		# <summary>
		# Checks the type of an argument, raises error if not matching. </summary>
		# <param name="narg">  argument index. </param>
		# <param name="t">     typecode (from <seealso cref="#type"/> for example). </param>
		# <summary>
		# Loads and runs the given string. </summary>
		# <param name="s">  the string to run. </param>
		# <returns>  a status code, as per <seealso cref="#load"/>. </returns>
		# <summary>
		# Equivalent to luaL_findtable.  Instead of the table being passed on
		# the stack, it is passed as the argument <var>t</var>.
		# Likes its PUC-Rio equivalent however, this method leaves a table on
		# the Lua stack.
		# </summary> # no such field? # new table for field # field has a non-table value?
		# <summary>
		# Get a field (event) from an Lua value's metatable.  Returns Lua
		# <code>nil</code> if there is either no metatable or no field. </summary>
		# <param name="o">           Lua value to get metafield for. </param>
		# <param name="event">       name of metafield (event). </param>
		# <returns>            the field from the metatable, or nil. </returns>
		# <summary>
		# Loads a Lua chunk from a file.  The <var>filename</var> argument is
		# used in a call to <seealso cref="Class#getResourceAsStream"/> where
		# <code>this</code> is the <seealso cref="Lua"/> instance, thus relative
		# pathnames will be relative to the location of the
		# <code>Lua.class</code> file.  Pushes compiled chunk, or error
		# message, onto stack. </summary>
		# <param name="filename">  location of file. </param>
		# <returns> status code, as per <seealso cref="#load"/>. </returns> # Unix exec. file?
		# :todo: handle this case
		# <summary>
		# Loads a Lua chunk from a string.  Pushes compiled chunk, or error
		# message, onto stack. </summary>
		# <param name="s">           the string to load. </param>
		# <param name="chunkname">   the name of the chunk. </param>
		# <returns> status code, as per <seealso cref="#load"/>. </returns>
		# <summary>
		# Get optional integer argument.  Raises error if non-number
		# supplied. </summary>
		# <param name="narg">  argument index. </param>
		# <param name="def">   default value for integer. </param>
		# <returns> an int. </returns>
		# <summary>
		# Get optional number argument.  Raises error if non-number supplied. </summary>
		# <param name="narg">  argument index. </param>
		# <param name="def">   default value for number. </param>
		# <returns> a double. </returns>
		# <summary>
		# Get optional string argument.  Raises error if non-string supplied. </summary>
		# <param name="narg">  argument index. </param>
		# <param name="def">   default value for string. </param>
		# <returns> a string. </returns>
		# <summary>
		# Creates a table in the global namespace and registers it as a loaded
		# module. </summary>
		# <returns> the new table </returns> # not found?
		# try global variable (and create one if it does not exist) # _LOADED[name] = new table
		# <summary>
		# Name of type of value at <var>idx</var>. </summary>
		# <param name="idx">  stack index. </param>
		# <returns>  the name of the value's type. </returns>
		# <summary>
		# Declare type error in argument. </summary>
		# <param name="narg">   Index of argument. </param>
		# <param name="tname">  Name of type expected. </param>
		# <summary>
		# Return string identifying current position of the control at level
		# <var>level</var>. </summary>
		# <param name="level">  specifies the call-stack level. </param>
		# <returns> a description for that level. </returns> # check function at level # get info about it # is there info? # else, no information available...
		# <summary>
		# Provide <seealso cref="java.io.Reader"/> interface over a <code>String</code>.
		# Equivalent of <seealso cref="java.io.StringReader#StringReader"/> from J2SE.
		# The ability to convert a <code>String</code> to a
		# <code>Reader</code> is required internally,
		# to provide the Lua function <code>loadstring</code>; exposed
		# externally as a convenience. </summary>
		# <param name="s">  the string from which to read. </param>
		# <returns> a <seealso cref="java.io.Reader"/> that reads successive chars from <var>s</var>. </returns>
		#///////////////////////////////////////////////////////////////////
		# Debug
		# Methods equivalent to debug API.  In PUC-Rio most of these are in
		# ldebug.c
		# :todo: complete me # no tail call?
		## assert isFunction(f)
		# <summary>
		# Locates function activation at specified call level and returns a
		# <seealso cref="Debug"/>
		# record for it, or <code>null</code> if level is too high.
		# May become public. </summary>
		# <param name="level">  the call level. </param>
		# <returns> a <seealso cref="Debug"/> instance describing the activation record. </returns> # Index of CallInfo # Lua function? # skip lost tail calls # level found? # level is of a lost tail call?
		# <summary>
		# Sets the debug hook.
		# </summary> # turn off hooks?
		# <returns> true is okay, false otherwise (for example, error). </returns>
		# :todo: implement me # handled by getInfo
		# :todo: more cases. # only active Lua functions have current-line info # function is not a Lua function?
		# <summary>
		# Equivalent to macro isLua _and_ f_isLua from lstate.h. </summary>
		#///////////////////////////////////////////////////////////////////
		# Do
		# Methods equivalent to the file ldo.c.  Prefixed with d.
		# Some of these are in vm* instead.
		# <summary>
		# Equivalent to luaD_callhook.
		# </summary> # not supported yet # cannot call hooks inside a hook
		## assert !allowhook
		self._MEMERRMSG = "not enough memory"
		# <summary>
		# Equivalent to luaD_seterrorobj.  It is valid for oldtop to be
		# equal to the current stack size (<code>stackSize</code>).
		# <seealso cref="#resume"/> uses this value for oldtop.
		# </summary>
		#///////////////////////////////////////////////////////////////////
		# Func
		# Methods equivalent to the file lfunc.c.  Prefixed with f.
		# <summary>
		# Equivalent of luaF_close.  All open upvalues referencing stack
		# slots level or higher are closed. </summary>
		# <param name="level">  Absolute stack index. </param>
		# 
		# * We search from the end of the Vector towards the beginning,
		# * looking for an UpVal for the required stack-slot.
		# 
		# i points to be position _after_ which we want to insert a new
		# UpVal (it's -1 when we want to insert at the beginning).
		#///////////////////////////////////////////////////////////////////
		# Debug
		# Methods equivalent to the file ldebug.c.  Prefixed with g.
		# <summary>
		# <var>p1</var> and <var>p2</var> are operands to a numeric opcode.
		# Corrupts <code>NUMOP[0]</code>.
		# There is the possibility of using <var>p1</var> and <var>p2</var> to
		# identify (for example) for local variable being used in the
		# computation (consider the error message for code like <code>local
		# y='a'; return y+1</code> for example).  Currently the debug info is
		# not used, and this opportunity is wasted (it would require changing
		# or overloading gTypeerror).
		# </summary> # first operand is wrong
		# <summary>
		# <var>p1</var> and <var>p2</var> are absolute stack indexes. </summary>
		# assert !(p1 instanceof String);
		# :todo: implement me. # is there an error handling function # push function (under error arg) # call it
		# NOTREACHED
		# NOTREACHED
		# :todo: PUC-Rio searches the stack to see if the value (which may
		# be a reference to stack cell) is a local variable.
		# For now we cop out and just call gTypeerror(Object, String)
		#///////////////////////////////////////////////////////////////////
		# Object
		# Methods equivalent to the file lobject.c.  Prefixed with o.
		self._IDSIZE = 60
		# <returns> a string no longer than IDSIZE. </returns>
		# else  "source" or "...source" # get last part of file name
		# else  [string "string"] # must truncate
		# <summary>
		# Equivalent to luaO_fb2int. </summary>
		# <seealso cref= Syntax#oInt2fb </seealso>
		# <summary>
		# Equivalent to luaO_rawequalObj. </summary>
		# see also vmEqual
		# Now a is not null, so a.equals() is a valid call.
		# Numbers (Doubles), Booleans, Strings all get compared by value,
		# as they should; tables, functions, get compared by identity as
		# they should.
		# <summary>
		# Equivalent to luaO_str2d. </summary>
		# :todo: using try/catch may be too slow.  In which case we'll have
		# to recognise the valid formats first.
		# Attempt hexadecimal conversion.
		# :todo: using String.trim is not strictly accurate, because it
		# trims other ASCII control characters as well as whitespace.
		#/////////////////////////////////////////////////////////////////////
		# VM
		# Most of the methods in this section are equivalent to the files
		# lvm.c and ldo.c from PUC-Rio.  They're mostly prefixed with vm as
		# well.
		self._PCRLUA = 0
		self._PCRJ = 1
		self._PCRYIELD = 2
		# Instruction decomposition.
		# There follows a series of methods that extract the various fields
		# from a VM instruction.  See lopcodes.h from PUC-Rio.
		# :todo: Consider replacing with m4 macros (or similar).
		# A brief overview of the instruction format:
		# Logically an instruction has an opcode (6 bits), op, and up to
		# three fields using one of three formats:
		# A B C  (8 bits, 9 bits, 9 bits)
		# A Bx   (8 bits, 18 bits)
		# A sBx  (8 bits, 18 bits signed - excess K)
		# Some instructions do not use all the fields (EG OP_UNM only uses A
		# and B).
		# When packed into a word (an int in Jill) the following layouts are
		# used:
		#  31 (MSB)    23 22          14 13         6 5      0 (LSB)
		# +--------------+--------------+------------+--------+
		# | B            | C            | A          | OPCODE |
		# +--------------+--------------+------------+--------+
		#
		# +--------------+--------------+------------+--------+
		# | Bx                          | A          | OPCODE |
		# +--------------+--------------+------------+--------+
		#
		# +--------------+--------------+------------+--------+
		# | sBx                         | A          | OPCODE |
		# +--------------+--------------+------------+--------+
		self._NO_REG = 0xff # SIZE_A == 8, (1 << 8)-1
		# Hardwired values for speed.
		# <summary>
		# Equivalent of macro GET_OPCODE </summary>
		# POS_OP == 0 (shift amount)
		# SIZE_OP == 6 (opcode width)
		# <summary>
		# Equivalent of macro GET_OPCODE </summary>
		# POS_OP == 0 (shift amount)
		# SIZE_OP == 6 (opcode width)
		# <summary>
		# Equivalent of macro GETARG_A </summary>
		# POS_A == POS_OP + SIZE_OP == 6 (shift amount)
		# SIZE_A == 8 (operand width)
		# <summary>
		# Equivalent of macro GETARG_B </summary>
		# POS_B == POS_OP + SIZE_OP + SIZE_A + SIZE_C == 23 (shift amount)
		# SIZE_B == 9 (operand width)
		# No mask required as field occupies the most significant bits of a
		# * 32-bit int.
		# <summary>
		# Equivalent of macro GETARG_C </summary>
		# POS_C == POS_OP + SIZE_OP + SIZE_A == 14 (shift amount)
		# SIZE_C == 9 (operand width)
		# <summary>
		# Equivalent of macro GETARG_Bx </summary>
		# POS_Bx = POS_C == 14
		# SIZE_Bx == SIZE_C + SIZE_B == 18
		# No mask required as field occupies the most significant bits of a
		# * 32 bit int.
		# <summary>
		# Equivalent of macro GETARG_sBx </summary>
		# As ARGBx but with (2**17-1) subtracted. # CHECK THIS IS RIGHT
		# The "is constant" bit position depends on the size of the B and C
		# fields (required to be the same width).
		# SIZE_B == 9
		# <summary>
		# Near equivalent of macros RKB and RKC.  Note: non-static as it
		# requires stack and base instance members.  Stands for "Register or
		# Konstant" by the way, it gets value from either the register file
		# (stack) or the constant array (k).
		# </summary>
		# <summary>
		# Slower version of RK that does not receive the constant array.  Not
		# recommend for routine use, but is used by some error handling code
		# to avoid having a constant array passed around too much.
		# </summary>
		# CREATE functions are required by FuncState, so default access.
		# POS_OP == 0
		# POS_A == 6
		# POS_B == 23
		# POS_C == 14
		# POS_OP == 0
		# POS_A == 6
		# POS_Bx == POS_C == 14
		# opcode enumeration.
		# Generated by a script:
		# awk -f opcode.awk < lopcodes.h
		# and then pasted into here.
		# Made default access so that code generation, in FuncState, can see
		# the enumeration as well.
		self._OP_MOVE = 0
		self._OP_LOADK = 1
		self._OP_LOADBOOL = 2
		self._OP_LOADNIL = 3
		self._OP_GETUPVAL = 4
		self._OP_GETGLOBAL = 5
		self._OP_GETTABLE = 6
		self._OP_SETGLOBAL = 7
		self._OP_SETUPVAL = 8
		self._OP_SETTABLE = 9
		self._OP_NEWTABLE = 10
		self._OP_SELF = 11
		self._OP_ADD = 12
		self._OP_SUB = 13
		self._OP_MUL = 14
		self._OP_DIV = 15
		self._OP_MOD = 16
		self._OP_POW = 17
		self._OP_UNM = 18
		self._OP_NOT = 19
		self._OP_LEN = 20
		self._OP_CONCAT = 21
		self._OP_JMP = 22
		self._OP_EQ = 23
		self._OP_LT = 24
		self._OP_LE = 25
		self._OP_TEST = 26
		self._OP_TESTSET = 27
		self._OP_CALL = 28
		self._OP_TAILCALL = 29
		self._OP_RETURN = 30
		self._OP_FORLOOP = 31
		self._OP_FORPREP = 32
		self._OP_TFORLOOP = 33
		self._OP_SETLIST = 34
		self._OP_CLOSE = 35
		self._OP_CLOSURE = 36
		self._OP_VARARG = 37
		# end of instruction decomposition
		self._SIZE_C = 9
		self._SIZE_B = 9
		self._SIZE_Bx = self._SIZE_C + self._SIZE_B
		self._SIZE_A = 8
		self._SIZE_OP = 6
		self._POS_OP = 0
		self._POS_A = self._POS_OP + self._SIZE_OP
		self._POS_C = self._POS_A + self._SIZE_A
		self._POS_B = self._POS_C + self._SIZE_C
		self._POS_Bx = self._POS_C
		self._MAXARG_Bx = (1 << self._SIZE_Bx) - 1
		self._MAXARG_sBx = self._MAXARG_Bx >> 1 # `sBx' is signed
		self._MAXARG_A = (1 << self._SIZE_A) - 1
		self._MAXARG_B = (1 << self._SIZE_B) - 1
		self._MAXARG_C = (1 << self._SIZE_C) - 1
		# this bit 1 means constant (0 means register)
		self._BITRK = 1 << (self._SIZE_B - 1)
		self._MAXINDEXRK = self._BITRK - 1
		# <summary>
		# Equivalent of luaD_call. </summary>
		# <param name="func">  absolute stack index of function to call. </param>
		# <param name="r">     number of required results. </param>
		# <summary>
		# Equivalent of luaV_concat. </summary> # number of elements handled in this pass (at least 2) # concat all strings # got n strings to create 1 new # repeat until only 1 result left
		# <summary>
		# Primitive for testing Lua equality of two values.  Equivalent of
		# PUC-Rio's <code>equalobj</code> macro.
		# In the loosest sense, this is the equivalent of
		# <code>luaV_equalval</code>.
		# </summary>
		# Deal with number case first
		# Now we're only concerned with the .r field.
		# <summary>
		# Part of <seealso cref="#vmEqual"/>.  Compares the reference part of two
		# Slot instances.  That is, compares two Lua values, as long as
		# neither is a number.
		# </summary>
		# Same class, but different objects.
		# Resort to metamethods. # no TM? # call TM
		# <summary>
		# Array of numeric operands.  Used when converting strings to numbers
		# by an arithmetic opcode (ADD, SUB, MUL, DIV, MOD, POW, UNM).
		# </summary>
		self._NUMOP = Array.CreateInstance(Double, 2)
		# <summary>
		# The core VM execution engine. </summary>
		# This labelled while loop is used to simulate the effect of C's
		# goto.  The end of the while loop is never reached.  The beginning
		# of the while loop is branched to using a "continue reentry;"
		# statement (when a Lua function is called or returns).
		# assert stack[ci.function()].r instanceof LuaFunction; # main loop of interpreter
		# Where the PUC-Rio code used the Protect macro, this has been
		# replaced with "savedpc = pc" and a "// Protect" comment.
		# Where the PUC-Rio code used the dojump macro, this has been
		# replaced with the equivalent increment of the pc and a
		# "//dojump" comment. # VM instruction.
		# :todo: line hook # did hook yield?
		# base = this.base # its A field.
		# :todo: optimise path
		# assert rb instance of String; # Protect # Protect # Protect
		# :todo: consider inlining objectAt # Protect # Protect
		# All numbers are treated as true, so no need to examine
		# the .d field. # Protect # Protect
		# :todo: The compiler assumes that all
		# stack locations _above_ b end up with junk in them.  In
		# which case we can improve the speed of vmConcat (by not
		# converting each stack slot, but simply using
		# StringBuffer.append on whatever is there).
		# dojump
		# dojump # Protect
		# dojump # Protect
		# dojump
		# dojump
		# dojump
		# Was Java function called by precall, adjust result # yield
		# assert ARGC(i) - 1 == MULTRET
		# tail call: put new frame in place of previous one. # Fresh CallInfo # loop index is used after loop ends
		# move frame down # correct top
		# assert stackSize == base + ((LuaFunction)stack[func]).proto().maxstacksize(); # remove new frame. # It was a Java function # yield
		# 'adjust' replaces aliased 'b' in PUC-Rio code.
		# dojump # internal index # external index # next steps may throw errors
		# dojump # call base # Protect # continue loop
		# dojump
		# :todo: consider expanding space in table
		# assert OPCODE(in) == OP_MOVE;
		# :todo: Protect
		# :todo: check stack # switch # while # reentry: while
		# :todo: this needs proper checking for boundary cases
		# EG, is currently wrong for (-0)^2. # integer only case, save doing unnecessary work # doesn't work if a negative (complex result!)
		# <summary>
		# Equivalent of luaV_gettable. </summary> # 't' is a table?
		# else will try the tag method # else repeat with 'tm'
		# <summary>
		# Equivalent of luaV_lessthan. </summary>
		# :todo: PUC-Rio use strcoll, maybe we should use something
		# equivalent.
		# <summary>
		# Equivalent of luaV_lessequal. </summary> # first try 'le' # else try 'lt'
		# <summary>
		# Equivalent of luaD_poscall. </summary>
		# <param name="firstResult">  stack index (absolute) of the first result </param>
		# :todo: call hook # local copy, for faster access
		# Now (as a result of the dec_ci call), lci is the CallInfo record
		# for the current function (the function executing an OP_RETURN
		# instruction), and this.ci is the CallInfo record for the function
		# we are returning to. # Caution: wanted could be == MULTRET # Continuation CallInfo
		# Move results (and pad with nils to required number if necessary)
		# The movement is always downwards, so copying from the top-most
		# result first is always correct.
		# :todo: consider using two stacksetsize calls to nil out
		# remaining required results.
		# <summary>
		# Equivalent of LuaD_precall.  This method expects that the arguments
		# to the function are placed above the function on the stack. </summary>
		# <param name="func">  absolute stack index of the function to call. </param>
		# <param name="r">     number of results expected. </param> # Function AS Object
		# :todo: ensure enough stack
		# trim stack to the argument list
		# expand stack to the function's max stack size.
		# :todo: implement call hook.
		# :todo: checkstack (not sure it's necessary)
		# :todo: call hook #FIXME: added # yielding?
		# <summary>
		# Equivalent of luaV_settable. </summary> # 't' is a table # result is not nil? # or no TM?
		# else will try the tag method # else repeat with 'tm'
		# <summary>
		# Printf format item used to convert numbers to strings (in {@link
		# #vmTostring}).  The initial '%' should be not specified.
		# </summary>
		self._NUMBER_FMT = ".14g"
		if not self._InstanceFieldsInitialized:
			self.InitializeInstanceFields()
			self._InstanceFieldsInitialized = True
		self._global = LuaTable()
		self._registry = LuaTable()
		self._metatable = Array.CreateInstance(LuaTable, self._NUM_TAGS)
		self._main = self

	def __init__(self):
		self._InstanceFieldsInitialized = False
		self._D = False
		self._VERSION = "Lua 5.1 (Jill 1.0.1)"
		self._RELEASE = "Lua 5.1.4 (Jill 1.0.1)"
		self._VERSION_NUM = 501
		self._COPYRIGHT = "Copyright (C) 1994-2008 Lua.org, PUC-Rio (Copyright (C) 2006 Nokia Corporation and/or its subsidiary(-ies))"
		self._AUTHORS = "R. Ierusalimschy, L. H. de Figueiredo & W. Celes (Ravenbrook Limited)"
		self._stack = Array.CreateInstance(Slot, 0)
		self._civ = metamorphose.java.Stack()
		self._openupval = ArrayList()
		self._allowhook = True
		self._LFIELDS_PER_FLUSH = 50
		self._MAXTAGLOOP = 100
		self._LUA_ERROR = ""
		self._MAXVARS = 200
		self._MAXSTACK = 250
		self._MAXUPVALUES = 60
		self._NUMBER = System.Object()
		self._SPARE_SLOT = Slot()
		self._LOADED = "_LOADED"
		self._MULTRET = -1
		self._NIL = System.Object()
		self._TNONE = -1
		self._TNIL = 0
		self._TBOOLEAN = 1
		self._TNUMBER = 3
		self._TSTRING = 4
		self._TTABLE = 5
		self._TFUNCTION = 6
		self._TUSERDATA = 7
		self._TTHREAD = 8
		self._NUM_TAGS = 9
		self._TYPENAME = Array[str](("nil", "boolean", "userdata", "number", "string", "table", "function", "userdata", "thread"))
		self._MINSTACK = 20
		self._YIELD = 1
		self._ERRRUN = 2
		self._ERRSYNTAX = 3
		self._ERRMEM = 4
		self._ERRERR = 5
		self._ERRFILE = 6
		self._GCSTOP = 0
		self._GCRESTART = 1
		self._GCCOLLECT = 2
		self._GCCOUNT = 3
		self._GCCOUNTB = 4
		self._GCSTEP = 5
		self._GCSETPAUSE = 6
		self._GCSETSTEPMUL = 7
		self._HOOKCALL = 0
		self._HOOKRET = 1
		self._HOOKLINE = 2
		self._HOOKCOUNT = 3
		self._HOOKTAILRET = 4
		self._MASKCALL = 1 << self._HOOKCALL
		self._MASKRET = 1 << self._HOOKRET
		self._MASKLINE = 1 << self._HOOKLINE
		self._MASKCOUNT = 1 << self._HOOKCOUNT
		self._MEMERRMSG = "not enough memory"
		self._IDSIZE = 60
		self._PCRLUA = 0
		self._PCRJ = 1
		self._PCRYIELD = 2
		self._NO_REG = 0xff
		self._OP_MOVE = 0
		self._OP_LOADK = 1
		self._OP_LOADBOOL = 2
		self._OP_LOADNIL = 3
		self._OP_GETUPVAL = 4
		self._OP_GETGLOBAL = 5
		self._OP_GETTABLE = 6
		self._OP_SETGLOBAL = 7
		self._OP_SETUPVAL = 8
		self._OP_SETTABLE = 9
		self._OP_NEWTABLE = 10
		self._OP_SELF = 11
		self._OP_ADD = 12
		self._OP_SUB = 13
		self._OP_MUL = 14
		self._OP_DIV = 15
		self._OP_MOD = 16
		self._OP_POW = 17
		self._OP_UNM = 18
		self._OP_NOT = 19
		self._OP_LEN = 20
		self._OP_CONCAT = 21
		self._OP_JMP = 22
		self._OP_EQ = 23
		self._OP_LT = 24
		self._OP_LE = 25
		self._OP_TEST = 26
		self._OP_TESTSET = 27
		self._OP_CALL = 28
		self._OP_TAILCALL = 29
		self._OP_RETURN = 30
		self._OP_FORLOOP = 31
		self._OP_FORPREP = 32
		self._OP_TFORLOOP = 33
		self._OP_SETLIST = 34
		self._OP_CLOSE = 35
		self._OP_CLOSURE = 36
		self._OP_VARARG = 37
		self._SIZE_C = 9
		self._SIZE_B = 9
		self._SIZE_Bx = self._SIZE_C + self._SIZE_B
		self._SIZE_A = 8
		self._SIZE_OP = 6
		self._POS_OP = 0
		self._POS_A = self._POS_OP + self._SIZE_OP
		self._POS_C = self._POS_A + self._SIZE_A
		self._POS_B = self._POS_C + self._SIZE_C
		self._POS_Bx = self._POS_C
		self._MAXARG_Bx = (1 << self._SIZE_Bx) - 1
		self._MAXARG_sBx = self._MAXARG_Bx >> 1
		self._MAXARG_A = (1 << self._SIZE_A) - 1
		self._MAXARG_B = (1 << self._SIZE_B) - 1
		self._MAXARG_C = (1 << self._SIZE_C) - 1
		self._BITRK = 1 << (self._SIZE_B - 1)
		self._MAXINDEXRK = self._BITRK - 1
		self._NUMOP = Array.CreateInstance(Double, 2)
		self._NUMBER_FMT = ".14g"
		if not self._InstanceFieldsInitialized:
			self.InitializeInstanceFields()
			self._InstanceFieldsInitialized = True
		self._global = LuaTable()
		self._registry = LuaTable()
		self._metatable = Array.CreateInstance(LuaTable, self._NUM_TAGS)
		self._main = self

	def call(self, nargs, nresults):
		self.apiChecknelems(nargs + 1)
		func = self._stackSize - (nargs + 1)
		self.vmCall(func, nresults)

	def close(self):
		pass

	def concat(self, n):
		self.apiChecknelems(n)
		if n >= 2:
			self.vmConcat(n, (self._stackSize - self._base) - 1)
			self.pop(n - 1)
		elif n == 0:
			self.push("")

	def createTable(self, narr, nrec):
		return LuaTable(narr, nrec)

	def dump(function, writer):
		if not ():
			raise IOException("Cannot dump " + Lua.typeName(Lua.type(function)))
		f = function
		Lua.uDump(f.proto(), writer, False)

	dump = staticmethod(dump)

	def equal(self, o1, o2):
		if isinstance(o1, double):
			return o1.Equals(o2)
		return self.vmEqualRef(o1, o2)

	def error(self, message):
		return self.gErrormsg(message)

	def gc(self, what, data):
		if what == self._GCSTOP:
			return 0
		elif what == self._GCRESTART or what == self._GCCOLLECT or what == self._GCSTEP:
			SystemUtil.gc()
			return 0
		elif what == self._GCCOUNT:
			rt = Runtime.getRuntime()
			return ((rt.totalMemory() - rt.freeMemory()) / 1024)
		elif what == self._GCCOUNTB:
			rt = Runtime.getRuntime()
			return ((rt.totalMemory() - rt.freeMemory()) % 1024)
		elif what == self._GCSETPAUSE or what == self._GCSETSTEPMUL:
			return 0
		return 0

	def getFenv(self, o):
		if isinstance(o, LuaFunction):
			f = o
			return f.getEnv()
		if isinstance(o, LuaJavaCallback):
			f = o
			return None
		if isinstance(o, LuaUserdata):
			u = o
			return u.getEnv()
		if isinstance(o, Lua):
			l = o
			return l.global_
		return None

	def getField(self, t, field):
		return self.getTable(t, field)

	def getGlobal(self, name):
		return self.getField(self._global, name)

	def get_Globals(self):
		return self._global

	Globals = property(fget=get_Globals)

	def getMetatable(self, o):
		if isinstance(o, LuaTable):
			t = o
			mt = t.getMetatable()
		elif isinstance(o, LuaUserdata):
			u = o
			mt = u.getMetatable()
		else:
			mt = self._metatable[self.type(o)]
		return mt

	def get_Registry(self):
		return self._registry

	Registry = property(fget=get_Registry)

	def getTable(self, t, k):
		s = Slot(k)
		v = Slot()
		self.vmGettable(t, s, v)
		return v.asObject()

	def get_Top(self):
		return self._stackSize - self._base

	def set_Top(self, value):
		if value < 0:
			raise System.ArgumentException()
		self.stacksetsize(self._base + value)

	Top = property(fget=get_Top, fset=set_Top)

	def insert(self, o, idx):
		idx = self.absIndexUnclamped(idx)
		self.stackInsertAt(o, idx)

	def isBoolean(o):
		return 

	isBoolean = staticmethod(isBoolean)

	def isJavaFunction(o):
		return 

	isJavaFunction = staticmethod(isJavaFunction)

	def isFunction(self, o):
		return isinstance(o, LuaFunction) or isinstance(o, LuaJavaCallback) 

	def get_Main(self):
		return self == self._main

	Main = property(fget=get_Main)

	def isNil(self, o):
		return self._NIL == o

	def isNumber(self, o):
		self._SPARE_SLOT.Object = o
		return self.tonumber(self._SPARE_SLOT, self._NUMOP)

	def isString(self, o):
		return isinstance(o, string) or isinstance(o, double)

	def isTable(self, o):
		return 

	def isThread(o):
		return 

	isThread = staticmethod(isThread)

	def isUserdata(o):
		return 

	isUserdata = staticmethod(isUserdata)

	def isValue(o):
		return o == self._NIL or isinstance(o, bool) or isinstance(o, string) or isinstance(o, double) or isinstance(o, LuaFunction) or isinstance(o, LuaJavaCallback) or isinstance(o, LuaTable) or isinstance(o, LuaUserdata); 

	isValue = staticmethod(isValue)

	def lessThan(self, o1, o2):
		a = Slot(o1)
		b = Slot(o2)
		return self.vmLessthan(a, b)

	def load(self, in_, chunkname):
		self.push(LuaInternal(in_, chunkname))
		return self.pcall(0, 1, None)

	def load(self, in_, chunkname):
		self.push(LuaInternal(in_, chunkname))
		return self.pcall(0, 1, None)

	def next(self, idx):
		o = self.value(idx)
		t = o
		key = self.value(-1)
		self.pop(1)
		e = t.keys()
		if key == self._NIL:
			if e.hasMoreElements():
				key = e.nextElement()
				self.push(key)
				self.push(t.getlua(key))
				return True
			return False
		while e.hasMoreElements():
			k = e.nextElement()
			if k.Equals(key):
				if e.hasMoreElements():
					key = e.nextElement()
					self.push(key)
					self.push(t.getlua(key))
					return True
				return False
		return False

	def newTable(self):
		return LuaTable()

	def newThread(self):
		return Lua(self)

	def newUserdata(self, ref):
		return LuaUserdata(ref)

	def objLen(self, o):
		if isinstance(o, String):
			s = o
			return s.Length
		if isinstance(o, LuaTable):
			t = o
			return t.getn()
		if isinstance(o, double):
			return self.vmTostring(o).Length
		return 0

	def pcall(self, nargs, nresults, ef):
		self.apiChecknelems(nargs + 1)
		restoreStack = self._stackSize - (nargs + 1)
		restoreCi = self._civ.getSize()
		oldnCcalls = self._nCcalls
		old_errfunc = self._errfunc
		self._errfunc = ef
		old_allowhook = self._allowhook
		errorStatus = 0
		try:
			self.call(nargs, nresults)
		except LuaError, e:
			self.fClose(restoreStack)
			self.dSeterrorobj(e.errorStatus, restoreStack)
			self._nCcalls = oldnCcalls
			self._civ.setSize(restoreCi)
			ci = self.__ci()
			self._base = ci.base()
			self._savedpc = ci.savedpc()
			self._allowhook = old_allowhook
			errorStatus = e.errorStatus
		except System.OutOfMemoryException:
			self.fClose(restoreStack)
			self.dSeterrorobj(self._ERRMEM, restoreStack)
			self._nCcalls = oldnCcalls
			self._civ.setSize(restoreCi)
			ci = self.__ci()
			self._base = ci.base()
			self._savedpc = ci.savedpc()
			self._allowhook = old_allowhook
			errorStatus = self._ERRMEM
		finally:
			pass
		self._errfunc = old_errfunc
		return errorStatus

	def pop(self, n):
		if n < 0:
			raise System.ArgumentException()
		self.stacksetsize(self._stackSize - n)

	def push(self, o):
		self.stackAdd(o)

	def pushBoolean(self, b):
		self.push(self.valueOfBoolean(b))

	def pushLiteral(self, s):
		self.push(s)

	def pushNil(self):
		self.push(self._NIL)

	def pushNumber(self, d):
		self.push(System.Nullable[Double](d))

	def pushString(self, s):
		self.push(s)

	def pushValue(self, idx):
		self.push(self.value(idx))

	def rawEqual(self, o1, o2):
		return self.oRawequal(o1, o2)

	def rawGet(self, t, k):
		table = t
		return table.getlua(k)

	def rawGetI(self, t, i):
		table = t
		return table.getnum(i)

	def rawSet(self, t, k, v):
		table = t
		table.putlua(self, k, v)

	def rawSetI(self, t, i, v):
		self.apiCheck()
		h = t
		h.putnum(i, v)

	def register(self, name, f):
		self.setGlobal(name, f)

	def resume(self, narg):
		if self._status_Renamed != self._YIELD:
			if self._status_Renamed != 0:
				return self.resume_error("cannot resume dead coroutine")
			elif self._civ.getSize() != 1:
				return self.resume_error("cannot resume non-suspended coroutine")
		errorStatus = 0
		try:
			firstArg = self._stackSize - narg
			if self._status_Renamed == 0:
				if self.vmPrecall(firstArg - 1, self._MULTRET) != self._PCRLUA:
					pass #goto protectBreak;
			else:
				self._status_Renamed = 0
				if not self.isLua(self.__ci()):
					if self.vmPoscall(firstArg):
						self.stacksetsize(self.__ci().top())
				else:
					self._base = self.__ci().base()
			self.vmExecute(self._civ.getSize() - 1)
		except LuaError, e:
			self._status_Renamed = e.errorStatus
			self.dSeterrorobj(e.errorStatus, self._stackSize)
			self.__ci().Top = self._stackSize
		finally:
			pass
		return self._status_Renamed

	def setFenv(self, o, table):
		t = table
		if isinstance(o, LuaFunction):
			f = o
			f.setEnv(t)
			return True
		if isinstance(o, LuaJavaCallback):
			f = o
			return False
		if isinstance(o, LuaUserdata):
			u = o
			u.setEnv(t)
			return True
		if isinstance(o, Lua):
			l = o
			l.global_ = t
			return True
		return False

	def setField(self, t, name, v):
		s = Slot(name)
		self.vmSettable(t, s, v)

	def setMetatable(self, o, mt):
		if self.isNil(mt):
			mt = None
		else:
			self.apiCheck()
		mtt = mt
		if isinstance(o, LuaTable):
			t = o
			t.setMetatable(mtt)
		elif isinstance(o, LuaUserdata):
			u = o
			u.setMetatable(mtt)
		else:
			self._metatable[self.type(o)] = mtt

	def setGlobal(self, name, value):
		s = Slot(name)
		self.vmSettable(self._global, s, value)

	def setTable(self, t, k, v):
		s = Slot(k)
		self.vmSettable(t, s, v)

	def status(self):
		return self._status_Renamed

	def tableKeys(self, t):
		if not ():
			self.error("table required")
		return (t).keys()

	def toBoolean(self, o):
		return not (o == self._NIL or False.Equals(o))

	def toInteger(self, o):
		return self.toNumber(o)

	def toNumber(self, o):
		self._SPARE_SLOT.Object = o
		if self.tonumber(self._SPARE_SLOT, self._NUMOP):
			return self._NUMOP[0]
		return 0

	def toString(self, o):
		return self.vmTostring(o)

	def toThread(self, o):
		if not ():
			return None
		return o

	def toUserdata(self, o):
		if isinstance(o, LuaUserData):
			return o
		return None

	def type(self, idx):
		idx = self.absIndex(idx)
		if idx < 0:
			return self._TNONE
		return self.type(self._stack[idx])

	def type(self, s):
		if s.r == self._NUMBER:
			return self._TNUMBER
		return self.type(s.r)

	def type(o):
		if o == self._NIL:
			return self._TNIL
		elif isinstance(o, Double):
			return self._TNUMBER
		elif isinstance(o, Boolean):
			return self._TBOOLEAN
		elif isinstance(o, String):
			return self._TSTRING
		elif isinstance(o, LuaTable):
			return self._TTABLE
		elif isinstance(o, LuaFunction) or isinstance(o, LuaJavaCallback):
			return self._TFUNCTION
		elif isinstance(o, LuaUserdata):
			return self._TUSERDATA
		elif isinstance(o, Lua):
			return self._TTHREAD
		return self._TNONE

	type = staticmethod(type)

	def typeName(type):
		if self._TNONE == type:
			return "no value"
		return self._TYPENAME[type]

	typeName = staticmethod(typeName)

	def value(self, idx):
		idx = self.absIndex(idx)
		if idx < 0:
			return self._NIL
		if self._D:
			Console.Error.WriteLine("value:" + idx)
		return self._stack[idx].asObject()

	def valueOfBoolean(b):
		if b:
			return True
		else:
			return False

	valueOfBoolean = staticmethod(valueOfBoolean)

	def valueOfNumber(d):
		return System.Nullable[Double](d)

	valueOfNumber = staticmethod(valueOfNumber)

	def xmove(self, to, n):
		if self == to:
			return 
		self.apiChecknelems(n)
		i = 0
		while i < n:
			to.push(self.value(-n + i))
			i += 1
		self.pop(n)

	def yield_(self, nresults):
		if self._nCcalls > 0:
			self.gRunerror("attempt to yield across metamethod/Java-call boundary")
		self._base = self._stackSize - nresults
		self._status_Renamed = self._YIELD
		return -1

	def absIndex(self, idx):
		s = self._stackSize
		if idx == 0:
			return -1
		if idx > 0:
			if idx + self._base > s:
				return -1
			return self._base + idx - 1
		if s + idx < self._base:
			return -1
		return s + idx

	def absIndexUnclamped(self, idx):
		if idx == 0:
			return -1
		if idx > 0:
			return self._base + idx - 1
		return self._stackSize + idx

	def apiCheck(self, cond):
		if not cond:
			raise System.ArgumentException()

	def apiChecknelems(self, n):
		self.apiCheck(n <= self._stackSize - self._base)

	def argCheck(self, cond, numarg, extramsg):
		if cond:
			return 
		self.argError(numarg, extramsg)

	def argError(self, narg, extramsg):
		return self.error("bad argument " + narg + " (" + extramsg + ")")

	def callMeta(self, obj, event):
		o = self.value(obj)
		ev = self.getMetafield(o, event)
		if ev == self._NIL:
			return False
		self.push(ev)
		self.push(o)
		self.call(1, 1)
		return True

	def checkAny(self, narg):
		if self.type(narg) == self._TNONE:
			self.argError(narg, "value expected")

	def checkInt(self, narg):
		return self.checkNumber(narg)

	def checkNumber(self, narg):
		o = self.value(narg)
		d = self.toNumber(o)
		if d == 0 and not self.isNumber(o):
			self.tagError(narg, self._TNUMBER)
		return d

	def checkOption(self, narg, def_, lst):
		if def_ == None:
			name = self.checkString(narg)
		else:
			name = self.optString(narg, def_)
		i = 0
		while i < lst.Length:
			if lst[i].Equals(name):
				return i
			i += 1
		return self.argError(narg, "invalid option '" + name + "'")

	def checkString(self, narg):
		s = self.toString(self.value(narg))
		if s == None:
			self.tagError(narg, self._TSTRING)
		return s

	def checkType(self, narg, t):
		if self.type(narg) != t:
			self.tagError(narg, t)

	def doString(self, s):
		status = self.load(Lua.stringReader(s), s)
		if status == 0:
			status = self.pcall(0, self._MULTRET, None)
		return status

	def errfile(self, what, fname, e):
		self.push("cannot " + what + " " + fname + ": " + e.ToString())
		return self._ERRFILE

	def findTable(self, t, fname, szhint):
		e = 0
		i = 0
		while e >= 0:
			e = fname.IndexOf('.', i)
			if e < 0:
				part = fname.Substring(i)
			else:
				part = fname.Substring(i, e - i)
			v = self.rawGet(t, part)
			if self.isNil(v):
				v = self.createTable(0, 1 if (e >= 0) else szhint)
				self.setTable(t, part, v)
			elif not self.isTable(v):
				return part
			t = v
			i = e + 1
		self.push(t)
		return None

	def getMetafield(self, o, event):
		mt = self.getMetatable(o)
		if mt == None:
			return self._NIL
		return mt.getlua(event)

	def isNoneOrNil(self, narg):
		return self.type(narg) <= self._TNIL

	def loadFile(self, filename):
		if filename == None:
			raise System.NullReferenceException()
		in_ = SystemUtil.getResourceAsStream(filename)
		if in_ == None:
			return self.errfile("open", filename, IOException())
		status = 0
		try:
			in_.mark(1)
			c = in_.read()
			if c == '#':
				pass
				# :todo: handle this case
			in_.reset()
			status = self.load(in_, "@" + filename)
		except IOException, e:
			return self.errfile("read", filename, e)
		finally:
			pass
		return status

	def loadString(self, s, chunkname):
		return self.load(self.stringReader(s), chunkname)

	def optInt(self, narg, def_):
		if self.isNoneOrNil(narg):
			return def_
		return self.checkInt(narg)

	def optNumber(self, narg, def_):
		if self.isNoneOrNil(narg):
			return def_
		return self.checkNumber(narg)

	def optString(self, narg, def_):
		if self.isNoneOrNil(narg):
			return def_
		return self.checkString(narg)

	def register(self, name):
		self.findTable(self.Registry, self._LOADED, 1)
		loaded = self.value(-1)
		self.pop(1)
		t = self.getField(loaded, name)
		if not self.isTable(t):
			if self.findTable(self.Globals, name, 0) != None:
				self.error("name conflict for module '" + name + "'")
			t = self.value(-1)
			self.pop(1)
			self.setField(loaded, name, t)
		return t

	def tagError(self, narg, tag):
		self.typerror(narg, self.typeName(tag))

	def typeNameOfIndex(self, idx):
		return self._TYPENAME[self.type(idx)]

	def typerror(self, narg, tname):
		self.argError(narg, tname + " expected, got " + self.typeNameOfIndex(narg))

	def where(self, level):
		ar = self.getStack(level)
		if ar != None:
			self.getInfo("Sl", ar)
			if ar.currentline() > 0:
				return ar.shortsrc() + ":" + ar.currentline() + ": "
		return ""

	def stringReader(s):
		return StringReader(s)

	stringReader = staticmethod(stringReader)

	def getInfo(self, what, ar):
		f = None
		callinfo = None
		if ar.ici() > 0:
			callinfo = self._civ.elementAt(ar.ici())
			f = self._stack[callinfo.function()].r
		status = self.auxgetinfo(what, ar, f, callinfo)
		if what.IndexOf('f') >= 0:
			if f == None:
				self.push(self._NIL)
			else:
				self.push(f)
		return status

	def getStack(self, level):
		ici = self._civ.getSize() - 1
		while level > 0 and ici > 0:
			ci = self._civ.elementAt(ici)
			level -= 1
			if self.isLua(ci):
				level -= ci.tailcalls()
			ici -= 1
		if level == 0 and ici > 0:
			return Debug(ici)
		elif level < 0:
			return Debug(0)
		return None

	def setHook(self, func, mask, count):
		if func == None or mask == 0:
			mask = 0
			func = None
		self._hook = func
		self._basehookcount = count
		self.resethookcount()
		self._hookmask = mask

	def auxgetinfo(self, what, ar, f, ci):
		status = True
		if f == None:
			return status
		i = 0
		while i < what.Length:
			if what[i] == 'S':
				self.funcinfo(ar, f)
			elif what[i] == 'l':
				ar.Currentline = self.currentline(ci) if (ci != None) else -1
			elif what[i] == 'f':
				pass
			else:
				status = False
			i += 1
		return status

	def currentline(self, ci):
		pc = self.currentpc(ci)
		if pc < 0:
			return -1
		else:
			faso = self._stack[ci.function()].r
			f = faso
			return f.proto().getline(pc)

	def currentpc(self, ci):
		if not self.isLua(ci):
			return -1
		if ci == self.__ci():
			ci.Savedpc = self._savedpc
		return self.pcRel(ci.savedpc())

	def funcinfo(self, ar, cl):
		if isinstance(cl, LuaJavaCallback):
			ar.Source = "=[Java]"
			ar.Linedefined = -1
			ar.Lastlinedefined = -1
			ar.What = "Java"
		else:
			p = (cl).proto()
			ar.Source = p.source()
			ar.Linedefined = p.linedefined()
			ar.Lastlinedefined = p.lastlinedefined()
			ar.What = "main" if ar.linedefined() == 0 else "Lua"

	def isLua(self, callinfo):
		f = self._stack[callinfo.function()].r
		return 

	def pcRel(pc):
		return pc - 1

	pcRel = staticmethod(pcRel)

	def dCallhook(self, event, line):
		hook = self._hook
		if self._hook != None and self._allowhook:
			top = self._stackSize
			ci_top = self.__ci().top()
			ici = self._civ.getSize() - 1
			if event == self._HOOKTAILRET:
				ici = 0
			ar = Debug(ici)
			ar.Event = event
			ar.Currentline = line
			self.__ci().Top = self._stackSize
			self._allowhook = False
			self._hook.luaHook(self, ar)
			self._allowhook = True
			self.__ci().Top = ci_top
			self.stacksetsize(top)

	def dSeterrorobj(self, errcode, oldtop):
		msg = self.objectAt(self._stackSize - 1)
		if self._stackSize == oldtop:
			self.stacksetsize(oldtop + 1)
		if errcode == self._ERRMEM:
			if self._D:
				Console.Error.WriteLine("dSeterrorobj:" + oldtop)
			self._stack[oldtop].r = self._MEMERRMSG
		elif errcode == self._ERRERR:
			if self._D:
				Console.Error.WriteLine("dSeterrorobj:" + oldtop)
			self._stack[oldtop].r = "error in error handling"
		elif errcode == self._ERRFILE or errcode == self._ERRRUN or errcode == self._ERRSYNTAX:
			self.setObjectAt(msg, oldtop)
		self.stacksetsize(oldtop + 1)

	def dThrow(self, status):
		raise LuaError(status)

	def fClose(self, level):
		i = self._openupval.Count
		while 1:
			i -= 1
			if i < 0:
				break
			uv = self._openupval[i]
			if uv.offset() < level:
				break
			uv.close()
		self._openupval.Capacity = i + 1
		return 

	def fFindupval(self, idx):
		i = self._openupval.Count
		while 1:
			i -= 1
			if i < 0:
				break
			uv2 = self._openupval[i]
			if uv2.offset() == idx:
				return uv2
			if uv2.offset() < idx:
				break
		uv = UpVal(idx, self._stack[idx])
		self._openupval.Insert(i + 1, uv)
		return uv

	def gAritherror(self, p1, p2):
		if not self.tonumber(p1, self._NUMOP):
			p2 = p1
		self.gTypeerror(p2, "perform arithmetic on")

	def gConcaterror(self, p1, p2):
		if isinstance(stack[p1].r, String):
			p1 = p2
		self.gTypeerror(self._stack[p1], "concatenate")

	def gCheckcode(self, p):
		return True

	def gErrormsg(self, message):
		self.push(message)
		if self._errfunc != None:
			if not self.isFunction(self._errfunc):
				self.dThrow(self._ERRERR)
			self.insert(self._errfunc, self.Top)
			self.vmCall(self._stackSize - 2, 1)
		self.dThrow(self._ERRRUN)
		return 0

	def gOrdererror(self, p1, p2):
		t1 = self.typeName(self.type(p1))
		t2 = self.typeName(self.type(p2))
		if t1[2] == t2[2]:
			self.gRunerror("attempt to compare two " + t1 + "values")
		else:
			self.gRunerror("attempt to compare " + t1 + " with " + t2)
		return False

	def gRunerror(self, s):
		self.gErrormsg(s)

	def gTypeerror(self, o, op):
		t = self.typeName(self.type(o))
		self.gRunerror("attempt to " + op + " a " + t + " value")

	def gTypeerror(self, p, op):
		self.gTypeerror(p.asObject(), op)

	def oChunkid(source):
		len = self._IDSIZE
		if source.StartsWith("="):
			if source.Length < self._IDSIZE + 1:
				return source.Substring(1)
			else:
				return source.Substring(1, len)
		if source.StartsWith("@"):
			source = source.Substring(1)
			len -= " '...' ".Length
			l2 = source.Length
			if l2 > len:
				return "..." + source.Substring(source.Length - len, source.Length - (source.Length - len))
			return source
		l = source.IndexOf('\n')
		if l == -1:
			l = source.Length
		len -= " [string \"...\"] ".Length
		if l > len:
			l = len
		buf = StringBuilder()
		buf.Append("[string \"")
		buf.Append(source.Substring(0, l))
		if source.Length > l:
			buf.Append("...")
		buf.Append("\"]")
		return buf.ToString()

	oChunkid = staticmethod(oChunkid)

	def oFb2int(x):
		e = ((x >> 3)) & 31
		if e == 0:
			return x
		return ((x & 7) + 8) << (e - 1)

	oFb2int = staticmethod(oFb2int)

	def oRawequal(a, b):
		if self._NIL == a:
			return self._NIL == b
		return a.Equals(b)

	oRawequal = staticmethod(oRawequal)

	def oStr2d(s, out):
		try:
			out[0] = Convert.ToDouble(s)
			return True
		except NumberFormatException:
			try:
				s = s.Trim().ToUpper()
				if s.StartsWith("0X"):
					s = s.Substring(2)
				elif s.StartsWith("-0X"):
					s = "-" + s.Substring(3)
				else:
					return False
				out[0] = Convert.ToInt32(s, 16)
				return True
			except NumberFormatException:
				return False
			finally:
				pass
		finally:
			pass

	oStr2d = staticmethod(oStr2d)

	def OPCODE(instruction):
		return instruction & 0x3f

	OPCODE = staticmethod(OPCODE)

	def SET_OPCODE(i, op):
		return (i & ~0x3F) | (op & 0x3F)

	SET_OPCODE = staticmethod(SET_OPCODE)

	def ARGA(instruction):
		return ((instruction >> 6)) & 0xff

	ARGA = staticmethod(ARGA)

	def SETARG_A(i, u):
		return (i & ~(0xff << 6)) | ((u & 0xff) << 6)

	SETARG_A = staticmethod(SETARG_A)

	def ARGB(instruction):
		return ((instruction >> 23))

	ARGB = staticmethod(ARGB)

	def SETARG_B(i, b):
		return (i & ~(0x1ff << 23)) | ((b & 0x1ff) << 23)

	SETARG_B = staticmethod(SETARG_B)

	def ARGC(instruction):
		return ((instruction >> 14)) & 0x1ff

	ARGC = staticmethod(ARGC)

	def SETARG_C(i, c):
		return (i & ~(0x1ff << 14)) | ((c & 0x1ff) << 14)

	SETARG_C = staticmethod(SETARG_C)

	def ARGBx(instruction):
		return ((instruction >> 14))

	ARGBx = staticmethod(ARGBx)

	def SETARG_Bx(i, bx):
		return (i & 0x3fff) | (bx << 14)

	SETARG_Bx = staticmethod(SETARG_Bx)

	def ARGsBx(instruction):
		return ((instruction >> 14)) - self._MAXARG_sBx

	ARGsBx = staticmethod(ARGsBx)

	def SETARG_sBx(i, bx):
		return (i & 0x3fff) | ((bx + self._MAXARG_sBx) << 14)

	SETARG_sBx = staticmethod(SETARG_sBx)

	def ISK(field):
		return field >= 0x100

	ISK = staticmethod(ISK)

	def RK(self, k, field):
		if self.ISK(field):
			if self._D:
				Console.Error.WriteLine("RK:" + field)
			return k[field & 0xff]
		if self._D:
			Console.Error.WriteLine("RK:" + (self._base + field))
		return self._stack[self._base + field]

	def RK(self, field):
		function = self._stack[self.__ci().function()].r
		k = function.proto().constant()
		return self.RK(k, field)

	def CREATE_ABC(o, a, b, c):
		return o | (a << 6) | (b << 23) | (c << 14)

	CREATE_ABC = staticmethod(CREATE_ABC)

	def CREATE_ABx(o, a, bc):
		return o | (a << 6) | (bc << 14)

	CREATE_ABx = staticmethod(CREATE_ABx)

	def vmCall(self, func, r):
		self._nCcalls += 1
		if self.vmPrecall(func, r) == self._PCRLUA:
			self.vmExecute(1)
		self._nCcalls -= 1

	def vmConcat(self, total, last):
		while total > 1:
			top = self._base + last + 1
			n = 2
			if not self.tostring(top - 2) or not self.tostring(top - 1):
				if self._D:
					Console.Error.WriteLine("vmConcat:" + (top - 2) + "," + (top - 1))
				if not self.call_binTM(self._stack[top - 2], self._stack[top - 1], self._stack[top - 2], "__concat"):
					self.gConcaterror(top - 2, top - 1)
			elif (self._stack[top - 1].r).Length > 0:
				tl = (self._stack[top - 1].r).Length
				n = 1
				while n < total and self.tostring(top - n - 1):
					tl += (self._stack[top - n - 1].r).Length
					if tl < 0:
						self.gRunerror("string length overflow")
					n += 1
				buffer = StringBuilder(tl)
				i = n
				while i > 0:
					buffer.Append(self._stack[top - i].r)
					i -= 1
				self._stack[top - n].r = buffer.ToString()
			total -= n - 1
			last -= n - 1

	def vmEqual(self, a, b):
		if self._NUMBER == a.r:
			if self._NUMBER != b.r:
				return False
			return a.d == b.d
		return self.vmEqualRef(a.r, b.r)

	def vmEqualRef(self, a, b):
		if a.Equals(b):
			return True
		if a.GetType() != b.GetType():
			return False
		if isinstance(a, LuaJavaCallback) or isinstance(a, LuaTable):
			tm = self.get_compTM(self.getMetatable(a), self.getMetatable(b), "__eq")
			if self._NIL == tm:
				return False
			s = Slot()
			self.callTMres(s, tm, a, b)
			return not self.isFalse(s.r)
		return False

	def vmExecute(self, nexeccalls):
		while True:
			function = self._stack[self.__ci().function()].r
			proto = function.proto()
			code = proto.code()
			k = proto.constant()
			pc = self._savedpc
			while True:
				i = code[pc]
				pc += 1
				if (self._hookmask & self._MASKCOUNT) != 0:
					self._hookcount -= 1
					if self._hookcount == 0:
						self.traceexec(pc)
						if self._status_Renamed == self._YIELD:
							self._savedpc = pc - 1
							return 
				a = self.ARGA(i)
				if self.OPCODE(i) == self._OP_MOVE:
					self._stack[self._base + a].r = self._stack[self._base + self.ARGB(i)].r
					self._stack[self._base + a].d = self._stack[self._base + self.ARGB(i)].d
					continue
				elif self.OPCODE(i) == self._OP_LOADK:
					self._stack[self._base + a].r = k[self.ARGBx(i)].r
					self._stack[self._base + a].d = k[self.ARGBx(i)].d
					continue
				elif self.OPCODE(i) == self._OP_LOADBOOL:
					self._stack[self._base + a].r = self.valueOfBoolean(self.ARGB(i) != 0)
					if self.ARGC(i) != 0:
						pc += 1
					continue
				elif self.OPCODE(i) == self._OP_LOADNIL:
					b = self._base + self.ARGB(i)
					while b >= self._base + a:
						self._stack[b].r = self._NIL
						b -= 1
					continue
				elif self.OPCODE(i) == self._OP_GETUPVAL:
					b = self.ARGB(i)
					self.setObjectAt(function.upVal(b).Value, self._base + a)
					continue
				elif self.OPCODE(i) == self._OP_GETGLOBAL:
					rb = k[self.ARGBx(i)]
					self._savedpc = pc
					self.vmGettable(function.getEnv(), rb, self._stack[self._base + a])
					continue
				elif self.OPCODE(i) == self._OP_GETTABLE:
					self._savedpc = pc
					h = self._stack[self._base + self.ARGB(i)].asObject()
					if self._D:
						Console.Error.WriteLine("OP_GETTABLE index = " + (self._base + self.ARGB(i)) + ", size = " + self._stack.Length + ", h = " + h)
					self.vmGettable(h, self.RK(k, self.ARGC(i)), self._stack[self._base + a])
					continue
				elif self.OPCODE(i) == self._OP_SETUPVAL:
					uv = function.upVal(self.ARGB(i))
					uv.Value = self.objectAt(self._base + a)
					continue
				elif self.OPCODE(i) == self._OP_SETGLOBAL:
					self._savedpc = pc
					self.vmSettable(function.getEnv(), k[self.ARGBx(i)], self.objectAt(self._base + a))
					continue
				elif self.OPCODE(i) == self._OP_SETTABLE:
					self._savedpc = pc
					t = self._stack[self._base + a].asObject()
					self.vmSettable(t, self.RK(k, self.ARGB(i)), self.RK(k, self.ARGC(i)).asObject())
					continue
				elif self.OPCODE(i) == self._OP_NEWTABLE:
					b = self.ARGB(i)
					c = self.ARGC(i)
					self._stack[self._base + a].r = LuaTable(self.oFb2int(b), self.oFb2int(c))
					continue
				elif self.OPCODE(i) == self._OP_SELF:
					b = self.ARGB(i)
					rb = self._stack[self._base + b]
					self._stack[self._base + a + 1].r = rb.r
					self._stack[self._base + a + 1].d = rb.d
					self._savedpc = pc
					self.vmGettable(rb.asObject(), self.RK(k, self.ARGC(i)), self._stack[self._base + a])
					continue
				elif self.OPCODE(i) == self._OP_ADD:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						sum = rb.d + rc.d
						self._stack[self._base + a].d = sum
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						sum = self._NUMOP[0] + self._NUMOP[1]
						self._stack[self._base + a].d = sum
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__add"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_SUB:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						difference = rb.d - rc.d
						self._stack[self._base + a].d = difference
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						difference = self._NUMOP[0] - self._NUMOP[1]
						self._stack[self._base + a].d = difference
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__sub"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_MUL:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						product = rb.d * rc.d
						self._stack[self._base + a].d = product
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						product = self._NUMOP[0] * self._NUMOP[1]
						self._stack[self._base + a].d = product
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__mul"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_DIV:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						quotient = rb.d / rc.d
						self._stack[self._base + a].d = quotient
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						quotient = self._NUMOP[0] / self._NUMOP[1]
						self._stack[self._base + a].d = quotient
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__div"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_MOD:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						modulus = Lua.modulus(rb.d, rc.d)
						self._stack[self._base + a].d = modulus
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						modulus = Lua.modulus(self._NUMOP[0], self._NUMOP[1])
						self._stack[self._base + a].d = modulus
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__mod"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_POW:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if rb.r == self._NUMBER and rc.r == self._NUMBER:
						result = self.iNumpow(rb.d, rc.d)
						self._stack[self._base + a].d = result
						self._stack[self._base + a].r = self._NUMBER
					elif self.toNumberPair(rb, rc, self._NUMOP):
						result = self.iNumpow(self._NUMOP[0], self._NUMOP[1])
						self._stack[self._base + a].d = result
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rc, self._stack[self._base + a], "__pow"):
						self.gAritherror(rb, rc)
					continue
				elif self.OPCODE(i) == self._OP_UNM:
					rb = self._stack[self._base + self.ARGB(i)]
					if rb.r == self._NUMBER:
						self._stack[self._base + a].d = -rb.d
						self._stack[self._base + a].r = self._NUMBER
					elif self.tonumber(rb, self._NUMOP):
						self._stack[self._base + a].d = -self._NUMOP[0]
						self._stack[self._base + a].r = self._NUMBER
					elif not self.call_binTM(rb, rb, self._stack[self._base + a], "__unm"):
						self.gAritherror(rb, rb)
					continue
				elif self.OPCODE(i) == self._OP_NOT:
					ra = self._stack[self._base + self.ARGB(i)].r
					self._stack[self._base + a].r = self.valueOfBoolean(self.isFalse(ra))
					continue
				elif self.OPCODE(i) == self._OP_LEN:
					rb = self._stack[self._base + self.ARGB(i)]
					if isinstance(rb.r, LuaTable):
						t = rb.r
						self._stack[self._base + a].d = t.getn()
						self._stack[self._base + a].r = self._NUMBER
						continue
					elif isinstance(rb.r, String):
						s = rb.r
						self._stack[self._base + a].d = s.Length
						self._stack[self._base + a].r = self._NUMBER
						continue
					self._savedpc = pc
					if not self.call_binTM(rb, rb, self._stack[self._base + a], "__len"):
						self.gTypeerror(rb, "get length of")
					continue
				elif self.OPCODE(i) == self._OP_CONCAT:
					b = self.ARGB(i)
					c = self.ARGC(i)
					self._savedpc = pc
					self.vmConcat(c - b + 1, c)
					self._stack[self._base + a].r = self._stack[self._base + b].r
					self._stack[self._base + a].d = self._stack[self._base + b].d
					continue
				elif self.OPCODE(i) == self._OP_JMP:
					pc += self.ARGsBx(i)
					continue
				elif self.OPCODE(i) == self._OP_EQ:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					if self.vmEqual(rb, rc) == (a != 0):
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_LT:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					self._savedpc = pc
					if self.vmLessthan(rb, rc) == (a != 0):
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_LE:
					rb = self.RK(k, self.ARGB(i))
					rc = self.RK(k, self.ARGC(i))
					self._savedpc = pc
					if self.vmLessequal(rb, rc) == (a != 0):
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_TEST:
					if self.isFalse(self._stack[self._base + a].r) != (self.ARGC(i) != 0):
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_TESTSET:
					rb = self._stack[self._base + self.ARGB(i)]
					if self.isFalse(rb.r) != (self.ARGC(i) != 0):
						self._stack[self._base + a].r = rb.r
						self._stack[self._base + a].d = rb.d
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_CALL:
					b = self.ARGB(i)
					nresults = self.ARGC(i) - 1
					if b != 0:
						self.stacksetsize(self._base + a + b)
					self._savedpc = pc
					if self.vmPrecall(self._base + a, nresults) == self._PCRLUA:
						nexeccalls += 1
					elif self.vmPrecall(self._base + a, nresults) == self._PCRJ:
						if nresults >= 0:
							self.stacksetsize(self.__ci().top())
						continue
					else:
						return 
				elif self.OPCODE(i) == self._OP_TAILCALL:
					b = self.ARGB(i)
					if b != 0:
						self.stacksetsize(self._base + a + b)
					self._savedpc = pc
					if self.vmPrecall(self._base + a, self._MULTRET) == self._PCRLUA:
						ci = self._civ.elementAt(self._civ.getSize() - 2)
						func = ci.function()
						fci = self.__ci()
						pfunc = fci.function()
						self.fClose(ci.base())
						self._base = func + (fci.base() - pfunc)
						aux = 0
						while pfunc + aux < self._stackSize:
							self._stack[func + aux].r = self._stack[pfunc + aux].r
							self._stack[func + aux].d = self._stack[pfunc + aux].d
							aux += 1
						self.stacksetsize(func + aux)
						ci.tailcall(self._base, self._stackSize)
						self.dec_ci()
					elif self.vmPrecall(self._base + a, self._MULTRET) == self._PCRJ:
						continue
					else:
						return 
				elif self.OPCODE(i) == self._OP_RETURN:
					self.fClose(self._base)
					b = self.ARGB(i)
					if b != 0:
						top = a + b - 1
						self.stacksetsize(self._base + top)
					self._savedpc = pc
					adjust = self.vmPoscall(self._base + a)
					nexeccalls -= 1
					if nexeccalls == 0:
						return 
					if adjust:
						self.stacksetsize(self.__ci().top())
				elif self.OPCODE(i) == self._OP_FORLOOP:
					step = self._stack[self._base + a + 2].d
					idx = self._stack[self._base + a].d + step
					limit = self._stack[self._base + a + 1].d
					if (0 < step and idx <= limit) or (step <= 0 and limit <= idx):
						pc += self.ARGsBx(i)
						self._stack[self._base + a].d = idx
						self._stack[self._base + a].r = self._NUMBER
						self._stack[self._base + a + 3].d = idx
						self._stack[self._base + a + 3].r = self._NUMBER
					continue
				elif self.OPCODE(i) == self._OP_FORPREP:
					init = self._base + a
					plimit = self._base + a + 1
					pstep = self._base + a + 2
					self._savedpc = pc
					if not self.tonumber(init):
						self.gRunerror("'for' initial value must be a number")
					elif not self.tonumber(plimit):
						self.gRunerror("'for' limit must be a number")
					elif not self.tonumber(pstep):
						self.gRunerror("'for' step must be a number")
					step = self._stack[pstep].d
					idx = self._stack[init].d - step
					self._stack[init].d = idx
					self._stack[init].r = self._NUMBER
					pc += self.ARGsBx(i)
					continue
				elif self.OPCODE(i) == self._OP_TFORLOOP:
					cb = self._base + a + 3
					self._stack[cb + 2].r = self._stack[self._base + a + 2].r
					self._stack[cb + 2].d = self._stack[self._base + a + 2].d
					self._stack[cb + 1].r = self._stack[self._base + a + 1].r
					self._stack[cb + 1].d = self._stack[self._base + a + 1].d
					self._stack[cb].r = self._stack[self._base + a].r
					self._stack[cb].d = self._stack[self._base + a].d
					self.stacksetsize(cb + 3)
					self._savedpc = pc
					self.vmCall(cb, self.ARGC(i))
					self.stacksetsize(self.__ci().top())
					if self._NIL != self._stack[cb].r:
						self._stack[cb - 1].r = self._stack[cb].r
						self._stack[cb - 1].d = self._stack[cb].d
						pc += self.ARGsBx(code[pc])
					pc += 1
					continue
				elif self.OPCODE(i) == self._OP_SETLIST:
					n = self.ARGB(i)
					c = self.ARGC(i)
					setstack = False
					if 0 == n:
						n = (self._stackSize - (self._base + a)) - 1
						setstack = True
					if 0 == c:
						c = code[pc]
						pc += 1
					t = self._stack[self._base + a].r
					last = ((c - 1) * self._LFIELDS_PER_FLUSH) + n
					while n > 0:
						val = self.objectAt(self._base + a + n)
						t.putnum(last, val)
						last -= 1
						n -= 1
					if setstack:
						self.stacksetsize(self.__ci().top())
					continue
				elif self.OPCODE(i) == self._OP_CLOSE:
					self.fClose(self._base + a)
					continue
				elif self.OPCODE(i) == self._OP_CLOSURE:
					p = function.proto().proto()[self.ARGBx(i)]
					nup = p.nups()
					up = Array.CreateInstance(UpVal, nup)
					j = 0
					while j < nup:
						in_ = code[pc]
						if self.OPCODE(in_) == self._OP_GETUPVAL:
							up[j] = function.upVal(self.ARGB(in_))
						else:
							up[j] = self.fFindupval(self._base + self.ARGB(in_))
						j += 1
						pc += 1
					nf = LuaFunction(p, up, function.getEnv())
					self._stack[self._base + a].r = nf
					continue
				elif self.OPCODE(i) == self._OP_VARARG:
					b = self.ARGB(i) - 1
					n = (self._base - self.__ci().function()) - function.proto().numparams() - 1
					if b == self._MULTRET:
						b = n
						self.stacksetsize(self._base + a + n)
					j = 0
					while j < b:
						if j < n:
							src = self._stack[self._base - n + j]
							self._stack[self._base + a + j].r = src.r
							self._stack[self._base + a + j].d = src.d
						else:
							self._stack[self._base + a + j].r = self._NIL
						j += 1
					continue

	def iNumpow(a, b):
		invert = b < 0.0
		if invert:
			b = -b
		if a == 0.0:
			return Double.NaN if invert else a
		result = 1.0
		ipow = b
		b -= ipow
		t = a
		while ipow > 0:
			if (ipow & 1) != 0:
				result *= t
			ipow >>= 1
			t = t * t
		if b != 0.0:
			if a < 0.0:
				return Double.NaN
			t = Math.Sqrt(a)
			half = 0.5
			while b > 0.0:
				if b >= half:
					result = result * t
					b -= half
				b = b + b
				t = Math.Sqrt(t)
				if t == 1.0:
					break
		return 1.0 / result if invert else result

	iNumpow = staticmethod(iNumpow)

	def vmGettable(self, t, key, val):
		loop = 0
		while loop < self._MAXTAGLOOP:
			if isinstance(t, LuaTable):
				h = t
				h.getlua(key, self._SPARE_SLOT)
				if self._SPARE_SLOT.r != self._NIL:
					val.r = self._SPARE_SLOT.r
					val.d = self._SPARE_SLOT.d
					return 
				tm = self.tagmethod(h, "__index")
				if tm == self._NIL:
					val.r = self._NIL
					return 
			else:
				tm = self.tagmethod(t, "__index")
				if tm == self._NIL:
					self.gTypeerror(t, "index")
			if self.isFunction(tm):
				self._SPARE_SLOT.Object = t
				self.callTMres(val, tm, self._SPARE_SLOT, key)
				return 
			t = tm
			loop += 1
		self.gRunerror("loop in gettable")

	def vmLessthan(self, l, r):
		if l.r.GetType() != r.r.GetType():
			self.gOrdererror(l, r)
		elif l.r == self._NUMBER:
			return l.d < r.d
		elif isinstance(l.r, String):
			return (l.r).CompareTo(r.r) < 0
		res = self.call_orderTM(l, r, "__lt")
		if res >= 0:
			return res != 0
		return self.gOrdererror(l, r)

	def vmLessequal(self, l, r):
		if l.r.GetType() != r.r.GetType():
			self.gOrdererror(l, r)
		elif l.r == self._NUMBER:
			return l.d <= r.d
		elif isinstance(l.r, String):
			return (l.r).CompareTo(r.r) <= 0
		res = self.call_orderTM(l, r, "__le")
		if res >= 0:
			return res != 0
		res = self.call_orderTM(r, l, "__lt")
		if res >= 0:
			return res == 0
		return self.gOrdererror(l, r)

	def vmPoscall(self, firstResult):
		lci = self.dec_ci()
		res = lci.res()
		wanted = lci.nresults()
		cci = self.__ci()
		self._base = cci.base()
		self._savedpc = cci.savedpc()
		i = wanted
		top = self._stackSize
		while i != 0 and firstResult < top:
			if self._D:
				Console.Error.WriteLine("vmPoscall:" + res)
			self._stack[res].r = self._stack[firstResult].r
			self._stack[res].d = self._stack[firstResult].d
			res += 1
			firstResult += 1
			i -= 1
		if i > 0:
			self.stacksetsize(res + i)
		while i > 0:
			i -= 1
			self._stack[res].r = self._NIL
			res += 1
		self.stacksetsize(res)
		return wanted != self._MULTRET

	def vmPrecall(self, func, r):
		if self._D:
			Console.Error.WriteLine("vmPrecall:" + func)
		faso = self._stack[func].r
		if not self.isFunction(faso):
			faso = self.tryfuncTM(func)
		self.__ci().Savedpc = self._savedpc
		if isinstance(faso, LuaFunction):
			f = faso
			p = f.proto()
			if not p.Vararg:
				self._base = func + 1
				if self._stackSize > self._base + p.numparams():
					self.stacksetsize(self._base + p.numparams())
			else:
				nargs = (self._stackSize - func) - 1
				self._base = self.adjust_varargs(p, nargs)
			top = self._base + p.maxstacksize()
			self.inc_ci(func, self._base, top, r)
			self._savedpc = 0
			self.stacksetsize(top)
			return self._PCRLUA
		elif isinstance(faso, LuaJavaCallback):
			fj = faso
			self._base = func + 1
			self.inc_ci(func, self._base, self._stackSize + self._MINSTACK, r)
			n = 99
			try:
				n = fj.luaFunction(self)
			except LuaError, e:
				raise e
			except Exception, e:
				Console.WriteLine(e.ToString())
				Console.Write(e.StackTrace)
				self.yield_(0)
				raise e
			finally:
				pass
			if n < 0:
				return self._PCRYIELD
			else:
				self.vmPoscall(self._stackSize - n)
				return self._PCRJ
		raise System.ArgumentException()

	def vmSettable(self, t, key, val):
		loop = 0
		while loop < self._MAXTAGLOOP:
			if isinstance(t, LuaTable):
				h = t
				h.getlua(key, self._SPARE_SLOT)
				if self._SPARE_SLOT.r != self._NIL:
					h.putlua(self, key, val)
					return 
				tm = self.tagmethod(h, "__newindex")
				if tm == self._NIL:
					h.putlua(self, key, val)
					return 
			else:
				tm = self.tagmethod(t, "__newindex")
				if tm == self._NIL:
					self.gTypeerror(t, "index")
			if self.isFunction(tm):
				self.callTM(tm, t, key, val)
				return 
			t = tm
			loop += 1
		self.gRunerror("loop in settable")

	def vmTostring(o):
		if isinstance(o, String):
			return o
		if not ():
			return None
		# Convert number to string.  PUC-Rio abstracts this operation into
		# a macro, lua_number2str.  The macro is only invoked from their
		# equivalent of this code.
		# Formerly this code used Double.toString (and remove any trailing
		# ".0") but this does not give an accurate emulation of the PUC-Rio
		# behaviour which Intuwave require.  So now we use "%.14g" like
		# PUC-Rio.
		# :todo: consider optimisation of making FormatItem an immutable
		# class and keeping a static reference to the required instance
		# (which never changes).  A possible half-way house would be to
		# create a copied instance from an already create prototype
		# instance which would be faster than parsing the format string
		# each time.
		f = FormatItem(None, self._NUMBER_FMT)
		b = StringBuilder()
		d = o
		f.formatFloat(b, d)
		return b.ToString()

	vmTostring = staticmethod(vmTostring)

	def adjust_varargs(self, p, actual):
		""" <summary>
		 Equivalent of adjust_varargs in "ldo.c". </summary>
		"""
		nfixargs = p.numparams()
		while actual < nfixargs:
			self.stackAdd(self._NIL)
			actual += 1
		# PUC-Rio's LUA_COMPAT_VARARG is not supported here.
		# Move fixed parameters to final position
		fixed = self._stackSize - actual # first fixed argument
		newbase = self._stackSize # final position of first argument
		i = 0
		while i < nfixargs:
			# :todo: arraycopy?
			self.push(self._stack[fixed + i])
			self._stack[fixed + i].r = self._NIL
			i += 1
		return newbase

	def call_binTM(self, p1, p2, res, event):
		""" <summary>
		 Does not modify contents of p1 or p2.  Modifies contents of res. </summary>
		 <param name="p1">  left hand operand. </param>
		 <param name="p2">  right hand operand. </param>
		 <param name="res"> absolute stack index of result. </param>
		 <returns> false if no tagmethod, true otherwise </returns>
		"""
		tm = self.tagmethod(p1.asObject(), event) # try first operand
		if self.isNil(tm):
			tm = self.tagmethod(p2.asObject(), event) # try second operand
		if not self.isFunction(tm):
			return False
		self.callTMres(res, tm, p1, p2)
		return True

	def call_orderTM(self, p1, p2, event):
		""" <returns> -1 if no tagmethod, 0 false, 1 true </returns>"""
		tm1 = self.tagmethod(p1.asObject(), event)
		if tm1 == self._NIL: # not metamethod
			return -1
		tm2 = self.tagmethod(p2.asObject(), event)
		if not self.oRawequal(tm1, tm2): # different metamethods?
			return -1
		s = Slot()
		self.callTMres(s, tm1, p1, p2)
		return 0 if self.isFalse(s.r) else 1

	def callTM(self, f, p1, p2, p3):
		self.push(f)
		self.push(p1)
		self.push(p2)
		self.push(p3)
		self.vmCall(self._stackSize - 4, 0)

	def callTMres(self, res, f, p1, p2):
		self.push(f)
		self.push(p1)
		self.push(p2)
		self.vmCall(self._stackSize - 3, 1)
		if self._D:
			Console.Error.WriteLine("callTMres:" + (self._stackSize - 1))
		res.r = self._stack[self._stackSize - 1].r
		res.d = self._stack[self._stackSize - 1].d
		self.pop(1)

	def callTMres(self, res, f, p1, p2):
		""" <summary>
		 Overloaded version of callTMres used by <seealso cref="#vmEqualRef"/>.
		 Textuall identical, but a different (overloaded) push method is
		 invoked.
		 </summary>
		"""
		self.push(f)
		self.push(p1)
		self.push(p2)
		self.vmCall(self._stackSize - 3, 1)
		if self._D:
			Console.Error.WriteLine("callTMres" + (self._stackSize - 1))
		res.r = self._stack[self._stackSize - 1].r
		res.d = self._stack[self._stackSize - 1].d
		self.pop(1)

	def get_compTM(self, mt1, mt2, event):
		if mt1 == None:
			return self._NIL
		tm1 = mt1.getlua(event)
		if self.isNil(tm1):
			return self._NIL # no metamethod
		if mt1 == mt2:
			return tm1 # same metatables => same metamethods
		if mt2 == None:
			return self._NIL
		tm2 = mt2.getlua(event)
		if self.isNil(tm2):
			return self._NIL # no metamethod
		if self.oRawequal(tm1, tm2): # same metamethods?
			return tm1
		return self._NIL

	def tagmethod(self, o, event):
		""" <summary>
		 Gets tagmethod for object. </summary>
		 <returns> method or nil. </returns>
		"""
		return self.getMetafield(o, event)

	def tagmethod(self, o, event):
		""" @deprecated DO NOT CALL """
		raise System.ArgumentException("tagmethod called")

	def modulus(x, y):
		""" <summary>
		 Computes the result of Lua's modules operator (%).  Note that this
		 modulus operator does not match Java's %.
		 </summary>
		"""
		return x - Math.Floor(x / y) * y

	modulus = staticmethod(modulus)

	def stacksetsize(self, n):
		""" <summary>
		 Changes the stack size, padding with NIL where necessary, and
		 allocate a new stack array if necessary.
		 </summary>
		"""
		if n == 3:
			if self._D:
				Console.Error.WriteLine("stacksetsize:" + n)
		# It is absolutely critical that when the stack changes sizes those
		# elements that are common to both old and new stack are unchanged.
		# First implementation of this simply ensures that the stack array
		# has at least the required size number of elements.
		# :todo: consider policies where the stack may also shrink.
		old = self._stackSize
		if n > self._stack.Length:
			newLength = Math.Max(n, 2 * self._stack.Length)
			newStack = Array.CreateInstance(Slot, newLength)
			# Currently the stack only ever grows, so the number of items to
			# copy is the length of the old stack.
			toCopy = self._stack.Length
			Array.Copy(self._stack, 0, newStack, 0, toCopy)
			self._stack = newStack
		self._stackSize = n
		# Nilling out.  The VM requires that fresh stack slots allocated
		# for a new function activation are initialised to nil (which is
		# Lua.NIL, which is not Java null).
		# There are basically two approaches: nil out when the stack grows,
		# or nil out when it shrinks.  Nilling out when the stack grows is
		# slightly simpler, but nilling out when the stack shrinks means
		# that semantic garbage is not retained by the GC.
		# We nil out slots when the stack shrinks, but we also need to make
		# sure they are nil initially.
		# In order to avoid nilling the entire array when we allocate one
		# we maintain a stackhighwater which is 1 more than that largest
		# stack slot that has been nilled.  We use this to nil out stacks
		# slow when we grow.
		if n <= old:
			# when shrinking
			i = n
			while i < old:
				self._stack[i].r = self._NIL
				i += 1
		if n > self._stackhighwater:
			# when growing above stackhighwater for the first time
			i = self._stackhighwater
			while i < n:
				self._stack[i] = Slot()
				self._stack[i].r = self._NIL
				i += 1
			self._stackhighwater = n

	def stackAdd(self, o):
		""" <summary>
		 Pushes a Lua value onto the stack.
		 </summary>
		"""
		i = self._stackSize
		self.stacksetsize(i + 1)
		if self._D:
			Console.Error.WriteLine("stackAdd:" + i)
		self._stack[i].Object = o

	def push(self, p):
		""" <summary>
		 Copies a slot into a new space in the stack.
		 </summary>
		"""
		i = self._stackSize
		self.stacksetsize(i + 1)
		if self._D:
			Console.Error.WriteLine("push:" + i)
		self._stack[i].r = p.r
		self._stack[i].d = p.d

	def stackInsertAt(self, o, i):
		n = self._stackSize - i
		self.stacksetsize(self._stackSize + 1)
		# Copy each slot N into its neighbour N+1.  Loop proceeds from high
		# index slots to lower index slots.
		# A loop from n to 1 copies n slots.
		j = n
		while j >= 1:
			if self._D:
				Console.Error.WriteLine("stackInsertAt:" + (i + j))
			self._stack[i + j].r = self._stack[i + j - 1].r
			self._stack[i + j].d = self._stack[i + j - 1].d
			j -= 1
		self._stack[i].Object = o

	def resethookcount(self):
		""" <summary>
		 Equivalent of macro in ldebug.h.
		 </summary>
		"""
		self._hookcount = self._basehookcount

	def traceexec(self, pc):
		""" <summary>
		 Equivalent of traceexec in lvm.c.
		 </summary>
		"""
		mask = self._hookmask
		oldpc = self._savedpc
		self._savedpc = pc
		if mask > self._MASKLINE: # instruction-hook set?
			if self._hookcount == 0:
				self.resethookcount()
				self.dCallhook(self._HOOKCOUNT, -1)

	# :todo: line hook.
	def tonumber(o, out):
		""" <summary>
		 Convert to number.  Returns true if the argument <var>o</var> was
		 converted to a number.  Converted number is placed in <var>out[0]</var>.
		 Returns
		 false if the argument <var>o</var> could not be converted to a number.
		 Overloaded.
		 </summary>
		"""
		if o.r == self._NUMBER:
			out[0] = o.d
			return True
		if not ():
			return False
		if Lua.oStr2d(o.r, out):
			return True
		return False

	tonumber = staticmethod(tonumber)

	def tonumber(self, idx):
		""" <summary>
		 Converts a stack slot to number.  Returns true if the element at
		 the specified stack slot was converted to a number.  False
		 otherwise.  Note that this actually modifies the element stored at
		 <var>idx</var> in the stack (in faithful emulation of the PUC-Rio
		 code).  Corrupts <code>NUMOP[0]</code>.  Overloaded. </summary>
		 <param name="idx">  absolute stack slot. </param>
		"""
		if self.tonumber(self._stack[idx], self._NUMOP):
			if self._D:
				Console.Error.WriteLine("tonumber:" + idx)
			self._stack[idx].d = self._NUMOP[0]
			self._stack[idx].r = self._NUMBER
			return True
		return False

	def toNumberPair(x, y, out):
		""" <summary>
		 Convert a pair of operands for an arithmetic opcode.  Stores
		 converted results in <code>out[0]</code> and <code>out[1]</code>. </summary>
		 <returns> true if and only if both values converted to number. </returns>
		"""
		if Lua.tonumber(y, out):
			out[1] = out[0]
			if Lua.tonumber(x, out):
				return True
		return False

	toNumberPair = staticmethod(toNumberPair)

	def tostring(self, idx):
		""" <summary>
		 Convert to string.  Returns true if element was number or string
		 (the number will have been converted to a string), false otherwise.
		 Note this actually modifies the element stored at <var>idx</var> in
		 the stack (in faithful emulation of the PUC-Rio code), and when it
		 returns <code>true</code>, <code>stack[idx].r instanceof String</code>
		 is true.
		 </summary>
		"""
		# :todo: optimise
		o = self.objectAt(idx)
		s = self.vmTostring(o)
		if s == None:
			return False
		if self._D:
			Console.Error.WriteLine("tostring:" + idx)
		self._stack[idx].r = s
		return True

	def tryfuncTM(self, func):
		""" <summary>
		 Equivalent to tryfuncTM from ldo.c. </summary>
		 <param name="func">  absolute stack index of the function object. </param>
		"""
		if self._D:
			Console.Error.WriteLine("tryfuncTM:" + func)
		tm = self.tagmethod(self._stack[func].asObject(), "__call")
		if not self.isFunction(tm):
			self.gTypeerror(self._stack[func], "call")
		self.stackInsertAt(tm, func)
		return tm

	def isFalse(self, o):
		""" <summary>
		 Lua's is False predicate. </summary>
		"""
		return o == self._NIL or o == False

	def isFalse(self, o):
		""" @deprecated DO NOT CALL. """
		raise System.ArgumentException("isFalse called")

	def inc_ci(self, func, baseArg, top, nresults):
		""" <summary>
		 Make new CallInfo record. </summary>
		"""
		ci = CallInfo(func, baseArg, top, nresults)
		self._civ.addElement(ci)
		return ci

	def dec_ci(self):
		""" <summary>
		 Pop topmost CallInfo record and return it. </summary>
		"""
		ci = self._civ.pop()
		return ci

	def resume_error(self, msg):
		""" <summary>
		 Equivalent to resume_error from ldo.c </summary>
		"""
		self.stacksetsize(self.__ci().base())
		self.stackAdd(msg)
		return self._ERRRUN

	def objectAt(self, idx):
		""" <summary>
		 Return the stack element as an Object.  Converts double values into
		 Double objects. </summary>
		 <param name="idx">  absolute index into stack (0 <= idx < stackSize). </param>
		"""
		r = self._stack[idx].r
		if r != self._NUMBER:
			return r
		return System.Nullable[Double](self._stack[idx].d)

	def setObjectAt(self, o, idx):
		""" <summary>
		 Sets the stack element.  Double instances are converted to double. </summary>
		 <param name="o">  Object to store. </param>
		 <param name="idx">  absolute index into stack (0 <= idx < stackSize). </param>
		"""
		if isinstance(o, Double):
			if self._D:
				Console.Error.WriteLine("setObjectAt" + idx)
			self._stack[idx].r = self._NUMBER
			self._stack[idx].d = (o)
			return 
		self._stack[idx].r = o

	def uDump(f, writer, strip):
		""" <summary>
		 Corresponds to ldump's luaU_dump method, but with data gone and writer
		 replaced by OutputStream.
		 </summary>
		"""
		d = DumpState(DataOutputStream(writer), strip)
		d.DumpHeader()
		d.DumpFunction(f, None)
		d.writer.flush()
		return 0

	uDump = staticmethod(uDump)
 # Any errors result in thrown exceptions.
class DumpState(object):
	def __init__(self, writer, strip):
		self._writer = writer
		self._strip = strip

	def DumpHeader(self):
		"""///////////// dumper ////////////////////"""
		# 
		# * In order to make the code more compact the dumper re-uses the
		# * header defined in Loader.java.  It has to fix the endianness byte
		# * first.
		# 
		Loader.HEADER[6] = 0
		self._writer.write(Loader.HEADER)

	def DumpInt(self, i):
		self._writer.writeInt(i)
 # big-endian
	def DumpNumber(self, d):
		self._writer.writeDouble(d)
 # big-endian
	def DumpFunction(self, f, p):
		self.DumpString(None if (f.source_Renamed == p or self._strip) else f.source_Renamed)
		self.DumpInt(f.linedefined_Renamed)
		self.DumpInt(f.lastlinedefined_Renamed)
		self._writer.writeByte(f.nups_Renamed)
		self._writer.writeByte(f.numparams_Renamed)
		self._writer.writeBoolean(f.Vararg)
		self._writer.writeByte(f.maxstacksize_Renamed)
		self.DumpCode(f)
		self.DumpConstants(f)
		self.DumpDebug(f)

	def DumpCode(self, f):
		n = f.sizecode
		code = f.code_Renamed
		self.DumpInt(n)
		i = 0
		while i < n:
			self.DumpInt(code[i])
			i += 1

	def DumpConstants(self, f):
		n = f.sizek
		k = f.k
		self.DumpInt(n)
		i = 0
		while i < n:
			o = k[i].r
			if o == Lua.NIL:
				self._writer.writeByte(Lua.TNIL)
			elif isinstance(o, Boolean):
				self._writer.writeByte(Lua.TBOOLEAN)
				self._writer.writeBoolean((o))
			elif o == Lua.NUMBER:
				self._writer.writeByte(Lua.TNUMBER)
				self.DumpNumber(k[i].d)
			elif isinstance(o, String):
				self._writer.writeByte(Lua.TSTRING)
				self.DumpString(o)
			else:
				pass
			i += 1
		## assert false
		n = f.sizep
		self.DumpInt(n)
		i = 0
		while i < n:
			subfunc = f.p[i]
			self.DumpFunction(subfunc, f.source_Renamed)
			i += 1

	def DumpString(self, s):
		if s == None:
			self.DumpInt(0)
		else:
			# 
			# * Strings are dumped by converting to UTF-8 encoding.  The MIDP
			# * 2.0 spec guarantees that this encoding will be supported (see
			# * page 9 of midp-2_0-fr-spec.pdf).  Nonetheless, any
			# * possible UnsupportedEncodingException is left to be thrown
			# * (it's a subclass of IOException which is declared to be thrown).
			# 
			contents = Array.CreateInstance(Byte, Encoding.GetEncoding("UTF-8").GetByteCount(s))
			Encoding.GetEncoding("UTF-8").GetBytes(s, 0, s.Length, contents, 0)
			size = contents.Length
			self.DumpInt(size + 1)
			self._writer.write(contents, 0, size)
			self._writer.writeByte(0)

	def DumpDebug(self, f):
		if self._strip:
			self.DumpInt(0)
			self.DumpInt(0)
			self.DumpInt(0)
			return 
		n = f.sizelineinfo
		self.DumpInt(n)
		i = 0
		while i < n:
			self.DumpInt(f.lineinfo[i])
			i += 1
		n = f.sizelocvars
		self.DumpInt(n)
		i = 0
		while i < n:
			locvar = f.locvars_Renamed[i]
			self.DumpString(locvar.varname)
			self.DumpInt(locvar.startpc)
			self.DumpInt(locvar.endpc)
			i += 1
		n = f.sizeupvalues
		self.DumpInt(n)
		i = 0
		while i < n:
			self.DumpString(f.upvalues[i])
			i += 1

class Slot(object):
	def __init__(self, o):
		self._Object = o

	def __init__(self, o):
		self._Object = o

	def __init__(self, o):
		self._Object = o

	def asObject(self):
		if self._r == Lua.NUMBER:
			return System.Nullable[Double](self._d)
		return self._r

	def set_Object(self, value):
		self._r = value
		if isinstance(value, Double):
			self._r = Lua.NUMBER
			self._d = (value)
			if Lua.D:
				Console.Error.WriteLine("Slot.setObject:" + self._d)

	Object = property(fset=set_Object)