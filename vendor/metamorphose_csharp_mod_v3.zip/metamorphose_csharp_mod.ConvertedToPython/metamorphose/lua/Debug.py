﻿# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Debug.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Debug(object):
	""" <summary>
	 Equivalent to struct lua_Debug.  This implementation is incomplete
	 because it is not intended to form part of the public API.  It has
	 only been implemented to the extent necessary for internal use.
	 </summary>
	"""
	# private, no public accessors defined.
	# public accessors may be defined for these.
	def __init__(self, ici):
		""" <param name="ici">  index of CallInfo record in L.civ </param>"""
		self._ici_Renamed = ici

	def ici(self):
		""" <summary>
		 Get ici, index of the <seealso cref="CallInfo"/> record.
		 </summary>
		"""
		return self._ici_Renamed

	# <summary>
	# Setter for event.
	# </summary>
	def set_Event(self, value):
		self._event = value

	Event = property(fset=set_Event)

	def what(self):
		return self._what_Renamed

	# <summary>
	# Sets the what field.
	# </summary>
	def set_What(self, value):
		self._what_Renamed = value

	What = property(fset=set_What)

	# <summary>
	# Sets the source, and the shortsrc.
	# </summary>
	def set_Source(self, value):
		self._source = value
		self._shortsrc_Renamed = Lua.oChunkid(value)

	Source = property(fset=set_Source)

	def currentline(self):
		""" <summary>
		 Gets the current line.  May become public.
		 </summary>
		"""
		return self._currentline_Renamed

	# <summary>
	# Set currentline.
	# </summary>
	def set_Currentline(self, value):
		self._currentline_Renamed = value

	Currentline = property(fset=set_Currentline)

	def linedefined(self):
		""" <summary>
		 Get linedefined.
		 </summary>
		"""
		return self._linedefined_Renamed

	# <summary>
	# Set linedefined.
	# </summary>
	def set_Linedefined(self, value):
		self._linedefined_Renamed = value

	Linedefined = property(fset=set_Linedefined)

	# <summary>
	# Set lastlinedefined.
	# </summary>
	def set_Lastlinedefined(self, value):
		self._lastlinedefined = value

	Lastlinedefined = property(fset=set_Lastlinedefined)

	def shortsrc(self):
		""" <summary>
		 Gets the "printable" version of source, for error messages.
		 May become public.
		 </summary>
		"""
		return self._shortsrc_Renamed