﻿from System import *
from System.Collections import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/FuncState.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class FuncState(object):
	""" <summary>
	 Used to model a function during compilation.  Code generation uses
	 this structure extensively.  Most of the PUC-Rio functions from
	 lcode.c have moved into this class, alongwith a few functions from
	 lparser.c
	 </summary>
	"""
	# <summary>
	# See NO_JUMP in lcode.h. </summary>
	# <summary>
	# Proto object for this function. </summary>
	# <summary>
	# Table to find (and reuse) elements in <var>f.k</var>.  Maps from
	# Object (a constant Lua value) to an index into <var>f.k</var>.
	# </summary>
	# <summary>
	# Enclosing function. </summary>
	# <summary>
	# Lexical state. </summary>
	# <summary>
	# Lua state. </summary>
	# <summary>
	# chain of current blocks </summary> # = null;
	# <summary>
	# next position to code. </summary> # = 0;
	# <summary>
	# pc of last jump target. </summary>
	# <summary>
	# List of pending jumps to <var>pc</var>. </summary>
	# <summary>
	# First free register. </summary> # = 0;
	# <summary>
	# number of elements in <var>k</var>. </summary> # = 0;
	# <summary>
	# number of elements in <var>p</var>. </summary> # = 0;
	# <summary>
	# number of elements in <var>locvars</var>. </summary> # = 0;
	# <summary>
	# number of active local variables. </summary> # = 0;
	# <summary>
	# upvalues as 8-bit k and 8-bit info </summary>
	# <summary>
	# declared-variable stack. </summary>
	def __init__(self, ls):
		""" <summary>
		 Constructor.  Much of this is taken from <code>open_func</code> in
		 <code>lparser.c</code>.
		 </summary>
		"""
		self._NO_JUMP = -1
		self._h = Hashtable()
		self._lasttarget = -1
		self._jpc = self._NO_JUMP
		self._upvalues = Array.CreateInstance(int, Lua.MAXUPVALUES)
		self._actvar = Array.CreateInstance(Int16, Lua.MAXVARS) # default value for maxstacksize=2
		#    prev = ls.linkfs(this);
		# <summary>
		# Equivalent to <code>close_func</code> from <code>lparser.c</code>. </summary>
		## assert checks
		## assert bl == null
		# <summary>
		# Equivalent to getlocvar from lparser.c.
		# Accesses <code>LocVar</code>s of the <seealso cref="Proto"/>.
		# </summary>
		# Functions from lcode.c
		# <summary>
		# Equivalent to luaK_checkstack. </summary>
		# <summary>
		# Equivalent to luaK_code. </summary>
		# Put new instruction in code array.
		# <summary>
		# Equivalent to luaK_codeABC. </summary>
		# assert getOpMode(o) == iABC;
		# assert getBMode(o) != OP_ARG_N || b == 0;
		# assert getCMode(o) != OP_ARG_N || c == 0;
		# <summary>
		# Equivalent to luaK_codeABx. </summary>
		# assert getOpMode(o) == iABx || getOpMode(o) == iAsBx);
		# assert getCMode(o) == OP_ARG_N);
		# <summary>
		# Equivalent to luaK_codeAsBx. </summary>
		# <summary>
		# Equivalent to luaK_dischargevars. </summary> # there is one value available (somewhere)
		# <summary>
		# Equivalent to luaK_exp2anyreg. </summary> # reg is not a local? # put value on it # default
		# <summary>
		# Equivalent to luaK_exp2nextreg. </summary>
		# <summary>
		# Equivalent to luaK_fixline. </summary>
		# <summary>
		# Equivalent to luaK_infix. </summary> # operand must be on the `stack'
		# <summary>
		# Equivalent to luaK_nil. </summary> # no jumps to current position? # function start? # positions are already clean # can connect both?
		# <summary>
		# Equivalent to luaK_numberK. </summary>
		# <summary>
		# Equivalent to luaK_posfix. </summary>
		# list must be closed
		## assert e1.t == NO_JUMP
		# list must be closed
		## assert e1.f == NO_JUMP
		## assert e1.info == Lua.ARGB(getcode(e2))-1 # operand must be on the 'stack'
		## assert false
		# <summary>
		# Equivalent to luaK_prefix. </summary>
		# <summary>
		# Equivalent to luaK_reserveregs. </summary>
		# <summary>
		# Equivalent to luaK_ret. </summary>
		# <summary>
		# Equivalent to luaK_setmultret (in lcode.h). </summary>
		# <summary>
		# Equivalent to luaK_setoneret. </summary> # expression is an open function call?
		# <summary>
		# Equivalent to luaK_setreturns. </summary> # expression is an open function call?
		# <summary>
		# Equivalent to luaK_stringK. </summary> # .intern()
		# :todo: assert
		# constant not found; create a new entry # do not attempt to divide by 0 # do not attempt to divide by 0 # no constant folding for 'len'
		## assert false # do not attempt to produce NaN
		## assert false
		# interchange true and false lists
		## assert false # put this jump in `t' list # position of an eventual LOAD false # position of an eventual LOAD true # position after whole expression # those instructions may be jump targets
		# <summary>
		# check whether list has any jump that do not produce a value
		# (or produce an inverted value)
		# </summary> # not found
		# assert reg == freereg;
		# <summary>
		# Equivalent to searchvar from lparser.c </summary>
		# caution: descending loop (in emulation of PUC-Rio). # not found
		# <summary>
		# Equivalent to <code>luaK_getlabel</code>. </summary>
		# <summary>
		# Equivalent to <code>luaK_concat</code>.
		# l1 was an int*, now passing back as result.
		# </summary> # find last element
		# <summary>
		# Equivalent to <code>luaK_patchlist</code>. </summary>
		## assert target < pc # jump to default target # cannot patch other instructions # no register to put value or register already has the value
		# 
		# ** masks for instruction properties. The format is:
		# ** bits 0-1: op mode
		# ** bits 2-3: C arg mode
		# ** bits 4-5: B arg mode
		# ** bit 6: instruction set register A
		# ** bit 7: operator is a test
		# 
		# <summary>
		# arg modes </summary>
		self._OP_ARG_N = 0
		self._OP_ARG_U = 1
		self._OP_ARG_R = 2
		self._OP_ARG_K = 3
		# <summary>
		# op modes </summary>
		self._iABC = 0
		self._iABx = 1
		self._iAsBx = 2
		self._OPMODE = Array[SByte]((self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_N, self._iABx), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_U, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_N, self._iABx), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_K, self._iABC), self.opmode(0, 0, self._OP_ARG_K, self._OP_ARG_N, self._iABx), self.opmode(0, 0, self._OP_ARG_U, self._OP_ARG_N, self._iABC), self.opmode(0, 0, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_U, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_R, self._iABC), self.opmode(0, 0, self._OP_ARG_R, self._OP_ARG_N, self._iAsBx), self.opmode(1, 0, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(1, 0, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(1, 0, self._OP_ARG_K, self._OP_ARG_K, self._iABC), self.opmode(1, 1, self._OP_ARG_R, self._OP_ARG_U, self._iABC), self.opmode(1, 1, self._OP_ARG_R, self._OP_ARG_U, self._iABC), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_U, self._iABC), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_U, self._iABC), self.opmode(0, 0, self._OP_ARG_U, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iAsBx), self.opmode(0, 1, self._OP_ARG_R, self._OP_ARG_N, self._iAsBx), self.opmode(1, 0, self._OP_ARG_N, self._OP_ARG_U, self._iABC), self.opmode(0, 0, self._OP_ARG_U, self._OP_ARG_U, self._iABC), self.opmode(0, 0, self._OP_ARG_N, self._OP_ARG_N, self._iABC), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_N, self._iABx), self.opmode(0, 1, self._OP_ARG_U, self._OP_ARG_N, self._iABC)))
		self._f = Proto(ls.source_Renamed, 2)
		self._L = ls.L
		self._ls = ls

	def close(self):
		self._f.closeCode(self._pc)
		self._f.closeLineinfo(self._pc)
		self._f.closeK(self._nk)
		self._f.closeP(self._np)
		self._f.closeLocvars(self._nlocvars)
		self._f.closeUpvalues()
		checks = self._L.gCheckcode(self._f)

	def getlocvar(self, idx):
		return self._f.locvars_Renamed[self._actvar[idx]]

	def kCheckstack(self, n):
		newstack = self._freereg_Renamed + n
		if newstack > self._f.maxstacksize():
			if newstack >= Lua.MAXSTACK:
				self._ls.xSyntaxerror("function or expression too complex")
			self._f.Maxstacksize = newstack

	def kCode(self, i, line):
		self.dischargejpc()
		self._f.codeAppend(self._L, self._pc, i, line)
		self._pc += 1
		return self._pc

	def kCodeABC(self, o, a, b, c):
		return self.kCode(Lua.CREATE_ABC(o, a, b, c), self._ls.lastline())

	def kCodeABx(self, o, a, bc):
		return self.kCode(Lua.CREATE_ABx(o, a, bc), self._ls.lastline())

	def kCodeAsBx(self, o, a, bc):
		return self.kCodeABx(o, a, bc + Lua.MAXARG_sBx)

	def kDischargevars(self, e):
		if e.kind() == Expdesc.VLOCAL:
			e.Kind = Expdesc.VNONRELOC
		elif e.kind() == Expdesc.VUPVAL:
			e.reloc(self.kCodeABC(Lua.OP_GETUPVAL, 0, e.info_Renamed, 0))
		elif e.kind() == Expdesc.VGLOBAL:
			e.reloc(self.kCodeABx(Lua.OP_GETGLOBAL, 0, e.info_Renamed))
		elif e.kind() == Expdesc.VINDEXED:
			self.freereg(e.aux())
			self.freereg(e.info())
			e.reloc(self.kCodeABC(Lua.OP_GETTABLE, 0, e.info_Renamed, e.aux_Renamed))
		elif e.kind() == Expdesc.VVARARG or e.kind() == Expdesc.VCALL:
			self.kSetoneret(e)
		else:
			pass

	def kExp2anyreg(self, e):
		self.kDischargevars(e)
		if e.k == Expdesc.VNONRELOC:
			if not e.hasjumps():
				return e.info_Renamed
			if e.info_Renamed >= self._nactvar:
				self.exp2reg(e, e.info_Renamed)
				return e.info_Renamed
		self.kExp2nextreg(e)
		return e.info_Renamed

	def kExp2nextreg(self, e):
		self.kDischargevars(e)
		self.freeexp(e)
		self.kReserveregs(1)
		self.exp2reg(e, self._freereg_Renamed - 1)

	def kFixline(self, line):
		self._f.setLineinfo(self._pc - 1, line)

	def kInfix(self, op, v):
		if op == Syntax.OPR_AND:
			self.kGoiftrue(v)
		elif op == Syntax.OPR_OR:
			self.kGoiffalse(v)
		elif op == Syntax.OPR_CONCAT:
			self.kExp2nextreg(v)
		else:
			if not self.isnumeral(v):
				self.kExp2RK(v)

	def isnumeral(self, e):
		return e.k == Expdesc.VKNUM and e.t == self._NO_JUMP and e.f == self._NO_JUMP

	def kNil(self, from_, n):
		if self._pc > self._lasttarget:
			if self._pc == 0:
				return 
			previous = self._pc - 1
			instr = self._f.code_Renamed[previous]
			if Lua.OPCODE(instr) == Lua.OP_LOADNIL:
				pfrom = Lua.ARGA(instr)
				pto = Lua.ARGB(instr)
				if pfrom <= from_ and from_ <= pto + 1:
					if from_ + n - 1 > pto:
						self._f.code_Renamed[previous] = Lua.SETARG_B(instr, from_ + n - 1)
					return 
		self.kCodeABC(Lua.OP_LOADNIL, from_, from_ + n - 1, 0)

	def kNumberK(self, r):
		return self.addk(Lua.valueOfNumber(r))

	def kPosfix(self, op, e1, e2):
		if op == Syntax.OPR_AND:
			self.kDischargevars(e2)
			e2.f = self.kConcat(e2.f, e1.f)
			e1.init(e2)
		elif op == Syntax.OPR_OR:
			self.kDischargevars(e2)
			e2.t = self.kConcat(e2.t, e1.t)
			e1.init(e2)
		elif op == Syntax.OPR_CONCAT:
			self.kExp2val(e2)
			if e2.k == Expdesc.VRELOCABLE and Lua.OPCODE(self.getcode(e2)) == Lua.OP_CONCAT:
				self.freeexp(e1)
				self.setcode(e2, Lua.SETARG_B(self.getcode(e2), e1.info_Renamed))
				e1.k = e2.k
				e1.info_Renamed = e2.info_Renamed
			else:
				self.kExp2nextreg(e2)
				self.codearith(Lua.OP_CONCAT, e1, e2)
		elif op == Syntax.OPR_ADD:
			self.codearith(Lua.OP_ADD, e1, e2)
		elif op == Syntax.OPR_SUB:
			self.codearith(Lua.OP_SUB, e1, e2)
		elif op == Syntax.OPR_MUL:
			self.codearith(Lua.OP_MUL, e1, e2)
		elif op == Syntax.OPR_DIV:
			self.codearith(Lua.OP_DIV, e1, e2)
		elif op == Syntax.OPR_MOD:
			self.codearith(Lua.OP_MOD, e1, e2)
		elif op == Syntax.OPR_POW:
			self.codearith(Lua.OP_POW, e1, e2)
		elif op == Syntax.OPR_EQ:
			self.codecomp(Lua.OP_EQ, True, e1, e2)
		elif op == Syntax.OPR_NE:
			self.codecomp(Lua.OP_EQ, False, e1, e2)
		elif op == Syntax.OPR_LT:
			self.codecomp(Lua.OP_LT, True, e1, e2)
		elif op == Syntax.OPR_LE:
			self.codecomp(Lua.OP_LE, True, e1, e2)
		elif op == Syntax.OPR_GT:
			self.codecomp(Lua.OP_LT, False, e1, e2)
		elif op == Syntax.OPR_GE:
			self.codecomp(Lua.OP_LE, False, e1, e2)
		else:
			pass

	def kPrefix(self, op, e):
		e2 = Expdesc(Expdesc.VKNUM, 0)
		if op == Syntax.OPR_MINUS:
			if e.kind() == Expdesc.VK:
				self.kExp2anyreg(e)
			self.codearith(Lua.OP_UNM, e, e2)
		elif op == Syntax.OPR_NOT:
			self.codenot(e)
		elif op == Syntax.OPR_LEN:
			self.kExp2anyreg(e)
			self.codearith(Lua.OP_LEN, e, e2)
		else:
			raise System.ArgumentException()

	def kReserveregs(self, n):
		self.kCheckstack(n)
		self._freereg_Renamed += n

	def kRet(self, first, nret):
		self.kCodeABC(Lua.OP_RETURN, first, nret + 1, 0)

	def kSetmultret(self, e):
		self.kSetreturns(e, Lua.MULTRET)

	def kSetoneret(self, e):
		if e.kind() == Expdesc.VCALL:
			e.nonreloc(Lua.ARGA(self.getcode(e)))
		elif e.kind() == Expdesc.VVARARG:
			self.setargb(e, 2)
			e.Kind = Expdesc.VRELOCABLE

	def kSetreturns(self, e, nresults):
		if e.kind() == Expdesc.VCALL:
			self.setargc(e, nresults + 1)
		elif e.kind() == Expdesc.VVARARG:
			self.setargb(e, nresults + 1)
			self.setarga(e, self._freereg_Renamed)
			self.kReserveregs(1)

	def kStringK(self, s):
		return self.addk(s)

	def addk(self, o):
		hash = o
		v = self._h[hash]
		if v != None:
			return (v)
		self._f.constantAppend(self._nk, o)
		self._h[hash] = System.Nullable[int](self._nk)
		self._nk += 1 # FIXME:
		return self._nk

	def codearith(self, op, e1, e2):
		if self.constfolding(op, e1, e2):
			return 
		else:
			o1 = self.kExp2RK(e1)
			o2 = self.kExp2RK(e2) if (op != Lua.OP_UNM and op != Lua.OP_LEN) else 0
			self.freeexp(e2)
			self.freeexp(e1)
			e1.info_Renamed = self.kCodeABC(op, 0, o1, o2)
			e1.k = Expdesc.VRELOCABLE

	def constfolding(self, op, e1, e2):
		if not self.isnumeral(e1) or not self.isnumeral(e2):
			return False
		v1 = e1.nval_Renamed
		v2 = e2.nval_Renamed
		if op == Lua.OP_ADD:
			r = v1 + v2
		elif op == Lua.OP_SUB:
			r = v1 - v2
		elif op == Lua.OP_MUL:
			r = v1 * v2
		elif op == Lua.OP_DIV:
			if v2 == 0.0:
				return False
			r = v1 / v2
		elif op == Lua.OP_MOD:
			if v2 == 0.0:
				return False
			r = v1 % v2
		elif op == Lua.OP_POW:
			r = Lua.iNumpow(v1, v2)
		elif op == Lua.OP_UNM:
			r = -v1
		elif op == Lua.OP_LEN:
			return False
		else:
			r = 0.0
		if Double.IsNaN(r):
			return False
		e1.nval_Renamed = r
		return True

	def codenot(self, e):
		self.kDischargevars(e)
		if e.k == Expdesc.VNIL or e.k == Expdesc.VFALSE:
			e.k = Expdesc.VTRUE
		elif e.k == Expdesc.VK or e.k == Expdesc.VKNUM or e.k == Expdesc.VTRUE:
			e.k = Expdesc.VFALSE
		elif e.k == Expdesc.VJMP:
			self.invertjump(e)
		elif e.k == Expdesc.VRELOCABLE or e.k == Expdesc.VNONRELOC:
			self.discharge2anyreg(e)
			self.freeexp(e)
			e.info_Renamed = self.kCodeABC(Lua.OP_NOT, 0, e.info_Renamed, 0)
			e.k = Expdesc.VRELOCABLE
		else:
			pass
		temp = e.f
		e.f = e.t
		e.t = temp
		self.removevalues(e.f)
		self.removevalues(e.t)

	def removevalues(self, list):
		while list != self._NO_JUMP:
			self.patchtestreg(list, Lua.NO_REG)
			list = self.getjump(list)

	def dischargejpc(self):
		self.patchlistaux(self._jpc, self._pc, Lua.NO_REG, self._pc)
		self._jpc = self._NO_JUMP

	def discharge2reg(self, e, reg):
		self.kDischargevars(e)
		if e.k == Expdesc.VNIL:
			self.kNil(reg, 1)
		elif e.k == Expdesc.VFALSE or e.k == Expdesc.VTRUE:
			self.kCodeABC(Lua.OP_LOADBOOL, reg, (1 if e.k == Expdesc.VTRUE else 0), 0)
		elif e.k == Expdesc.VK:
			self.kCodeABx(Lua.OP_LOADK, reg, e.info_Renamed)
		elif e.k == Expdesc.VKNUM:
			self.kCodeABx(Lua.OP_LOADK, reg, self.kNumberK(e.nval_Renamed))
		elif e.k == Expdesc.VRELOCABLE:
			self.setarga(e, reg)
		elif e.k == Expdesc.VNONRELOC:
			if reg != e.info_Renamed:
				self.kCodeABC(Lua.OP_MOVE, reg, e.info_Renamed, 0)
		elif e.k == Expdesc.VVOID or e.k == Expdesc.VJMP:
			return 
		else:
			pass
		e.nonreloc(reg)

	def exp2reg(self, e, reg):
		self.discharge2reg(e, reg)
		if e.k == Expdesc.VJMP:
			e.t = self.kConcat(e.t, e.info_Renamed)
		if e.hasjumps():
			p_f = self._NO_JUMP
			p_t = self._NO_JUMP
			if self.need_value(e.t) or self.need_value(e.f):
				fj = self._NO_JUMP if (e.k == Expdesc.VJMP) else self.kJump()
				p_f = self.code_label(reg, 0, 1)
				p_t = self.code_label(reg, 1, 0)
				self.kPatchtohere(fj)
			finalpos = self.kGetlabel()
			self.patchlistaux(e.f, finalpos, reg, p_f)
			self.patchlistaux(e.t, finalpos, reg, p_t)
		e.init(Expdesc.VNONRELOC, reg)

	def code_label(self, a, b, jump):
		self.kGetlabel()
		return self.kCodeABC(Lua.OP_LOADBOOL, a, b, jump)

	def need_value(self, list):
		while list != self._NO_JUMP:
			i = self.getjumpcontrol(list)
			instr = self._f.code_Renamed[i]
			if Lua.OPCODE(instr) != Lua.OP_TESTSET:
				return True
			list = self.getjump(list)
		return False

	def freeexp(self, e):
		if e.kind() == Expdesc.VNONRELOC:
			self.freereg(e.info_Renamed)

	def freereg(self, reg):
		if not Lua.ISK(reg) and reg >= self._nactvar:
			self._freereg_Renamed -= 1

	def getcode(self, e):
		return self._f.code_Renamed[e.info_Renamed]

	def setcode(self, e, code):
		self._f.code_Renamed[e.info_Renamed] = code

	def searchvar(self, n):
		i = self._nactvar - 1
		while i >= 0:
			if n.Equals(self.getlocvar(i).varname):
				return i
			i -= 1
		return -1

	def setarga(self, e, a):
		at = e.info_Renamed
		code = self._f.code_Renamed
		code[at] = Lua.SETARG_A(code[at], a)

	def setargb(self, e, b):
		at = e.info_Renamed
		code = self._f.code_Renamed
		code[at] = Lua.SETARG_B(code[at], b)

	def setargc(self, e, c):
		at = e.info_Renamed
		code = self._f.code_Renamed
		code[at] = Lua.SETARG_C(code[at], c)

	def kGetlabel(self):
		self._lasttarget = self._pc
		return self._pc

	def kConcat(self, l1, l2):
		if l2 == self._NO_JUMP:
			return l1
		elif l1 == self._NO_JUMP:
			return l2
		else:
			list = l1
			while true:
				next = self.getjump(list)
				if next == self._NO_JUMP:
					break
				list = next
			self.fixjump(list, l2)
			return l1

	def kPatchlist(self, list, target):
		if target == self._pc:
			self.kPatchtohere(list)
		else:
			self.patchlistaux(list, target, Lua.NO_REG, target)

	def patchlistaux(self, list, vtarget, reg, dtarget):
		while list != self._NO_JUMP:
			next = self.getjump(list)
			if self.patchtestreg(list, reg):
				self.fixjump(list, vtarget)
			else:
				self.fixjump(list, dtarget)
			list = next

	def patchtestreg(self, node, reg):
		i = self.getjumpcontrol(node)
		code = self._f.code_Renamed
		instr = code[i]
		if Lua.OPCODE(instr) != Lua.OP_TESTSET:
			return False
		if reg != Lua.NO_REG and reg != Lua.ARGB(instr):
			code[i] = Lua.SETARG_A(instr, reg)
		else:
			code[i] = Lua.CREATE_ABC(Lua.OP_TEST, Lua.ARGB(instr), 0, Lua.ARGC(instr))
		return True

	def getjumpcontrol(self, at):
		code = self._f.code_Renamed
		if at >= 1 and self.testTMode(Lua.OPCODE(code[at - 1])):
			return at - 1
		else:
			return at

	def opmode(t, a, b, c, m):
		return ((t << 7) | (a << 6) | (b << 4) | (c << 2) | m)

	opmode = staticmethod(opmode)

	def getOpMode(self, m):
		return self._OPMODE[m] & 3

	def testAMode(self, m):
		return (self._OPMODE[m] & (1 << 6)) != 0

	def testTMode(self, m):
		return (self._OPMODE[m] & (1 << 7)) != 0

	def kPatchtohere(self, list):
		""" <summary>
		 Equivalent to <code>luaK_patchtohere</code>. </summary>
		"""
		self.kGetlabel()
		self._jpc = self.kConcat(self._jpc, list)

	def fixjump(self, at, dest):
		jmp = self._f.code_Renamed[at]
		offset = dest - (at + 1)
		## assert dest != NO_JUMP
		if Math.Abs(offset) > Lua.MAXARG_sBx:
			self._ls.xSyntaxerror("control structure too long")
		self._f.code_Renamed[at] = Lua.SETARG_sBx(jmp, offset)

	def getjump(self, at):
		offset = Lua.ARGsBx(self._f.code_Renamed[at])
		if offset == self._NO_JUMP: # point to itself represents end of list
			return self._NO_JUMP
		else: # end of list
			return (at + 1) + offset
 # turn offset into absolute position
	def kJump(self):
		""" <summary>
		 Equivalent to <code>luaK_jump</code>. </summary>
		"""
		old_jpc = self._jpc # save list of jumps to here
		self._jpc = self._NO_JUMP
		j = self.kCodeAsBx(Lua.OP_JMP, 0, self._NO_JUMP)
		j = self.kConcat(j, old_jpc) # keep them on hold
		return j

	def kStorevar(self, var, ex):
		""" <summary>
		 Equivalent to <code>luaK_storevar</code>. </summary>
		"""
		if var.k == Expdesc.VLOCAL:
			self.freeexp(ex)
			self.exp2reg(ex, var.info_Renamed)
			return 
		elif var.k == Expdesc.VUPVAL:
			e = self.kExp2anyreg(ex)
			self.kCodeABC(Lua.OP_SETUPVAL, e, var.info_Renamed, 0)
			#break
		elif var.k == Expdesc.VGLOBAL:
			e = self.kExp2anyreg(ex)
			self.kCodeABx(Lua.OP_SETGLOBAL, e, var.info_Renamed)
			#break
		elif var.k == Expdesc.VINDEXED:
			e = self.kExp2RK(ex)
			self.kCodeABC(Lua.OP_SETTABLE, var.info_Renamed, var.aux_Renamed, e)
			#break
		else:
			# invalid var kind to store
			## assert false
			#break
			pass
		self.freeexp(ex)

	def kIndexed(self, t, k):
		""" <summary>
		 Equivalent to <code>luaK_indexed</code>. </summary>
		"""
		t.aux_Renamed = self.kExp2RK(k)
		t.k = Expdesc.VINDEXED

	def kExp2RK(self, e):
		""" <summary>
		 Equivalent to <code>luaK_exp2RK</code>. </summary>
		"""
		self.kExp2val(e)
		if e.k == Expdesc.VKNUM or e.k == Expdesc.VTRUE or e.k == Expdesc.VFALSE or e.k == Expdesc.VNIL:
			if self._nk <= Lua.MAXINDEXRK: # constant fit in RK operand?
				e.info_Renamed = self.nilK() if (e.k == Expdesc.VNIL) else self.kNumberK(e.nval_Renamed) if (e.k == Expdesc.VKNUM) else self.boolK(e.k == Expdesc.VTRUE)
				e.k = Expdesc.VK
				return e.info_Renamed | Lua.BITRK
			else:
				#break
				pass
		elif e.k == Expdesc.VK:
			if e.info_Renamed <= Lua.MAXINDEXRK: # constant fit in argC?
				return e.info_Renamed | Lua.BITRK
			else:
				#break
				pass
		else:
			pass
		# not a constant in the right range: put it in a register
		return self.kExp2anyreg(e)

	def kExp2val(self, e):
		""" <summary>
		 Equivalent to <code>luaK_exp2val</code>. </summary>
		"""
		if e.hasjumps():
			self.kExp2anyreg(e)
		else:
			self.kDischargevars(e)

	def boolK(self, b):
		return self.addk(Lua.valueOfBoolean(b))

	def nilK(self):
		return self.addk(Lua.NIL)

	def kGoiffalse(self, e):
		""" <summary>
		 Equivalent to <code>luaK_goiffalse</code>. </summary>
		""" # pc of last jump
		self.kDischargevars(e)
		if e.k == Expdesc.VNIL or e.k == Expdesc.VFALSE:
			lj = self._NO_JUMP # always false; do nothing
		elif e.k == Expdesc.VTRUE:
			lj = self.kJump() # always jump
		elif e.k == Expdesc.VJMP:
			lj = e.info_Renamed
		else:
			lj = self.jumponcond(e, True)
		e.t = self.kConcat(e.t, lj) # insert last jump in `t' list
		self.kPatchtohere(e.f)
		e.f = self._NO_JUMP

	def kGoiftrue(self, e):
		""" <summary>
		 Equivalent to <code>luaK_goiftrue</code>. </summary>
		""" # pc of last jump
		self.kDischargevars(e)
		if e.k == Expdesc.VK or e.k == Expdesc.VKNUM or e.k == Expdesc.VTRUE:
			lj = self._NO_JUMP # always true; do nothing
		elif e.k == Expdesc.VFALSE:
			lj = self.kJump() # always jump
		elif e.k == Expdesc.VJMP:
			self.invertjump(e)
			lj = e.info_Renamed
		else:
			lj = self.jumponcond(e, False)
		e.f = self.kConcat(e.f, lj) # insert last jump in `f' list
		self.kPatchtohere(e.t)
		e.t = self._NO_JUMP

	def invertjump(self, e):
		at = self.getjumpcontrol(e.info_Renamed)
		code = self._f.code_Renamed
		instr = code[at]
		## assert testTMode(Lua.OPCODE(instr)) && Lua.OPCODE(instr) != Lua.OP_TESTSET && Lua.OPCODE(instr) != Lua.OP_TEST
		code[at] = Lua.SETARG_A(instr, (1 if Lua.ARGA(instr) == 0 else 0))

	def jumponcond(self, e, cond):
		if e.k == Expdesc.VRELOCABLE:
			ie = self.getcode(e)
			if Lua.OPCODE(ie) == Lua.OP_NOT:
				self._pc -= 1 # remove previous OP_NOT
				return self.condjump(Lua.OP_TEST, Lua.ARGB(ie), 0, 0 if cond else 1)
		# else go through
		self.discharge2anyreg(e)
		self.freeexp(e)
		return self.condjump(Lua.OP_TESTSET, Lua.NO_REG, e.info_Renamed, 1 if cond else 0)

	def condjump(self, op, a, b, c):
		self.kCodeABC(op, a, b, c)
		return self.kJump()

	def discharge2anyreg(self, e):
		if e.k != Expdesc.VNONRELOC:
			self.kReserveregs(1)
			self.discharge2reg(e, self._freereg_Renamed - 1)

	def kSelf(self, e, key):
		self.kExp2anyreg(e)
		self.freeexp(e)
		func = self._freereg_Renamed
		self.kReserveregs(2)
		self.kCodeABC(Lua.OP_SELF, func, e.info_Renamed, self.kExp2RK(key))
		self.freeexp(key)
		e.info_Renamed = func
		e.k = Expdesc.VNONRELOC

	def kSetlist(self, base, nelems, tostore):
		c = (nelems - 1) / Lua.LFIELDS_PER_FLUSH + 1
		b = 0 if (tostore == Lua.MULTRET) else tostore
		## assert tostore != 0
		if c <= Lua.MAXARG_C:
			self.kCodeABC(Lua.OP_SETLIST, base, b, c)
		else:
			self.kCodeABC(Lua.OP_SETLIST, base, b, 0)
			self.kCode(c, self._ls.lastline_Renamed)
		self._freereg_Renamed = base + 1
 # free registers with list values
	def codecomp(self, op, cond, e1, e2):
		o1 = self.kExp2RK(e1)
		o2 = self.kExp2RK(e2)
		self.freeexp(e2)
		self.freeexp(e1)
		if (not cond) and op != Lua.OP_EQ:
			# exchange args to replace by `<' or `<='
			temp = o1 # o1 <==> o2
			o1 = o2
			o2 = temp
			cond = True
		e1.info_Renamed = self.condjump(op, (1 if cond else 0), o1, o2)
		e1.k = Expdesc.VJMP

	def markupval(self, level):
		b = self._bl
		while b != None and b.nactvar > level:
			b = b.previous
		if b != None:
			b.upval = True