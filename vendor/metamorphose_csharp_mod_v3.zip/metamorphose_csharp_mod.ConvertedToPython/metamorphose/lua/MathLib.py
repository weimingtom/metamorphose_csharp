﻿from System import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/MathLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class MathLib(LuaJavaCallback):
	""" <summary>
	 Contains Lua's math library.
	 The library can be opened using the <seealso cref="#open"/> method.
	 Because this library is implemented on top of CLDC 1.1 it is not as
	 complete as the PUC-Rio math library.  Trigononmetric inverses
	 (EG <code>acos</code>) and hyperbolic trigonometric functions (EG
	 <code>cosh</code>) are not provided.
	 </summary>
	"""
	# Each function in the library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	#private static final int acos = 2;
	#private static final int asin = 3;
	#private static final int atan2 = 4;
	#private static final int atan = 5;
	#private static final int cosh = 7;
	#private static final int frexp = 13;
	#private static final int ldexp = 14;
	#private static final int log = 15;
	#private static final int sinh = 23;
	#private static final int tanh = 26;
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	def __init__(self, which):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._ABS = 1
		self._CEIL = 6
		self._COS = 8
		self._DEG = 9
		self._EXP = 10
		self._FLOOR = 11
		self._FMOD = 12
		self._MAX = 16
		self._MIN = 17
		self._MODF = 18
		self._POW = 19
		self._RAD = 20
		self._RANDOM = 21
		self._RANDOMSEED = 22
		self._SIN = 24
		self._SQRT = 25
		self._TAN = 27
		self._rng = Random()
		self._which = which

	def luaFunction(self, L):
		""" <summary>
		 Implements all of the functions in the Lua math library.  Do not
		 call directly. </summary>
		 <param name="L">  the Lua state in which to execute. </param>
		 <returns> number of returned parameters, as per convention. </returns>
		"""
		if self._which == self._ABS:
			return self.abs(L)
		elif self._which == self._CEIL:
			return self.ceil(L)
		elif self._which == self._COS:
			return self.cos(L)
		elif self._which == self._DEG:
			return self.deg(L)
		elif self._which == self._EXP:
			return self.exp(L)
		elif self._which == self._FLOOR:
			return self.floor(L)
		elif self._which == self._FMOD:
			return self.fmod(L)
		elif self._which == self._MAX:
			return self.max(L)
		elif self._which == self._MIN:
			return self.min(L)
		elif self._which == self._MODF:
			return self.modf(L)
		elif self._which == self._POW:
			return self.pow(L)
		elif self._which == self._RAD:
			return self.rad(L)
		elif self._which == self._RANDOM:
			return self.random(L)
		elif self._which == self._RANDOMSEED:
			return self.randomseed(L)
		elif self._which == self._SIN:
			return self.sin(L)
		elif self._which == self._SQRT:
			return self.sqrt(L)
		elif self._which == self._TAN:
			return self.tan(L)
		return 0

	def open(L):
		""" <summary>
		 Opens the library into the given Lua state.  This registers
		 the symbols of the library in the global table. </summary>
		 <param name="L">  The Lua state into which to open. </param>
		"""
		t = L.register("math")
		MathLib.r(L, "abs", self._ABS)
		MathLib.r(L, "ceil", self._CEIL)
		MathLib.r(L, "cos", self._COS)
		MathLib.r(L, "deg", self._DEG)
		MathLib.r(L, "exp", self._EXP)
		MathLib.r(L, "floor", self._FLOOR)
		MathLib.r(L, "fmod", self._FMOD)
		MathLib.r(L, "max", self._MAX)
		MathLib.r(L, "min", self._MIN)
		MathLib.r(L, "modf", self._MODF)
		MathLib.r(L, "pow", self._POW)
		MathLib.r(L, "rad", self._RAD)
		MathLib.r(L, "random", self._RANDOM)
		MathLib.r(L, "randomseed", self._RANDOMSEED)
		MathLib.r(L, "sin", self._SIN)
		MathLib.r(L, "sqrt", self._SQRT)
		MathLib.r(L, "tan", self._TAN)
		L.setField(t, "pi", Lua.valueOfNumber(Math.PI))
		L.setField(t, "huge", Lua.valueOfNumber(Double.PositiveInfinity))

	open = staticmethod(open)

	def r(L, name, which):
		""" <summary>
		 Register a function. </summary>
		"""
		f = MathLib(which)
		L.setField(L.getGlobal("math"), name, f)

	r = staticmethod(r)

	def abs(L):
		L.pushNumber(Math.Abs(L.checkNumber(1)))
		return 1

	abs = staticmethod(abs)

	def ceil(L):
		L.pushNumber(Math.Ceiling(L.checkNumber(1)))
		return 1

	ceil = staticmethod(ceil)

	def cos(L):
		L.pushNumber(Math.Cos(L.checkNumber(1)))
		return 1

	cos = staticmethod(cos)

	def deg(L):
		L.pushNumber(MathUtil.toDegrees(L.checkNumber(1)))
		return 1

	deg = staticmethod(deg)

	def exp(L):
		# CLDC 1.1 has Math.E but no exp, pow, or log.  Bizarre.
		L.pushNumber(Lua.iNumpow(Math.E, L.checkNumber(1)))
		return 1

	exp = staticmethod(exp)

	def floor(L):
		L.pushNumber(Math.Floor(L.checkNumber(1)))
		return 1

	floor = staticmethod(floor)

	def fmod(L):
		L.pushNumber(L.checkNumber(1) % L.checkNumber(2))
		return 1

	fmod = staticmethod(fmod)

	def max(L):
		n = L.Top # number of arguments
		dmax = L.checkNumber(1)
		i = 2
		while i <= n:
			d = L.checkNumber(i)
			dmax = Math.Max(dmax, d)
			i += 1
		L.pushNumber(dmax)
		return 1

	max = staticmethod(max)

	def min(L):
		n = L.Top # number of arguments
		dmin = L.checkNumber(1)
		i = 2
		while i <= n:
			d = L.checkNumber(i)
			dmin = Math.Min(dmin, d)
			i += 1
		L.pushNumber(dmin)
		return 1

	min = staticmethod(min)

	def modf(L):
		x = L.checkNumber(1)
		fp = x % 1
		ip = x - fp
		L.pushNumber(ip)
		L.pushNumber(fp)
		return 2

	modf = staticmethod(modf)

	def pow(L):
		L.pushNumber(Lua.iNumpow(L.checkNumber(1), L.checkNumber(2)))
		return 1

	pow = staticmethod(pow)

	def rad(L):
		L.pushNumber(MathUtil.toRadians(L.checkNumber(1)))
		return 1

	rad = staticmethod(rad)

	def random(L):
		# It would seem better style to associate the java.util.Random
		# instance with the Lua instance (by implementing and using a
		# registry for example).  However, PUC-rio uses the ISO C library
		# and so will share the same random number generator across all Lua
		# states.  So we do too. # check number of arguments
		if L.Top == 0: # no arguments
			L.pushNumber(self._rng.NextDouble())
		elif L.Top == 1: # only upper limit
			u = L.checkInt(1)
			L.argCheck(1 <= u, 1, "interval is empty")
			L.pushNumber(self._rng.Next(u) + 1)
		elif L.Top == 2: # lower and upper limits
			l = L.checkInt(1)
			u = L.checkInt(2)
			L.argCheck(l <= u, 2, "interval is empty")
			L.pushNumber(self._rng.Next(u) + l)
		else:
			return L.error("wrong number of arguments")
		return 1

	random = staticmethod(random)

	def randomseed(L):
		self._rng = Random(L.checkNumber(1))
		return 0

	randomseed = staticmethod(randomseed)

	def sin(L):
		L.pushNumber(Math.Sin(L.checkNumber(1)))
		return 1

	sin = staticmethod(sin)

	def sqrt(L):
		L.pushNumber(Math.Sqrt(L.checkNumber(1)))
		return 1

	sqrt = staticmethod(sqrt)

	def tan(L):
		L.pushNumber(Math.Tan(L.checkNumber(1)))
		return 1

	tan = staticmethod(tan)