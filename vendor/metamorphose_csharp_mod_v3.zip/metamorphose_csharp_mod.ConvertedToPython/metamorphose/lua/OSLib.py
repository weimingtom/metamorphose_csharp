﻿from System import *
from System.Text import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/OSLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
# REFERENCES
# [C1990] "ISO Standard: Programming languages - C"; ISO 9899:1990;
class OSLib(LuaJavaCallback):
	""" <summary>
	 The OS Library.  Can be opened into a <seealso cref="Lua"/> state by invoking
	 the <seealso cref="#open"/> method.
	 </summary>
	"""
	# Each function in the library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	# EXECUTE = 4;
	# EXIT = 5; #FIXME:added
	# REMOVE = 7;
	# RENAME = 8;
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	def __init__(self, which):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._CLOCK = 1
		self._DATE = 2
		self._DIFFTIME = 3
		self._GETENV = 6
		self._SETLOCALE = 9
		self._TIME = 10
		# <summary>
		# Implements all of the functions in the Lua os library (that are
		# provided).  Do not call directly. </summary>
		# <param name="L">  the Lua state in which to execute. </param>
		# <returns> number of returned parameters, as per convention. </returns> #FIXME:
		# <summary>
		# Opens the library into the given Lua state.  This registers
		# the symbols of the library in the table "os". </summary>
		# <param name="L">  The Lua state into which to open. </param> #FIXME:added
		# <summary>
		# Register a function. </summary>
		self._T0 = SystemUtil.currentTimeMillis()
		# <summary>
		# Implements clock.  Java provides no way to get CPU time, so we
		# return the amount of wall clock time since this class was loaded.
		# </summary>
		# <summary>
		# Implements date. </summary> # 8 = number of fields
		# yday is not supported because CLDC 1.1 does not provide it.
		# setfield(L, "yday", c.get("???"));
		# CLDC 1.1 does not provide any way to determine isdst, so we set
		# it to -1 (which in C means that the information is not
		# available).
		# On the other hand if the timezone does not do DST then it
		# can't be in effect.
		# Generally in order to save space, the abbreviated forms are
		# identical to the long forms.
		# The specifiers are from [C1990].
		#FIXME:should be this
		#b.append(String.format("%tc", c)); # force into range 1-12
		# Not supported because CLDC 1.1 doesn't provide it.
		# We extract fields from the result of Date.toString.
		# The output of which is of the form:
		# dow mon dd hh:mm:ss zzz yyyy
		# except that zzz is optional. # while
		# <summary>
		# Implements difftime. </summary>
		# Incredibly, the spec doesn't give a numeric value and range for
		# Calendar.JANUARY through to Calendar.DECEMBER.
		# <summary>
		# Converts from 0-11 to required Calendar value.  DO NOT MODIFY THIS
		# ARRAY.
		# </summary>
		self._MONTH = Array[int]((1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12))
		# <summary>
		# Implements setlocale. </summary>
		# <summary>
		# Implements time. </summary> # called without args? # make sure table is at the top
		# ignore isdst field #FIXME:
		# <summary>
		# Format a positive integer in a 0-filled field of width
		# <var>w</var>.
		# </summary>
		# <summary>
		# (almost) inverts the conversion provided by <seealso cref="#MONTH"/>.  Converts
		# from a <seealso cref="Calendar"/> value to a month in the range 1-12. </summary>
		# <param name="m">  a value from the enum Calendar.JANUARY, Calendar.FEBRUARY, etc </param>
		# <returns> a month in the range 1-12, or the original value. </returns>
		# DO NOT MODIFY ARRAY
		self._WEEKDAY = Array[int]((Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY))
		self._which = which

	def luaFunction(self, L):
		if self._which == self._CLOCK:
			return self.clock(L)
		elif self._which == self._DATE:
			return self.date(L)
		elif self._which == self._DIFFTIME:
			return self.difftime(L)
		elif self._which == self._GETENV:
			return self.getenv(L)
		elif self._which == self._SETLOCALE:
			return self.setlocale(L)
		elif self._which == self._TIME:
			return self.time(L)
		return 0

	def open(L):
		L.register("os")
		OSLib.r(L, "clock", self._CLOCK)
		OSLib.r(L, "date", self._DATE)
		OSLib.r(L, "difftime", self._DIFFTIME)
		OSLib.r(L, "getenv", self._GETENV)
		OSLib.r(L, "setlocale", self._SETLOCALE)
		OSLib.r(L, "time", self._TIME)

	open = staticmethod(open)

	def r(L, name, which):
		f = OSLib(which)
		lib = L.getGlobal("os")
		L.setField(lib, name, f)

	r = staticmethod(r)

	def clock(L):
		d = SystemUtil.currentTimeMillis()
		d = d - self._T0
		d /= 1000
		L.pushNumber(d)
		return 1

	clock = staticmethod(clock)

	def date(L):
		if L.isNoneOrNil(2):
			t = SystemUtil.currentTimeMillis()
		else:
			t = L.checkNumber(2)
		s = L.optString(1, "%c")
		tz = metamorphose.java.TimeZone.getDefault()
		if s.StartsWith("!"):
			tz = metamorphose.java.TimeZone.getTimeZone("GMT")
			s = s.Substring(1)
		c = Calendar.getInstance(tz)
		c.setTime(DateTime(t))
		if s.Equals("*t"):
			L.push(L.createTable(0, 8))
			OSLib.setfield(L, "sec", c._get(Calendar.SECOND))
			OSLib.setfield(L, "min", c._get(Calendar.MINUTE))
			OSLib.setfield(L, "hour", c._get(Calendar.HOUR))
			OSLib.setfield(L, "day", c._get(Calendar.DAY_OF_MONTH))
			OSLib.setfield(L, "month", OSLib.canonicalmonth(c._get(Calendar.MONTH)))
			OSLib.setfield(L, "year", c._get(Calendar.YEAR))
			OSLib.setfield(L, "wday", OSLib.canonicalweekday(c._get(Calendar.DAY_OF_WEEK)))
			if tz.useDaylightTime():
				OSLib.setfield(L, "isdst", -1)
			else:
				OSLib.setfield(L, "isdst", 0)
		else:
			b = StringBuilder()
			i = 0
			l = s.Length
			while i < l:
				ch = s[i]
				i += 1
				if ch != '%':
					b.Append(ch)
					continue
				if i >= l:
					break
				ch = s[i]
				i += 1
				if ch == 'a' or ch == 'A':
					b.Append(OSLib.weekdayname(c))
				elif ch == 'b' or ch == 'B':
					b.Append(OSLib.monthname(c))
				elif ch == 'c':
					b.Append(c.getTime().ToString())
				elif ch == 'd':
					b.Append(OSLib.format(c._get(Calendar.DAY_OF_MONTH), 2))
				elif ch == 'H':
					b.Append(OSLib.format(c._get(Calendar.HOUR), 2))
				elif ch == 'I':
					h = c._get(Calendar.HOUR)
					h = (h + 11) % 12 + 1
					b.Append(OSLib.format(h, 2))
				elif ch == 'j' or ch == 'U' or ch == 'W':
					b.Append('%')
					b.Append(ch)
				elif ch == 'm':
					m = OSLib.canonicalmonth(c._get(Calendar.MONTH))
					b.Append(OSLib.format(m, 2))
				elif ch == 'M':
					b.Append(OSLib.format(c._get(Calendar.MINUTE), 2))
				elif ch == 'p':
					h = c._get(Calendar.HOUR)
					b.Append("am" if h < 12 else "pm")
				elif ch == 'S':
					b.Append(OSLib.format(c._get(Calendar.SECOND), 2))
				elif ch == 'w':
					b.Append(OSLib.canonicalweekday(c._get(Calendar.DAY_OF_WEEK)))
				elif ch == 'x':
					u = c.getTime().ToString()
					b.Append(u.Substring(0, 11))
					b.Append(c._get(Calendar.YEAR))
				elif ch == 'X':
					u = c.getTime().ToString()
					b.Append(u.Substring(11, u.Length - 5 - 11))
				elif ch == 'y':
					b.Append(OSLib.format(c._get(Calendar.YEAR) % 100, 2))
				elif ch == 'Y':
					b.Append(c._get(Calendar.YEAR))
				elif ch == 'Z':
					b.Append(tz.getID())
				elif ch == '%':
					b.Append('%')
			L.pushString(b.ToString())
		return 1

	date = staticmethod(date)

	def difftime(L):
		L.pushNumber((L.checkNumber(1) - L.optNumber(2, 0)) / 1000)
		return 1

	difftime = staticmethod(difftime)

	def setlocale(L):
		if L.isNoneOrNil(1):
			L.pushString("")
		else:
			L.pushNil()
		return 1

	setlocale = staticmethod(setlocale)

	def time(L):
		if L.isNoneOrNil(1):
			L.pushNumber(SystemUtil.currentTimeMillis())
			return 1
		L.checkType(1, Lua.TTABLE)
		L.Top = 1
		c = Calendar.getInstance()
		c._set(Calendar.SECOND, OSLib.getfield(L, "sec", 0))
		c._set(Calendar.MINUTE, OSLib.getfield(L, "min", 0))
		c._set(Calendar.HOUR, OSLib.getfield(L, "hour", 12))
		c._set(Calendar.DAY_OF_MONTH, OSLib.getfield(L, "day", -1))
		c._set(Calendar.MONTH, self._MONTH[OSLib.getfield(L, "month", -1) - 1])
		c._set(Calendar.YEAR, OSLib.getfield(L, "year", -1))
		L.pushNumber(c.getTime().Ticks)
		return 1

	time = staticmethod(time)

	def getfield(L, key, d):
		o = L.getField(L.value(-1), key)
		if L.isNumber(o):
			return L.toNumber(o)
		if d < 0:
			return L.error("field '" + key + "' missing in date table")
		return d

	getfield = staticmethod(getfield)

	def setfield(L, key, value):
		L.setField(L.value(-1), key, Lua.valueOfNumber(value))

	setfield = staticmethod(setfield)

	def format(i, w):
		b = StringBuilder()
		b.Append(i)
		while b.Length < w:
			b.Insert(0, '0')
		return b.ToString()

	format = staticmethod(format)

	def weekdayname(c):
		s = c.getTime().ToString()
		return s.Substring(0, 3)

	weekdayname = staticmethod(weekdayname)

	def monthname(c):
		s = c.getTime().ToString()
		return s.Substring(4, 3)

	monthname = staticmethod(monthname)

	def canonicalmonth(m):
		i = 0
		while i < self._MONTH.Length:
			if m == self._MONTH[i]:
				return i + 1
			i += 1
		return m

	canonicalmonth = staticmethod(canonicalmonth)

	def canonicalweekday(w):
		""" <summary>
		 Converts from a <seealso cref="Calendar"/> value to a weekday in the range
		 0-6 where 0 is Sunday (as per the convention used in [C1990]). </summary>
		 <param name="w">  a value from the enum Calendar.SUNDAY, Calendar.MONDAY, etc </param>
		 <returns> a weekday in the range 0-6, or the original value. </returns>
		"""
		i = 0
		while i < self._WEEKDAY.Length:
			if w == self._WEEKDAY[i]:
				return i
			i += 1
		return w

	canonicalweekday = staticmethod(canonicalweekday)

	#FIXME:added
	def getenv(L):
		name = L.checkString(1)
		value = SystemUtil.getenv(name)
		if value == None:
			L.pushNil()
		else:
			L.pushString(value)
		return 1

	getenv = staticmethod(getenv)