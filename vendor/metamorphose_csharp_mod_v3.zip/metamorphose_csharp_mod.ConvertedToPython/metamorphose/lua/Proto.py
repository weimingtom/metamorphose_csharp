﻿from System import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Proto.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Proto(object):
	""" <summary>
	 Models a function prototype.  This class is internal to Jill and
	 should not be used by clients.  This is the analogue of the PUC-Rio
	 type <code>Proto</code>, hence the name.
	 A function prototype represents the constant part of a function, that
	 is, a function without closures (upvalues) and without an
	 environment.  It's a handle for a block of VM instructions and
	 ancillary constants.
	 
	 For convenience some private arrays are exposed.  Modifying these
	 arrays is punishable by death. (Java has no convenient constant
	 array datatype)
	 </summary>
	"""
	# <summary>
	# Interned 0-element array. </summary>
	# Generally the fields are named following the PUC-Rio implementation
	# and so are unusually terse.
	# <summary>
	# Array of constants. </summary>
	# <summary>
	# Array of VM instructions. </summary>
	# <summary>
	# Array of Proto objects. </summary>
	# <summary>
	# Number of upvalues used by this prototype (and so by all the
	# functions created from this Proto).
	# </summary>
	# <summary>
	# Number of formal parameters used by this prototype, and so the
	# number of argument received by a function created from this Proto.
	# In a function defined to be variadic then this is the number of
	# fixed parameters, the number appearing before '...' in the parameter
	# list.
	# </summary>
	# <summary>
	# <code>true</code> if and only if the function is variadic, that is,
	# defined with '...' in its parameter list.
	# </summary>
	# Debug info
	# <summary>
	# Map from PC to line number. </summary>
	def __init__(self, source, maxstacksize):
		""" <summary>
		 Proto synthesized by <seealso cref="Loader"/>.
		 All the arrays that are passed to the constructor are
		 referenced by the instance.  Avoid unintentional sharing.  All
		 arrays must be non-null and all int parameters must not be
		 negative.  Generally, this constructor is used by <seealso cref="Loader"/>
		 since that has all the relevant arrays already constructed (as
		 opposed to the compiler). </summary>
		 <param name="constant">   array of constants. </param>
		 <param name="code">       array of VM instructions. </param>
		 <param name="nups">       number of upvalues (used by this function). </param>
		 <param name="numparams">  number of fixed formal parameters. </param>
		 <param name="isVararg">   whether '...' is used. </param>
		 <param name="maxstacksize">  number of stack slots required when invoking. </param>
		 <exception cref="NullPointerException"> if any array arguments are null. </exception>
		 <exception cref="IllegalArgumentException"> if nups or numparams is negative. </exception>
		"""
		self._ZERO_INT_ARRAY = Array.CreateInstance(int, 0)
		self._ZERO_LOCVAR_ARRAY = Array.CreateInstance(LocVar, 0)
		self._ZERO_CONSTANT_ARRAY = Array.CreateInstance(Slot, 0)
		self._ZERO_PROTO_ARRAY = Array.CreateInstance(Proto, 0)
		self._ZERO_STRING_ARRAY = Array.CreateInstance(str, 0)
		# <summary>
		# Blank Proto in preparation for compilation.
		# </summary>
		self._maxstacksize_Renamed = maxstacksize
		#    maxstacksize = 2;   // register 0/1 are always valid.
		# :todo: Consider removing size* members
		self._source_Renamed = source
		self._k = self._ZERO_CONSTANT_ARRAY
		self._sizek = 0
		self._code_Renamed = self._ZERO_INT_ARRAY
		self._sizecode = 0
		self._p = self._ZERO_PROTO_ARRAY
		self._sizep = 0
		self._lineinfo = self._ZERO_INT_ARRAY
		self._sizelineinfo = 0
		self._locvars_Renamed = self._ZERO_LOCVAR_ARRAY
		self._sizelocvars = 0
		self._upvalues = self._ZERO_STRING_ARRAY
		self._sizeupvalues = 0

	def __init__(self, source, maxstacksize):
		self._ZERO_INT_ARRAY = Array.CreateInstance(int, 0)
		self._ZERO_LOCVAR_ARRAY = Array.CreateInstance(LocVar, 0)
		self._ZERO_CONSTANT_ARRAY = Array.CreateInstance(Slot, 0)
		self._ZERO_PROTO_ARRAY = Array.CreateInstance(Proto, 0)
		self._ZERO_STRING_ARRAY = Array.CreateInstance(str, 0)
		self._maxstacksize_Renamed = maxstacksize
		self._source_Renamed = source
		self._k = self._ZERO_CONSTANT_ARRAY
		self._sizek = 0
		self._code_Renamed = self._ZERO_INT_ARRAY
		self._sizecode = 0
		self._p = self._ZERO_PROTO_ARRAY
		self._sizep = 0
		self._lineinfo = self._ZERO_INT_ARRAY
		self._sizelineinfo = 0
		self._locvars_Renamed = self._ZERO_LOCVAR_ARRAY
		self._sizelocvars = 0
		self._upvalues = self._ZERO_STRING_ARRAY
		self._sizeupvalues = 0

	def debug(self, lineinfoArg, locvarsArg, upvaluesArg):
		""" <summary>
		 Augment with debug info.  All the arguments are referenced by the
		 instance after the method has returned, so try not to share them.
		 </summary>
		"""
		self._lineinfo = lineinfoArg
		self._sizelineinfo = self._lineinfo.Length
		self._locvars_Renamed = locvarsArg
		self._sizelocvars = self._locvars_Renamed.Length
		self._upvalues = upvaluesArg
		self._sizeupvalues = self._upvalues.Length

	def source(self):
		""" <summary>
		 Gets source. </summary>
		"""
		return self._source_Renamed

	# <summary>
	# Setter for source. </summary>
	def set_Source(self, value):
		self._source_Renamed = value

	Source = property(fset=set_Source)

	def linedefined(self):
		return self._linedefined_Renamed

	def set_Linedefined(self, value):
		self._linedefined_Renamed = value

	Linedefined = property(fset=set_Linedefined)

	def lastlinedefined(self):
		return self._lastlinedefined_Renamed

	def set_Lastlinedefined(self, value):
		self._lastlinedefined_Renamed = value

	Lastlinedefined = property(fset=set_Lastlinedefined)

	def nups(self):
		""" <summary>
		 Gets Number of Upvalues </summary>
		"""
		return self._nups_Renamed

	def numparams(self):
		""" <summary>
		 Number of Parameters. </summary>
		"""
		return self._numparams_Renamed

	def maxstacksize(self):
		""" <summary>
		 Maximum Stack Size. </summary>
		"""
		return self._maxstacksize_Renamed

	# <summary>
	# Setter for maximum stack size. </summary>
	def set_Maxstacksize(self, value):
		self._maxstacksize_Renamed = value

	Maxstacksize = property(fset=set_Maxstacksize)

	def code(self):
		""" <summary>
		 Instruction block (do not modify). </summary>
		"""
		return self._code_Renamed

	def codeAppend(self, L, pc, instruction, line):
		""" <summary>
		 Append instruction. </summary>
		"""
		if Lua.D:
			Console.Error.WriteLine("pc:" + pc + ", instruction:" + instruction + ", line:" + line + ", lineinfo.length:" + self._lineinfo.Length)
		self.ensureCode(L, pc)
		self._code_Renamed[pc] = instruction
		if pc >= self._lineinfo.Length:
			newLineinfo = Array.CreateInstance(int, self._lineinfo.Length * 2 + 1)
			Array.Copy(self._lineinfo, 0, newLineinfo, 0, self._lineinfo.Length)
			self._lineinfo = newLineinfo
		self._lineinfo[pc] = line

	def ensureLocvars(self, L, atleast, limit):
		if atleast + 1 > self._sizelocvars:
			newsize = atleast * 2 + 1
			if newsize > limit:
				newsize = limit
			if atleast + 1 > newsize:
				L.gRunerror("too many local variables")
			newlocvars = Array.CreateInstance(LocVar, newsize)
			Array.Copy(self._locvars_Renamed, 0, newlocvars, 0, self._sizelocvars)
			i = self._sizelocvars
			while i < newsize:
				newlocvars[i] = LocVar()
				i += 1
			self._locvars_Renamed = newlocvars
			self._sizelocvars = newsize

	def ensureProtos(self, L, atleast):
		if atleast + 1 > self._sizep:
			newsize = atleast * 2 + 1
			if newsize > Lua.MAXARG_Bx:
				newsize = Lua.MAXARG_Bx
			if atleast + 1 > newsize:
				L.gRunerror("constant table overflow")
			newprotos = Array.CreateInstance(Proto, newsize)
			Array.Copy(self._p, 0, newprotos, 0, self._sizep)
			self._p = newprotos
			self._sizep = newsize

	def ensureUpvals(self, L, atleast):
		if atleast + 1 > self._sizeupvalues:
			newsize = atleast * 2 + 1
			if atleast + 1 > newsize:
				L.gRunerror("upvalues overflow")
			newupvalues = Array.CreateInstance(str, newsize)
			Array.Copy(self._upvalues, 0, newupvalues, 0, self._sizeupvalues)
			self._upvalues = newupvalues
			self._sizeupvalues = newsize

	def ensureCode(self, L, atleast):
		if atleast + 1 > self._sizecode:
			newsize = atleast * 2 + 1
			if atleast + 1 > newsize:
				L.gRunerror("code overflow")
			newcode = Array.CreateInstance(int, newsize)
			Array.Copy(self._code_Renamed, 0, newcode, 0, self._sizecode)
			self._code_Renamed = newcode
			self._sizecode = newsize

	def setLineinfo(self, pc, line):
		""" <summary>
		 Set lineinfo record. </summary>
		"""
		self._lineinfo[pc] = line

	def getline(self, pc):
		""" <summary>
		 Get linenumber corresponding to pc, or 0 if no info. </summary>
		"""
		if self._lineinfo.Length == 0:
			return 0
		return self._lineinfo[pc]

	def proto(self):
		""" <summary>
		 Array of inner protos (do not modify). </summary>
		"""
		return self._p

	def constant(self):
		""" <summary>
		 Constant array (do not modify). </summary>
		"""
		return self._k

	def constantAppend(self, idx, o):
		""" <summary>
		 Append constant. </summary>
		"""
		if idx >= self._k.Length:
			newK = Array.CreateInstance(Slot, self._k.Length * 2 + 1)
			Array.Copy(self._k, 0, newK, 0, self._k.Length)
			self._k = newK
		self._k[idx] = Slot(o)

	# <summary>
	# Predicate for whether function uses ... in its parameter list. </summary>
	def get_Vararg(self):
		return self._isVararg

	Vararg = property(fget=get_Vararg)

	def setIsVararg(self):
		""" <summary>
		 "Setter" for isVararg.  Sets it to true. </summary>
		"""
		self._isVararg = True

	def locvars(self):
		""" <summary>
		 LocVar array (do not modify). </summary>
		"""
		return self._locvars_Renamed

	# All the trim functions, below, check for the redundant case of
	# trimming to the length that they already are.  Because they are
	# initially allocated as interned zero-length arrays this also means
	# that no unnecesary zero-length array objects are allocated.
	def trimInt(self, old, n):
		""" <summary>
		 Trim an int array to specified size. </summary>
		 <returns> the trimmed array. </returns>
		"""
		if n == old.Length:
			return old
		newArray = Array.CreateInstance(int, n)
		Array.Copy(old, 0, newArray, 0, n)
		return newArray

	def closeCode(self, n):
		""" <summary>
		 Trim code array to specified size. </summary>
		"""
		self._code_Renamed = self.trimInt(self._code_Renamed, n)
		self._sizecode = self._code_Renamed.Length

	def closeLineinfo(self, n):
		""" <summary>
		 Trim lineinfo array to specified size. </summary>
		"""
		self._lineinfo = self.trimInt(self._lineinfo, n)
		self._sizelineinfo = n

	def closeK(self, n):
		""" <summary>
		 Trim k (constant) array to specified size. </summary>
		"""
		if self._k.Length > n:
			newArray = Array.CreateInstance(Slot, n)
			Array.Copy(self._k, 0, newArray, 0, n)
			self._k = newArray
		self._sizek = n
		return 

	def closeP(self, n):
		""" <summary>
		 Trim p (proto) array to specified size. </summary>
		"""
		if n == self._p.Length:
			return 
		newArray = Array.CreateInstance(Proto, n)
		Array.Copy(self._p, 0, newArray, 0, n)
		self._p = newArray
		self._sizep = n

	def closeLocvars(self, n):
		""" <summary>
		 Trim locvar array to specified size. </summary>
		"""
		if n == self._locvars_Renamed.Length:
			return 
		newArray = Array.CreateInstance(LocVar, n)
		Array.Copy(self._locvars_Renamed, 0, newArray, 0, n)
		self._locvars_Renamed = newArray
		self._sizelocvars = n

	def closeUpvalues(self):
		""" <summary>
		 Trim upvalues array to size <var>nups</var>. </summary>
		"""
		if self._nups_Renamed == self._upvalues.Length:
			return 
		newArray = Array.CreateInstance(str, self._nups_Renamed)
		Array.Copy(self._upvalues, 0, newArray, 0, self._nups_Renamed)
		self._upvalues = newArray
		self._sizeupvalues = self._nups_Renamed