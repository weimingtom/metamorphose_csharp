﻿from metamorphose.java import *
from System.Text import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Loader.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Loader(object):
	""" <summary>
	 Loads Lua 5.1 binary chunks.
	 This loader is restricted to loading Lua 5.1 binary chunks where:
	 <ul>
	 <li><code>LUAC_VERSION</code> is <code>0x51</code>.</li>
	 <li><code>int</code> is 32 bits.</li>
	 <li><code>size_t</code> is 32 bits.</li>
	 <li><code>Instruction</code> is 32 bits (this is a type defined in
	 the PUC-Rio Lua).</li>
	 <li><code>lua_Number</code> is an IEEE 754 64-bit double.  Suitable
	 for passing to <seealso cref="java.lang.Double#longBitsToDouble"/>.</li>
	 <li>endianness does not matter (the loader swabs as appropriate).</li>
	 </ul>
	 Any Lua chunk compiled by a stock Lua 5.1 running on a 32-bit Windows
	 PC or at 32-bit OS X machine should be fine.
	 </summary>
	"""
	# <summary>
	# Whether integers in the binary chunk are stored big-endian or
	# little-endian.  Recall that the number 0x12345678 is stored: 0x12
	# 0x34 0x56 0x78 in big-endian format; and, 0x78 0x56 0x34 0x12 in
	# little-endian format.
	# </summary>
	# auxiliary for reading ints/numbers
	def __init__(self, in_, name):
		""" <summary>
		 A new chunk loader.  The <code>InputStream</code> must be
		 positioned at the beginning of the <code>LUA_SIGNATURE</code> that
		 marks the beginning of a Lua binary chunk. </summary>
		 <param name="in">    The binary stream from which the chunk is read. </param>
		 <param name="name">  The name of the chunk. </param>
		"""
		self._intbuf = Array.CreateInstance(Byte, 4)
		self._longbuf = Array.CreateInstance(Byte, 8)
		# The name is treated slightly.  See lundump.c in the PUC-Rio
		# source for details.
		# :todo: Select some equivalent for the binary string case.
		# <summary>
		# Loads (undumps) a dumped binary chunk. </summary>
		# <exception cref="IOException">  if chunk is malformed or unacceptable. </exception>
		# <summary>
		# Primitive reader for undumping.
		# Reads exactly enough bytes from <code>this.in</code> to fill the
		# array <code>b</code>.  If there aren't enough to fill
		# <code>b</code> then an exception is thrown.  Similar to
		# <code>LoadBlock</code> from PUC-Rio's <code>lundump.c</code>. </summary>
		# <param name="b">  byte array to fill. </param>
		# <exception cref="EOFException"> when the stream is exhausted too early. </exception>
		# <exception cref="IOException"> when the underlying stream does. </exception>
		# <summary>
		# Undumps a byte as an 8 bit unsigned number.  Returns
		# an int to accommodate the range.
		# </summary> # paranoia
		# <summary>
		# Undumps the code for a <code>Proto</code>.  The code is an array of
		# VM instructions.
		# </summary>
		# :Instruction:size  Here we assume that a dumped Instruction is
		# the same size as a dumped int.
		# <summary>
		# Undumps the constant array contained inside a <code>Proto</code>
		# object.  First half of <code>LoadConstants</code>, see
		# <code>proto</code> for the second half of
		# <code>LoadConstants</code>.
		# </summary>
		# Load each constant one by one.  We use the following values for
		# the Lua tagtypes (taken from <code>lua.h</code> from the PUC-Rio
		# Lua 5.1 distribution):
		# LUA_TNIL         0
		# LUA_TBOOLEAN     1
		# LUA_TNUMBER      3
		# LUA_TSTRING      4
		# All other tagtypes are invalid
		# :todo: Currently a new Slot is created for each constant.
		# Consider a space optimisation whereby identical constants have
		# the same Slot.  Constants are pooled per function anyway (so a
		# function never has 2 identical constants), so would have to work
		# across functions.  The easy cases of nil, true, false, might be
		# worth doing since that doesn't require a global table.
		#  # LUA_TNIL # LUA_TBOOLEAN
		# assert b >= 0; # LUA_TNUMBER # LUA_TSTRING
		# <summary>
		# Undumps the debug info for a <code>Proto</code>. </summary>
		# <param name="proto">  The Proto instance to which debug info will be added. </param>
		# lineinfo
		# locvars
		# upvalue (names)
		# <summary>
		# Undumps a Proto object.  This is named 'function' after
		# <code>LoadFunction</code> in PUC-Rio's <code>lundump.c</code>. </summary>
		# <param name="parentSource">  Name of parent source "file". </param>
		# <exception cref="IOException">  when binary is malformed. </exception>
		# "is_vararg" is a 3-bit field, with the following bit meanings
		# (see "lobject.h"):
		# 1 - VARARG_HASARG
		# 2 - VARARG_ISVARARG
		# 4 - VARARG_NEEDSARG
		# Values 1 and 4 (bits 0 and 2) are only used for 5.0
		# compatibility.
		# HASARG indicates that a function was compiled in 5.0
		# compatibility mode and is declared to have ... in its parameter
		# list.
		# NEEDSARG indicates that a function was compiled in 5.0
		# compatibility mode and is declared to have ... in its parameter
		# list and does _not_ use the 5.1 style of vararg access (using ...
		# as an expression).  It is assumed to use 5.0 style vararg access
		# (the local 'arg' variable).  This is not supported in Jill.
		# ISVARARG indicates that a function has ... in its parameter list
		# (whether compiled in 5.0 compatibility mode or not).
		#
		# At runtime NEEDSARG changes the protocol for calling a vararg
		# function.  We don't support this, so we check that it is absent
		# here in the loader.
		#
		# That means that the legal values for this field ar 0,1,2,3.
		# :todo: call code verifier
		self._HEADERSIZE = 12
		# <summary>
		# A chunk header that is correct.  Except for the endian byte, at
		# index 6, which is always overwritten with the one from the file,
		# before comparison.  We cope with either endianness.
		# Default access so that <seealso cref="Lua#load"/> can read the first entry.
		# On no account should anyone except <seealso cref="#header"/> modify
		# this array.
		# </summary>
		self._HEADER = Array[Byte]((0x1B, 'L', 'u', 'a', 0x51, 0, 99, 4, 4, 4, 8, 0))
		if None == in_:
			raise System.NullReferenceException()
		self._in = in_
		if name.StartsWith("@") or name.StartsWith("="):
			self._name = name.Substring(1)
		elif False:
			self._name = "binary string"
		else:
			self._name = name

	def undump(self):
		self.header()
		return self.function(None)

	def block(self, b):
		n = self._in.read(b)
		if n != b.Length:
			raise EOFException()

	def byteLoad(self):
		c = self._in.read()
		if c == -1:
			raise EOFException()
		else:
			return c & 0xFF

	def code(self):
		n = self.intLoad()
		code = Array.CreateInstance(int, n)
		i = 0
		while i < n:
			code[i] = self.intLoad()
			i += 1
		return code

	def constant(self):
		n = self.intLoad()
		k = Array.CreateInstance(Slot, n)
		i = 0
		while i < n:
			t = self.byteLoad()
			if t == 0:
				k[i] = Slot(Lua.NIL)
			elif t == 1:
				b = self.byteLoad()
				if b > 1:
					raise IOException()
				k[i] = Slot(Lua.valueOfBoolean(b != 0))
			elif t == 3:
				k[i] = Slot(self.number())
			elif t == 4:
				k[i] = Slot(self.string())
			else:
				raise IOException()
			i += 1
		return k

	def debug(self, proto):
		n = self.intLoad()
		lineinfo = Array.CreateInstance(int, n)
		i = 0
		while i < n:
			lineinfo[i] = self.intLoad()
			i += 1
		n = self.intLoad()
		locvar = Array.CreateInstance(LocVar, n)
		i = 0
		while i < n:
			s = self.string()
			start = self.intLoad()
			end = self.intLoad()
			locvar[i] = LocVar(s, start, end)
			i += 1
		n = self.intLoad()
		upvalue = Array.CreateInstance(str, n)
		i = 0
		while i < n:
			upvalue[i] = self.string()
			i += 1
		proto.debug(lineinfo, locvar, upvalue)
		return 

	def function(self, parentSource):
		source = self.string()
		if None == source:
			source = parentSource
		linedefined = self.intLoad()
		lastlinedefined = self.intLoad()
		nups = self.byteLoad()
		numparams = self.byteLoad()
		varargByte = self.byteLoad()
		if varargByte < 0 or varargByte > 3:
			raise IOException()
		vararg = (0 != varargByte)
		maxstacksize = self.byteLoad()
		code = self.code()
		constant = self.constant()
		proto = self.proto(source)
		newProto = Proto(constant, code, proto, nups, numparams, vararg, maxstacksize)
		newProto.Source = source
		newProto.Linedefined = linedefined
		newProto.Lastlinedefined = lastlinedefined
		self.debug(newProto)
		return newProto

	def header(self):
		""" <summary>
		 Loads and checks the binary chunk header.  Sets
		 <code>this.bigendian</code> accordingly.
		 
		 A Lua 5.1 header looks like this:
		 <pre>
		 b[0]    0x33
		 b[1..3] "Lua";
		 b[4]    0x51 (LUAC_VERSION)
		 b[5]    0 (LUAC_FORMAT)
		 b[6]    0 big-endian, 1 little-endian
		 b[7]    4 (sizeof(int))
		 b[8]    4 (sizeof(size_t))
		 b[9]    4 (sizeof(Instruction))
		 b[10]   8 (sizeof(lua_Number))
		 b[11]   0 (floating point)
		 </pre>
		 
		 To conserve JVM bytecodes the sizes of the types <code>int</code>,
		 <code>size_t</code>, <code>Instruction</code>,
		 <code>lua_Number</code> are assumed by the code to be 4, 4, 4, and
		 8, respectively.  Where this assumption is made the tags :int:size,
		 :size_t:size :Instruction:size :lua_Number:size will appear so that
		 you can grep for them, should you wish to modify this loader to
		 load binary chunks from different architectures.
		 </summary>
		 <exception cref="IOException">  when header is malformed or not suitable. </exception>
		"""
		buf = Array.CreateInstance(Byte, self._HEADERSIZE)
		# int n;
		self.block(buf)
		# poke the HEADER's endianness byte and compare.
		self._HEADER[6] = buf[6]
		if buf[6] < 0 or buf[6] > 1 or not self.arrayEquals(self._HEADER, buf):
			raise IOException()
		self._bigendian = (buf[6] == 0)

	def intLoad(self):
		""" <summary>
		 Undumps an int.  This method swabs accordingly.
		 size_t and Instruction need swabbing too, but the code
		 simply uses this method to load size_t and Instruction.
		 </summary>
		"""
		# :int:size  Here we assume an int is 4 bytes.
		self.block(self._intbuf)
		# Caution: byte is signed so "&0xff" converts to unsigned value.
		if self._bigendian:
			i = ((self._intbuf[0] & 0xff) << 24) | ((self._intbuf[1] & 0xff) << 16) | ((self._intbuf[2] & 0xff) << 8) | (self._intbuf[3] & 0xff)
		else:
			i = ((self._intbuf[3] & 0xff) << 24) | ((self._intbuf[2] & 0xff) << 16) | ((self._intbuf[1] & 0xff) << 8) | (self._intbuf[0] & 0xff)
		return i

	# minimum footprint version?
	# int result = 0 ;
	# for (int shift = 0 ; shift < 32 ; shift+=8)
	# {
	# int byt = byteLoad () ;
	# if (bigendian)
	# result = (result << 8) | byt ;
	# else
	# result |= byt << shift ;
	# }
	# return result ;
	# 
	# another version?
	# if (bigendian)
	# {
	# int result = byteLoad() << 24 ;
	# result |= byteLoad () << 16 ;
	# result |= byteLoad () << 8 ;
	# result |= byteLoad () ;
	# return result;
	# }
	# else
	# {
	# int result = byteLoad() ;
	# result |= byteLoad () << 8 ;
	# result |= byteLoad () << 16 ;
	# result |= byteLoad () << 24 ;
	# return result ;
	# }
	# 
	def number(self):
		""" <summary>
		 Undumps a Lua number.  Which is assumed to be a 64-bit IEEE double.
		 </summary>
		"""
		# :lua_Number:size  Here we assume that the size is 8.
		self.block(self._longbuf)
		# Big-endian architectures store doubles with the sign bit first;
		# little-endian is the other way around.
		l = 0
		i = 0
		while i < 8:
			if self._bigendian:
				l = (l << 8) | (self._longbuf[i] & 0xff)
			else:
				l = ((l >> 8)) | (((self._longbuf[i] & 0xff)) << 56)
			i += 1
		d = l #double.longBitsToDouble(l);
		return Lua.valueOfNumber(d)

	def proto(self, source):
		""" <summary>
		 Undumps the <code>Proto</code> array contained inside a
		 <code>Proto</code> object.  These are the <code>Proto</code>
		 objects for all inner functions defined inside an existing
		 function.  Corresponds to the second half of PUC-Rio's
		 <code>LoadConstants</code> function.  See <code>constant</code> for
		 the first half.
		 </summary>
		"""
		n = self.intLoad()
		p = Array.CreateInstance(Proto, n)
		i = 0
		while i < n:
			p[i] = self.function(source)
			i += 1
		return p

	def string(self):
		""" <summary>
		 Undumps a <seealso cref="String"/> or <code>null</code>.  As per
		 <code>LoadString</code> in
		 PUC-Rio's lundump.c.  Strings are converted from the binary
		 using the UTF-8 encoding, using the {@link
		 java.lang.String#String(byte[], String) String(byte[], String)}
		 constructor.
		 </summary>
		"""
		# :size_t:size we assume that size_t is same size as int.
		size = self.intLoad()
		if size == 0:
			return None
		buf = Array.CreateInstance(Byte, size - 1)
		self.block(buf)
		# Discard trailing NUL byte
		if self._in.read() == -1:
			raise EOFException()
		return Encoding.GetEncoding("UTF-8").GetString(buf)

	def arrayEquals(x, y):
		""" <summary>
		 CLDC 1.1 does not provide <code>java.util.Arrays</code> so we make
		 do with this.
		 </summary>
		"""
		if x.Length != y.Length:
			return False
		i = 0
		while i < x.Length:
			if x[i] != y[i]:
				return False
			i += 1
		return True

	arrayEquals = staticmethod(arrayEquals)