﻿from System import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/LuaTable.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class LuaTable(Hashtable):
	""" <summary>
	 Class that models Lua's tables.  Each Lua table is an instance of
	 this class.  Whilst you can clearly see that this class extends
	 <seealso cref="java.util.Hashtable"/> you should in no way rely upon that.
	 Calling any methods that are not defined in this class (but are
	 defined in a super class) is extremely deprecated.
	 </summary>
	""" # = null;
	# <summary>
	# Array used so that tables accessed like arrays are more efficient.
	# All elements stored at an integer index, <var>i</var>, in the
	# range [1,sizeArray] are stored at <code>array[i-1]</code>.
	# This speed and space usage for array-like access.
	# When the table is rehashed the array's size is chosen to be the
	# largest power of 2 such that at least half the entries are
	# occupied.  Default access granted for <seealso cref="Enum"/> class, do not
	# abuse.
	# </summary>
	# <summary>
	# Equal to <code>array.length</code>.  Default access granted for
	# <seealso cref="Enum"/> class, do not abuse.
	# </summary> # = 0;
	# <summary>
	# <code>true</code> whenever we are in the <seealso cref="#rehash"/>
	# method.  Avoids infinite rehash loops.
	# </summary> # = false;
	def __init__(self, narray, nhash):
		self._MAXBITS = 26
		self._MAXASIZE = 1 << self._MAXBITS
		self._ZERO = Array.CreateInstance(Object, 0)
		self._array = self._ZERO
		# <summary>
		# Fresh LuaTable with hints for preallocating to size. </summary>
		# <param name="narray">  number of array slots to preallocate. </param>
		# <param name="nhash">   number of hash slots to preallocate. </param>
		# :todo: super(nhash) isn't clearly correct as adding nhash hash
		# table entries will causes a rehash with the usual implementation
		# (which rehashes when ratio of entries to capacity exceeds the
		# load factor of 0.75).  Perhaps ideally we would size the hash
		# tables such that adding nhash entries will not cause a rehash.
		# <summary>
		# Implements discriminating equality.  <code>o1.equals(o2) == (o1 ==
		# o2) </code>.  This method is not necessary in CLDC, it's only
		# necessary in J2SE because java.util.Hashtable overrides equals. </summary>
		# <param name="o">  the reference to compare with. </param>
		# <returns> true when equal. </returns>
		# <summary>
		# Provided to avoid Checkstyle warning.  This method is not necessary
		# for correctness (in neither JME nor JSE), it's only provided to
		# remove a Checkstyle warning.
		# Since <seealso cref="#equals"/> implements the most discriminating
		# equality possible, this method can have any implementation. </summary>
		# <returns> an int. </returns> # 'key' did not match some condition # number of elements smaller than 2^i # number of elements to go to array part # optimal size for array part # 2^i # more than half elements present? # optimal size (till now) # all elements smaller than n will go to array part # all elements already counted
		## assert narray[0]/2 <= na && na <= narray[0] # is 'key' an appropriate array index? # count as such # summation of 'nums' # count to traverse all array keys # 2^lg # for each slice # counter # adjust upper limit # no more elements to count
		# count elements in range (2^(lg-1), 2^lg] # total number of elements # summation of nums
		# <param name="nasize">  (new) size of array part </param> # array part must grow?
		# The new array slots, from sizeArray to nasize-1, must
		# be filled with their values from the hash part.
		# There are two strategies:
		# Iterate over the new array slots, and look up each index in the
		# hash part to see if it has a value; or,
		# Iterate over the hash part and see if each key belongs in the
		# array part.
		# For now we choose the first algorithm.
		# :todo: consider using second algorithm, possibly dynamically. # array part must shrink?
		# move elements from array slots nasize to sizeArray-1 to the
		# hash part. # count keys in array part
		# <summary>
		# Getter for metatable member. </summary>
		# <returns>  The metatable. </returns>
		# <summary>
		# Setter for metatable member. </summary>
		# <param name="metatable">  The metatable. </param>
		# :todo: Support metatable's __gc and __mode keys appropriately.
		#        This involves detecting when those keys are present in the
		#        metatable, and changing all the entries in the Hashtable
		#        to be instance of java.lang.Ref as appropriate.
		# <summary>
		# Supports Lua's length (#) operator.  More or less equivalent to
		# luaH_getn and unbound_search in ltable.c.
		# </summary>
		# there is a boundary in the array part: (binary) search for it
		# unbound_search
		# Find 'i' and 'j' such that i is present and j is not. # overflow
		# Pathological case.  Linear search.
		# binary search between i and j
		# <summary>
		# Like <seealso cref="java.util.Hashtable#get"/>.  Ensures that indexes
		# with no value return <seealso cref="Lua#NIL"/>.  In order to get the correct
		# behaviour for <code>t[nil]</code>, this code assumes that Lua.NIL
		# is non-<code>null</code>.
		# </summary>
		# <summary>
		# Like <seealso cref="#getlua(Object)"/> but the result is written into
		# the <var>value</var> <seealso cref="Slot"/>.
		# </summary>
		# <summary>
		# Like get for numeric (integer) keys. </summary>
		# <summary>
		# Like <seealso cref="java.util.Hashtable#put"/> but enables Lua's semantics
		# for <code>nil</code>;
		# In particular that <code>x = nil</nil>
		# deletes <code>x</code>.
		# And also that <code>t[nil]</code> raises an error.
		# Generally, users of Jill should be using
		# <seealso cref="Lua#setTable"/> instead of this. </summary>
		# <param name="key"> key. </param>
		# <param name="value"> value. </param> # will cause additional check for array part later if
		# the array part check fails now.
		# :todo: Consider checking key for NaN (PUC-Rio does)
		# This check is necessary because sometimes the call to super.put
		# can rehash and the new (k,v) pair should be in the array part
		# after the rehash, but is still in the hash part.
		# :todo: consider some sort of tail merge with the other putlua
		# <summary>
		# Like put for numeric (integer) keys.
		# </summary>
		# The key can never be NIL so putlua will never notice that its L
		# argument is null.
		# :todo: optimisation to avoid putlua checking for array part again
		# <summary>
		# Do not use, implementation exists only to generate deprecated
		# warning. </summary>
		# @deprecated Use getlua instead. 
		# <summary>
		# Do not use, implementation exists only to generate deprecated
		# warning. </summary>
		# @deprecated Use putlua instead. 
		# <summary>
		# Used by oLog2.  DO NOT MODIFY.
		# </summary>
		self._LOG2 = Array[SByte]((0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8))
		self._array = Array.CreateInstance(Object, narray)
		i = 0
		while i < narray:
			self._array[i] = Lua.NIL
			i += 1
		self._sizeArray = narray

	def __init__(self, narray, nhash):
		self._MAXBITS = 26
		self._MAXASIZE = 1 << self._MAXBITS
		self._ZERO = Array.CreateInstance(Object, 0)
		self._array = self._ZERO
		self._LOG2 = Array[SByte]((0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8))
		self._array = Array.CreateInstance(Object, narray)
		i = 0
		while i < narray:
			self._array[i] = Lua.NIL
			i += 1
		self._sizeArray = narray

	def Equals(self, o):
		return self == o

	def GetHashCode(self):
		return SystemUtil.identityHashCode(self)

	def arrayindex(key):
		if isinstance(key, Double):
			d = (key)
			k = d
			if k == d:
				return k
		return -1

	arrayindex = staticmethod(arrayindex)

	def computesizes(nums, narray):
		t = narray[0]
		a = 0
		na = 0
		n = 0
		twotoi = 1
		i = 0
		while twotoi / 2 < t:
			if nums[i] > 0:
				a += nums[i]
				if a > twotoi / 2:
					n = twotoi
					na = a
			if a == t:
				break
			twotoi *= 2
			i += 1
		narray[0] = n
		return na

	computesizes = staticmethod(computesizes)

	def countint(self, key, nums):
		k = self.arrayindex(key)
		if 0 < k and k <= self._MAXASIZE:
			nums[self.ceillog2(k)] += 1
			return 1
		return 0

	def numusearray(self, nums):
		ause = 0
		i = 1
		ttlg = 1
		lg = 0
		while lg <= self._MAXBITS:
			lc = 0
			lim = ttlg
			if lim > self._sizeArray:
				lim = self._sizeArray
				if i > lim:
					break
			while i <= lim:
				if self._array[i - 1] != Lua.NIL:
					lc += 1
				i += 1
			nums[lg] += lc
			ause += lc
			ttlg *= 2
			lg += 1
		return ause

	def numusehash(self, nums, pnasize):
		totaluse = 0
		ause = 0
		e = self.keys()
		while e.hasMoreElements():
			o = e.nextElement()
			ause += self.countint(o, nums)
			totaluse += 1
		pnasize[0] += ause
		return totaluse

	def resize(self, nasize):
		if nasize == self._sizeArray:
			return 
		newarray = Array.CreateInstance(Object, nasize)
		if nasize > self._sizeArray:
			Array.Copy(self._array, 0, newarray, 0, self._array.Length)
			i = self._array.Length
			while i < nasize:
				key = System.Nullable[Double](i + 1)
				v = self.remove(key)
				if v == None:
					v = Lua.NIL
				newarray[i] = v
				i += 1
		if nasize < self._sizeArray:
			i = nasize
			while i < self._sizeArray:
				if self._array[i] != Lua.NIL:
					key = System.Nullable[Double](i + 1)
					self.put(key, self._array[i])
				i += 1
			Array.Copy(self._array, 0, newarray, 0, newarray.Length)
		self._array = newarray
		self._sizeArray = self._array.Length

	def rehash(self):
		oldinrehash = self._inrehash
		self._inrehash = True
		if not oldinrehash:
			nasize = Array.CreateInstance(int, 1)
			nums = Array.CreateInstance(int, self._MAXBITS + 1)
			nasize[0] = self.numusearray(nums)
			totaluse = nasize[0]
			totaluse += self.numusehash(nums, nasize)
			na = self.computesizes(nums, nasize)
			self.resize(nasize[0])
		self.rehash()
		self._inrehash = oldinrehash

	def getMetatable(self):
		return self._metatable

	def setMetatable(self, metatable):
		self._metatable = metatable
		return 

	def getn(self):
		j = self._sizeArray
		if j > 0 and self._array[j - 1] == Lua.NIL:
			i2 = 0
			while j - i2 > 1:
				m = (i2 + j) / 2
				if self._array[m - 1] == Lua.NIL:
					j = m
				else:
					i2 = m
			return i2
		i = 0
		j = 1
		while self.getnum(j) != Lua.NIL:
			i = j
			j *= 2
			if j < 0:
				i = 1
				while self.getnum(i) != Lua.NIL:
					i += 1
				return i - 1
		while j - i > 1:
			m = (i + j) / 2
			if self.getnum(m) == Lua.NIL:
				j = m
			else:
				i = m
		return i

	def getlua(self, key):
		if isinstance(key, Double):
			d = (key)
			if d <= self._sizeArray and d >= 1:
				i = d
				if i == d:
					return self._array[i - 1]
		r = self._get(key)
		if r == None:
			r = Lua.NIL
		return r

	def getlua(self, key, value):
		if key.r == Lua.NUMBER:
			d = key.d
			if d <= self._sizeArray and d >= 1:
				i = d
				if i == d:
					value.Object = self._array[i - 1]
					return 
		r = self._get(key.asObject())
		if r == None:
			r = Lua.NIL
		value.Object = r

	def getnum(self, k):
		if k <= self._sizeArray and k >= 1:
			return self._array[k - 1]
		r = self._get(System.Nullable[Double](k))
		if r == None:
			return Lua.NIL
		return r

	def putlua(self, L, key, value):
		d = 0.0
		i = int.MaxValue
		if key == Lua.NIL:
			L.gRunerror("table index is nil")
		if isinstance(key, Double):
			d = (key)
			j = d
			if j == d and j >= 1:
				i = j
				if i <= self._sizeArray:
					self._array[i - 1] = value
					return 
			if Double.IsNaN(d):
				L.gRunerror("table index is NaN")
		if value == Lua.NIL:
			self.remove(key)
			return 
		self.put(key, value)
		if i <= self._sizeArray:
			self.remove(key)
			self._array[i - 1] = value

	def putlua(self, L, key, value):
		i = int.MaxValue
		if key.r == Lua.NUMBER:
			j = key.d
			if j == key.d and j >= 1:
				i = j
				if i <= self._sizeArray:
					self._array[i - 1] = value
					return 
			if Double.IsNaN(key.d):
				L.gRunerror("table index is NaN")
		k = key.asObject()
		if value == Lua.NIL:
			self.remove(k)
			return 
		self.put(k, value)
		if i <= self._sizeArray:
			self.remove(k)
			self._array[i - 1] = value

	def putnum(self, k, v):
		if k <= self._sizeArray and k >= 1:
			self._array[k - 1] = v
			return 
		self.putlua(None, System.Nullable[Double](k), v)

	def get(self, key):
		raise System.ArgumentException()

	def keys(self):
		return Enum(self, self.keys())

	def put(self, key, value):
		raise System.ArgumentException()

	def oLog2(x):
		""" <summary>
		 Equivalent to luaO_log2.
		 </summary>
		"""
		## assert x >= 0
		l = -1
		while x >= 256:
			l += 8
			x = (x >> 8)
		return l + self._LOG2[x]

	oLog2 = staticmethod(oLog2)

	def ceillog2(x):
		return LuaTable.oLog2(x - 1) + 1

	ceillog2 = staticmethod(ceillog2)