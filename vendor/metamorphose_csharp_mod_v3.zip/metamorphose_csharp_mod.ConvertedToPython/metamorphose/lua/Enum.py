﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from metamorphose.java import *

class Enum(Enumeration): # = 0
	def __init__(self, t, e):
		self._t = t
		self._e = e
		self.inci()

	def inci(self):
		""" <summary>
		 Increments <seealso cref="#i"/> until it either exceeds
		 <code>t.sizeArray</code> or indexes a non-nil element.
		 </summary>
		"""
		while self._i < self._t.sizeArray and self._t.array[self._i] == Lua.NIL:
			self._i += 1

	def hasMoreElements(self):
		if self._i < self._t.sizeArray:
			return True
		return self._e.hasMoreElements()

	def nextElement(self):
		if self._i < self._t.sizeArray:
			self._i += 1 # array index i corresponds to key i+1
			r = System.Nullable[Double](self._i)
			self.inci()
		else:
			r = self._e.nextElement()
		return r