﻿from System import *
from System.Collections import *
from System.Text import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Syntax.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Syntax(object):
	""" <summary>
	 Syntax analyser.  Lexing, parsing, code generation.
	 </summary>
	"""
	# <summary>
	# End of File, must be -1 as that is what read() returns. </summary>
	# WARNING: if you change the order of this enumeration,
	# grep "ORDER RESERVED"
	# <summary>
	# Equivalent to luaX_tokens.  ORDER RESERVED </summary>
	def __init__(self, L, z, source):
		self._EOZ = -1
		self._FIRST_RESERVED = 257
		self._TK_AND = self._FIRST_RESERVED + 0
		self._TK_BREAK = self._FIRST_RESERVED + 1
		self._TK_DO = self._FIRST_RESERVED + 2
		self._TK_ELSE = self._FIRST_RESERVED + 3
		self._TK_ELSEIF = self._FIRST_RESERVED + 4
		self._TK_END = self._FIRST_RESERVED + 5
		self._TK_FALSE = self._FIRST_RESERVED + 6
		self._TK_FOR = self._FIRST_RESERVED + 7
		self._TK_FUNCTION = self._FIRST_RESERVED + 8
		self._TK_IF = self._FIRST_RESERVED + 9
		self._TK_IN = self._FIRST_RESERVED + 10
		self._TK_LOCAL = self._FIRST_RESERVED + 11
		self._TK_NIL = self._FIRST_RESERVED + 12
		self._TK_NOT = self._FIRST_RESERVED + 13
		self._TK_OR = self._FIRST_RESERVED + 14
		self._TK_REPEAT = self._FIRST_RESERVED + 15
		self._TK_RETURN = self._FIRST_RESERVED + 16
		self._TK_THEN = self._FIRST_RESERVED + 17
		self._TK_TRUE = self._FIRST_RESERVED + 18
		self._TK_UNTIL = self._FIRST_RESERVED + 19
		self._TK_WHILE = self._FIRST_RESERVED + 20
		self._TK_CONCAT = self._FIRST_RESERVED + 21
		self._TK_DOTS = self._FIRST_RESERVED + 22
		self._TK_EQ = self._FIRST_RESERVED + 23
		self._TK_GE = self._FIRST_RESERVED + 24
		self._TK_LE = self._FIRST_RESERVED + 25
		self._TK_NE = self._FIRST_RESERVED + 26
		self._TK_NUMBER = self._FIRST_RESERVED + 27
		self._TK_NAME = self._FIRST_RESERVED + 28
		self._TK_STRING = self._FIRST_RESERVED + 29
		self._TK_EOS = self._FIRST_RESERVED + 30
		self._NUM_RESERVED = self._TK_WHILE - self._FIRST_RESERVED + 1
		self._tokens = Array[str](("and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "..", "...", "==", ">=", "<=", "~=", "<number>", "<name>", "<string>", "<eof>"))
		self._reserved = metamorphose.java.Hashtable()
		# From struct LexState
		# <summary>
		# current character </summary>
		# <summary>
		# input line counter </summary>
		self._linenumber = 1
		# <summary>
		# line of last token 'consumed' </summary>
		self._lastline_Renamed = 1
		# <summary>
		# The token value.  For "punctuation" tokens this is the ASCII value
		# for the character for the token; for other tokens a member of the
		# enum (all of which are > 255).
		# </summary>
		# <summary>
		# Semantic info for token; a number. </summary>
		# <summary>
		# Semantic info for token; a string. </summary>
		# <summary>
		# Lookahead token value. </summary>
		self._lookahead = self._TK_EOS
		# <summary>
		# Semantic info for lookahead; a number. </summary>
		# <summary>
		# Semantic info for lookahead; a string. </summary>
		# <summary>
		# Semantic info for return value from <seealso cref="#llex"/>; a number. </summary>
		# <summary>
		# As <seealso cref="#semR"/>, for string. </summary>
		# <summary>
		# FuncState for current (innermost) function being parsed. </summary>
		# <summary>
		# input stream </summary>
		# <summary>
		# Buffer for tokens. </summary>
		self._buff = StringBuilder()
		# <summary>
		# current source name </summary>
		# <summary>
		# locale decimal point. </summary>
		self._decpoint = '.'
		# From <ctype.h>
		# Implementations of functions from <ctype.h> are only correct copies
		# to the extent that Lua requires them.
		# Generally they have default access so that StringLib can see them.
		# Unlike C's these version are not locale dependent, they use the
		# ISO-Latin-1 definitions from CLDC 1.1 Character class.
		# <summary>
		# True if and only if the char (when converted from the int) is a
		# control character.
		# </summary>
		# <summary>
		# A character is punctuation if not cntrl, not alnum, and not space.
		# </summary>
		# From llex.c #FIXME:
		## assert currIsNewline() # skip '\n' or '\r' # skip '\n\r' or '\r\n' # overflow
		## assert s == '[' || s == ']' # skip 2nd `[' # string starts with a newline? # skip it # to avoid warnings # skip 2nd `]' # avoid wasting space # loop
		# <summary>
		# Lex a token and return it.  The semantic info for the token is
		# stored in <code>this.semR</code> or <code>this.semS</code> as
		# appropriate.
		# </summary>
		# else is a comment # `skip_sep' may dirty the buffer # long comment
		# else short comment # avoids Checkstyle warning.
		# assert !currIsNewline();
		# identifier or reserved word # single-char tokens
		# <summary>
		# Reads number.  Writes to semR. </summary>
		# assert isdigit(current); # 'E' ? # optional exponent sign
		# :todo: consider doing PUC-Rio's decimal point tricks.
		# <summary>
		# Reads string.  Writes to semS. </summary> # avoid compiler warning # avoid compiler warning # do not save the '\' # no '\a' in Java. # no '\v' in Java. # will raise an error next loop # handles \\, \", \', \? # \xxx
		# In unicode, there are no bounds on a 3-digit decimal. # skip delimiter
		# <summary>
		# Getter for source. </summary>
		# <summary>
		# Equivalent to <code>luaX_lexerror</code>. </summary>
		# <summary>
		# Equivalent to <code>luaX_next</code>. </summary> # is there a look-ahead token? # Use this one, # and discharge it.
		# <summary>
		# Equivalent to <code>luaX_syntaxerror</code>. </summary>
		# assert token == (char)token;
		# From lparser.c
		# <param name="what">   the token that is intended to end the match. </param>
		# <param name="who">    the token that begins the match. </param>
		# <param name="where">  the line number of <var>what</var>. </param> # final return;
		# :todo: check this is a valid assertion to make
		## assert fs != fs.prev
		# <summary>
		# Equivalent to luaY_parser. </summary>
		## assert fs.prev == null
		## assert fs.f.nups == 0
		## assert ls.fs == null
		# :todo: consider making a method in FuncState. # no more levels? # default is global variable # local will be used as an upval # not found at current level; try upper one # else was LOCAL or UPVAL
		# GRAMMAR RULES
		# chunk -> { stat [';'] }
		## assert fs.f.maxstacksize >= fs.freereg && fs.freereg >= fs.nactvar
		# constructor -> ?? # no value (yet) # fix it at stack top (for gc)
		## assert cc.v.k == Expdesc.VVOID || cc.tostore > 0 # may be listfields or recfields # expression? # constructor_item -> recfield # constructor_part -> listfield # set initial array size # set initial table size # exponent
		# recfield -> (NAME | `['exp1`]') = exp1
		# yChecklimit(fs, cc.nh, MAX_INT, "items in a constructor"); # token == '[' # free registers # do not count last expression (unknown number of elements) # there is no list item # flush # no more items pending
		# <returns> number of expressions in expression list. </returns>
		# explist1 -> expr { ',' expr } # at least one expression
		# stat -> func | assignment # stat -> func # call statement uses no results # stat -> assignment
		# 
		# ** check whether, in an assignment to a local variable, the local variable
		# ** is needed in a previous assignment (to a table). If so, save original
		# ** local value in a safe place and use this safe copy in the previous
		# ** assignment.
		#  # eventual position to save local variable # conflict? # previous assignment will use safe copy # conflict? # previous assignment will use safe copy # make copy # assignment -> `,' primaryexp assignment # assignment -> `=' explist1 # remove extra values # close last expression # avoid default # default assignment # funcargs -> '(' [ explist1 ] ')' # arg list is empty? # funcargs -> constructor # funcargs -> STRING # must use tokenS before 'next'
		# assert (f.kind() == VNONRELOC); # base register for call # open call # close last argument # call removes functions and arguments
		# and leaves (unless changed) one result.
		# prefixexp -> NAME | '(' expr ')'
		# primaryexp ->
		#    prefixexp { '.' NAME | '[' exp ']' | ':' NAME funcargs | funcargs } # field # `[' exp1 `]' # `:' NAME funcargs # funcargs
		# stat -> RETURN explist # skip RETURN
		# registers with returned values (first, nret)
		# return no values # tail call?
		## assert Lua.ARGA(fs.getcode(e)) == fs.nactvar # return all values # only one single value? # values must go to the `stack' # return all `active' values
		## assert nret == fs.freereg - first
		# simpleexp -> NUMBER | STRING | NIL | true | false | ... |
		#              constructor | FUNCTION body | primaryexp # vararg # constructor # stat -> ifstat # stat -> whilestat # stat -> DO block END # skip DO # stat -> forstat # stat -> repeatstat # stat -> funcstat # stat -> localstat # skip LOCAL # local function? # must be last statement # stat -> breakstat # skip BREAK # must be last statement
		# grep "ORDER OPR" if you change these enums.
		# default access so that FuncState can access them.
		self._OPR_ADD = 0
		self._OPR_SUB = 1
		self._OPR_MUL = 2
		self._OPR_DIV = 3
		self._OPR_MOD = 4
		self._OPR_POW = 5
		self._OPR_CONCAT = 6
		self._OPR_NE = 7
		self._OPR_EQ = 8
		self._OPR_LT = 9
		self._OPR_LE = 10
		self._OPR_GT = 11
		self._OPR_GE = 12
		self._OPR_AND = 13
		self._OPR_OR = 14
		self._OPR_NOBINOPR = 15
		self._OPR_MINUS = 0
		self._OPR_NOT = 1
		self._OPR_LEN = 2
		self._OPR_NOUNOPR = 3
		# <summary>
		# Converts token into binary operator. </summary>
		# ORDER OPR
		# <summary>
		# Priority table.  left-priority of an operator is
		# <code>priority[op][0]</code>, its right priority is
		# <code>priority[op][1]</code>.  Please do not modify this table.
		# </summary>
		self._PRIORITY = Array[int]((Array[int]((6, 6)), Array[int]((6, 6)), Array[int]((7, 7)), Array[int]((7, 7)), Array[int]((7, 7)), Array[int]((10, 9)), Array[int]((5, 4)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((2, 2)), Array[int]((1, 1))))
		# <summary>
		# Priority for unary operators. </summary>
		self._UNARY_PRIORITY = 8
		self._L = L
		self._z = z
		self._source_Renamed = source
		self.next()

	def __init__(self, L, z, source):
		self._EOZ = -1
		self._FIRST_RESERVED = 257
		self._TK_AND = self._FIRST_RESERVED + 0
		self._TK_BREAK = self._FIRST_RESERVED + 1
		self._TK_DO = self._FIRST_RESERVED + 2
		self._TK_ELSE = self._FIRST_RESERVED + 3
		self._TK_ELSEIF = self._FIRST_RESERVED + 4
		self._TK_END = self._FIRST_RESERVED + 5
		self._TK_FALSE = self._FIRST_RESERVED + 6
		self._TK_FOR = self._FIRST_RESERVED + 7
		self._TK_FUNCTION = self._FIRST_RESERVED + 8
		self._TK_IF = self._FIRST_RESERVED + 9
		self._TK_IN = self._FIRST_RESERVED + 10
		self._TK_LOCAL = self._FIRST_RESERVED + 11
		self._TK_NIL = self._FIRST_RESERVED + 12
		self._TK_NOT = self._FIRST_RESERVED + 13
		self._TK_OR = self._FIRST_RESERVED + 14
		self._TK_REPEAT = self._FIRST_RESERVED + 15
		self._TK_RETURN = self._FIRST_RESERVED + 16
		self._TK_THEN = self._FIRST_RESERVED + 17
		self._TK_TRUE = self._FIRST_RESERVED + 18
		self._TK_UNTIL = self._FIRST_RESERVED + 19
		self._TK_WHILE = self._FIRST_RESERVED + 20
		self._TK_CONCAT = self._FIRST_RESERVED + 21
		self._TK_DOTS = self._FIRST_RESERVED + 22
		self._TK_EQ = self._FIRST_RESERVED + 23
		self._TK_GE = self._FIRST_RESERVED + 24
		self._TK_LE = self._FIRST_RESERVED + 25
		self._TK_NE = self._FIRST_RESERVED + 26
		self._TK_NUMBER = self._FIRST_RESERVED + 27
		self._TK_NAME = self._FIRST_RESERVED + 28
		self._TK_STRING = self._FIRST_RESERVED + 29
		self._TK_EOS = self._FIRST_RESERVED + 30
		self._NUM_RESERVED = self._TK_WHILE - self._FIRST_RESERVED + 1
		self._tokens = Array[str](("and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "..", "...", "==", ">=", "<=", "~=", "<number>", "<name>", "<string>", "<eof>"))
		self._reserved = metamorphose.java.Hashtable()
		self._linenumber = 1
		self._lastline_Renamed = 1
		self._lookahead = self._TK_EOS
		self._buff = StringBuilder()
		self._decpoint = '.'
		self._OPR_ADD = 0
		self._OPR_SUB = 1
		self._OPR_MUL = 2
		self._OPR_DIV = 3
		self._OPR_MOD = 4
		self._OPR_POW = 5
		self._OPR_CONCAT = 6
		self._OPR_NE = 7
		self._OPR_EQ = 8
		self._OPR_LT = 9
		self._OPR_LE = 10
		self._OPR_GT = 11
		self._OPR_GE = 12
		self._OPR_AND = 13
		self._OPR_OR = 14
		self._OPR_NOBINOPR = 15
		self._OPR_MINUS = 0
		self._OPR_NOT = 1
		self._OPR_LEN = 2
		self._OPR_NOUNOPR = 3
		self._PRIORITY = Array[int]((Array[int]((6, 6)), Array[int]((6, 6)), Array[int]((7, 7)), Array[int]((7, 7)), Array[int]((7, 7)), Array[int]((10, 9)), Array[int]((5, 4)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((3, 3)), Array[int]((2, 2)), Array[int]((1, 1))))
		self._UNARY_PRIORITY = 8
		self._L = L
		self._z = z
		self._source_Renamed = source
		self.next()

	def lastline(self):
		return self._lastline_Renamed

	def isalnum(c):
		ch = c
		return Char.IsUpper(ch) or Char.IsLower(ch) or Char.IsDigit(ch)

	isalnum = staticmethod(isalnum)

	def isalpha(c):
		ch = c
		return Char.IsUpper(ch) or Char.IsLower(ch)

	isalpha = staticmethod(isalpha)

	def iscntrl(c):
		return c < 0x20 or c == 0x7f

	iscntrl = staticmethod(iscntrl)

	def isdigit(c):
		return Char.IsDigit(c)

	isdigit = staticmethod(isdigit)

	def islower(c):
		return Char.IsLower(c)

	islower = staticmethod(islower)

	def ispunct(c):
		return not Syntax.isalnum(c) and not Syntax.iscntrl(c) and not Syntax.isspace(c)

	ispunct = staticmethod(ispunct)

	def isspace(c):
		return c == ' ' or c == '\f' or c == '\n' or c == '\r' or c == '\t'

	isspace = staticmethod(isspace)

	def isupper(c):
		return Char.IsUpper(c)

	isupper = staticmethod(isupper)

	def isxdigit(c):
		return Char.IsDigit(c) or ('a' <= c and c <= 'f') or ('A' <= c and c <= 'F')

	isxdigit = staticmethod(isxdigit)

	def check_next(self, set):
		if set.IndexOf(self._current) < 0:
			return False
		self.save_and_next()
		return True

	def currIsNewline(self):
		return self._current == '\n' or self._current == '\r'

	def inclinenumber(self):
		old = self._current
		self.next()
		if self.currIsNewline() and self._current != old:
			self.next()
		self._linenumber += 1
		if self._linenumber < 0:
			self.xSyntaxerror("chunk has too many lines")

	def skip_sep(self):
		count = 0
		s = self._current
		self.save_and_next()
		while self._current == '=':
			self.save_and_next()
			count += 1
		return count if (self._current == s) else (-count) - 1

	def read_long_string(self, isString, sep):
		cont = 0
		self.save_and_next()
		if self.currIsNewline():
			self.inclinenumber()
		while True:
			if self._current == self._EOZ:
				self.xLexerror("unfinished long string" if isString else "unfinished long comment", self._TK_EOS)
			elif self._current == ']':
				if self.skip_sep() == sep:
					self.save_and_next()
			elif self._current == '\n' or self._current == '\r':
				self.save('\n')
				self.inclinenumber()
				if not isString:
					self._buff.Length = 0
			else:
				if isString:
					self.save_and_next()
				else:
					self.next()
		if isString:
			rawtoken = self._buff.ToString()
			trim_by = 2 + sep
			self._semS = rawtoken.Substring(trim_by, rawtoken.Length - trim_by - trim_by)

	def llex(self):
		self._buff.Length = 0
		while True:
			if self._current == '\n' or self._current == '\r':
				self.inclinenumber()
				continue
			elif self._current == '-':
				self.next()
				if self._current != '-':
					return '-'
				self.next()
				if self._current == '[':
					sep2 = self.skip_sep()
					self._buff.Length = 0
					if sep2 >= 0:
						self.read_long_string(False, sep2)
						self._buff.Length = 0
						continue
				while not self.currIsNewline() and self._current != self._EOZ:
					self.next()
				continue
			elif self._current == '[':
				sep = self.skip_sep()
				if sep >= 0:
					self.read_long_string(True, sep)
					return self._TK_STRING
				elif sep == -1:
					return '['
				else:
					self.xLexerror("invalid long string delimiter", self._TK_STRING)
				continue
			elif self._current == '=':
				self.next()
				if self._current != '=':
					return '='
				else:
					self.next()
					return self._TK_EQ
			elif self._current == '<':
				self.next()
				if self._current != '=':
					return '<'
				else:
					self.next()
					return self._TK_LE
			elif self._current == '>':
				self.next()
				if self._current != '=':
					return '>'
				else:
					self.next()
					return self._TK_GE
			elif self._current == '~':
				self.next()
				if self._current != '=':
					return '~'
				else:
					self.next()
					return self._TK_NE
			elif self._current == '"' or self._current == '\'':
				self.read_string(self._current)
				return self._TK_STRING
			elif self._current == '.':
				self.save_and_next()
				if self.check_next("."):
					if self.check_next("."):
						return self._TK_DOTS
					else:
						return self._TK_CONCAT
				elif not self.isdigit(self._current):
					return '.'
				else:
					self.read_numeral()
					return self._TK_NUMBER
			elif self._current == self._EOZ:
				return self._TK_EOS
			else:
				if self.isspace(self._current):
					self.next()
					continue
				elif self.isdigit(self._current):
					self.read_numeral()
					return self._TK_NUMBER
				elif self.isalpha(self._current) or self._current == '_':
					while self.isalnum(self._current) or self._current == '_':
						self.save_and_next()
					s = self._buff.ToString()
					t = self._reserved._get(s)
					if t == None:
						self._semS = s
						return self._TK_NAME
					else:
						return (t)
				else:
					c = self._current
					self.next()
					return c

	def next(self):
		self._current = self._z.read()

	def read_numeral(self):
		while self.isdigit(self._current) or self._current == '.':
			self.save_and_next()
		if self.check_next("Ee"):
			self.check_next("+-")
		while self.isalnum(self._current) or self._current == '_':
			self.save_and_next()
		try:
			self._semR = Convert.ToDouble(self._buff.ToString())
			return 
		except NumberFormatException:
			self.xLexerror("malformed number", self._TK_NUMBER)
		finally:
			pass

	def read_string(self, del_):
		self.save_and_next()
		while self._current != del_:
			if self._current == self._EOZ:
				self.xLexerror("unfinished string", self._TK_EOS)
				continue
			elif self._current == '\n' or self._current == '\r':
				self.xLexerror("unfinished string", self._TK_STRING)
				continue
			elif self._current == '\\':
				self.next()
				if self._current == 'a':
					c = 7
				elif self._current == 'b':
					c = '\b'
				elif self._current == 'f':
					c = '\f'
				elif self._current == 'n':
					c = '\n'
				elif self._current == 'r':
					c = '\r'
				elif self._current == 't':
					c = '\t'
				elif self._current == 'v':
					c = 11
				elif self._current == '\n' or self._current == '\r':
					self.save('\n')
					self.inclinenumber()
					continue
				elif self._current == self._EOZ:
					continue
				else:
					if not self.isdigit(self._current):
						self.save_and_next()
					else:
						i = 0
						c = 0
						i += 1
						while True:
							i += 1
							if i < 3 and self.isdigit(self._current):
								c = 10 * c + (self._current - '0')
								self.next()
							else:
								break
						self.save(c)
					continue
				self.save(c)
				self.next()
				continue
			else:
				self.save_and_next()
		self.save_and_next()
		rawtoken = self._buff.ToString()
		self._semS = rawtoken.Substring(1, rawtoken.Length - 1 - 1)

	def save(self):
		self._buff.Append(self._current)

	def save(self, c):
		self._buff.Append(c)

	def save_and_next(self):
		self.save()
		self.next()

	def source(self):
		return self._source_Renamed

	def txtToken(self, tok):
		if tok == self._TK_NAME or tok == self._TK_STRING or tok == self._TK_NUMBER:
			return self._buff.ToString()
		else:
			return self.xToken2str(tok)

	def xLexerror(self, msg, tok):
		msg = self._source_Renamed + ":" + self._linenumber + ": " + msg
		if tok != 0:
			msg = msg + " near '" + self.txtToken(tok) + "'"
		self._L.pushString(msg)
		self._L.dThrow(Lua.ERRSYNTAX)

	def xNext(self):
		self._lastline_Renamed = self._linenumber
		if self._lookahead != self._TK_EOS:
			self._token = self._lookahead
			self._tokenR = self._lookaheadR
			self._tokenS = self._lookaheadS
			self._lookahead = self._TK_EOS
		else:
			self._token = self.llex()
			self._tokenR = self._semR
			self._tokenS = self._semS

	def xSyntaxerror(self, msg):
		self.xLexerror(msg, self._token)

	def xToken2str(token):
		if token < self._FIRST_RESERVED:
			if Syntax.iscntrl(token):
				return "char(" + token + ")"
			return (System.Nullable[Char](token)).ToString()
		return self._tokens[token - self._FIRST_RESERVED]

	xToken2str = staticmethod(xToken2str)

	def block_follow(token):
		if token == self._TK_ELSE or token == self._TK_ELSEIF or token == self._TK_END or token == self._TK_UNTIL or token == self._TK_EOS:
			return True
		else:
			return False

	block_follow = staticmethod(block_follow)

	def check(self, c):
		if self._token != c:
			self.error_expected(c)

	def check_match(self, what, who, where):
		if not self.testnext(what):
			if where == self._linenumber:
				self.error_expected(what)
			else:
				self.xSyntaxerror("'" + self.xToken2str(what) + "' expected (to close '" + self.xToken2str(who) + "' at line " + where + ")")

	def close_func(self):
		self.removevars(0)
		self._fs.kRet(0, 0)
		self._fs.close()
		self._fs = self._fs.prev

	def opcode_name(op):
		if op == Lua.OP_MOVE:
			return "MOVE"
		elif op == Lua.OP_LOADK:
			return "LOADK"
		elif op == Lua.OP_LOADBOOL:
			return "LOADBOOL"
		elif op == Lua.OP_LOADNIL:
			return "LOADNIL"
		elif op == Lua.OP_GETUPVAL:
			return "GETUPVAL"
		elif op == Lua.OP_GETGLOBAL:
			return "GETGLOBAL"
		elif op == Lua.OP_GETTABLE:
			return "GETTABLE"
		elif op == Lua.OP_SETGLOBAL:
			return "SETGLOBAL"
		elif op == Lua.OP_SETUPVAL:
			return "SETUPVAL"
		elif op == Lua.OP_SETTABLE:
			return "SETTABLE"
		elif op == Lua.OP_NEWTABLE:
			return "NEWTABLE"
		elif op == Lua.OP_SELF:
			return "SELF"
		elif op == Lua.OP_ADD:
			return "ADD"
		elif op == Lua.OP_SUB:
			return "SUB"
		elif op == Lua.OP_MUL:
			return "MUL"
		elif op == Lua.OP_DIV:
			return "DIV"
		elif op == Lua.OP_MOD:
			return "MOD"
		elif op == Lua.OP_POW:
			return "POW"
		elif op == Lua.OP_UNM:
			return "UNM"
		elif op == Lua.OP_NOT:
			return "NOT"
		elif op == Lua.OP_LEN:
			return "LEN"
		elif op == Lua.OP_CONCAT:
			return "CONCAT"
		elif op == Lua.OP_JMP:
			return "JMP"
		elif op == Lua.OP_EQ:
			return "EQ"
		elif op == Lua.OP_LT:
			return "LT"
		elif op == Lua.OP_LE:
			return "LE"
		elif op == Lua.OP_TEST:
			return "TEST"
		elif op == Lua.OP_TESTSET:
			return "TESTSET"
		elif op == Lua.OP_CALL:
			return "CALL"
		elif op == Lua.OP_TAILCALL:
			return "TAILCALL"
		elif op == Lua.OP_RETURN:
			return "RETURN"
		elif op == Lua.OP_FORLOOP:
			return "FORLOOP"
		elif op == Lua.OP_FORPREP:
			return "FORPREP"
		elif op == Lua.OP_TFORLOOP:
			return "TFORLOOP"
		elif op == Lua.OP_SETLIST:
			return "SETLIST"
		elif op == Lua.OP_CLOSE:
			return "CLOSE"
		elif op == Lua.OP_CLOSURE:
			return "CLOSURE"
		elif op == Lua.OP_VARARG:
			return "VARARG"
		else:
			return "??" + op

	opcode_name = staticmethod(opcode_name)

	def codestring(self, e, s):
		e.init(Expdesc.VK, self._fs.kStringK(s))

	def checkname(self, e):
		self.codestring(e, self.str_checkname())

	def enterlevel(self):
		self._L.nCcalls += 1

	def error_expected(self, tok):
		self.xSyntaxerror("'" + self.xToken2str(tok) + "' expected")

	def leavelevel(self):
		self._L.nCcalls -= 1

	def parser(L, in_, name):
		ls = Syntax(L, in_, name)
		fs = FuncState(ls)
		ls.open_func(self._fs)
		self._fs.f.setIsVararg()
		ls.xNext()
		ls.chunk()
		ls.check(self._TK_EOS)
		ls.close_func()
		return self._fs.f

	parser = staticmethod(parser)

	def removevars(self, tolevel):
		while self._fs.nactvar > tolevel:
			self._fs.nactvar -= 1
			self._fs.getlocvar(self._fs.nactvar).endpc = self._fs.pc

	def singlevar(self, var):
		varname = self.str_checkname()
		if self.singlevaraux(self._fs, varname, var, True) == Expdesc.VGLOBAL:
			var.Info = self._fs.kStringK(varname)

	def singlevaraux(self, f, n, var, base):
		if f == None:
			var.init(Expdesc.VGLOBAL, Lua.NO_REG)
			return Expdesc.VGLOBAL
		else:
			v = f.searchvar(n)
			if v >= 0:
				var.init(Expdesc.VLOCAL, v)
				if not base:
					f.markupval(v)
				return Expdesc.VLOCAL
			else:
				if self.singlevaraux(f.prev, n, var, False) == Expdesc.VGLOBAL:
					return Expdesc.VGLOBAL
				var.upval(self.indexupvalue(f, n, var))
				return Expdesc.VUPVAL

	def str_checkname(self):
		self.check(self._TK_NAME)
		s = self._tokenS
		self.xNext()
		return s

	def testnext(self, c):
		if self._token == c:
			self.xNext()
			return True
		return False

	def chunk(self):
		islast = False
		self.enterlevel()
		while not islast and not self.block_follow(self._token):
			islast = self.statement()
			self.testnext(';')
			self._fs.freereg_Renamed = self._fs.nactvar
		self.leavelevel()

	def constructor(self, t):
		line = self._linenumber
		pc = self._fs.kCodeABC(Lua.OP_NEWTABLE, 0, 0, 0)
		cc = ConsControl(t)
		t.init(Expdesc.VRELOCABLE, pc)
		cc.v.init(Expdesc.VVOID, 0)
		self._fs.kExp2nextreg(t)
		self.checknext('{')
		while self.testnext(',') or self.testnext(';'):
			if self._token == '}':
				break
			self.closelistfield(cc)
			if self._token == self._TK_NAME:
				self.xLookahead()
				if self._lookahead != '=':
					self.listfield(cc)
				else:
					self.recfield(cc)
			elif self._token == '[':
				self.recfield(cc)
			else:
				self.listfield(cc)
		self.check_match('}', '{', line)
		self.lastlistfield(cc)
		code = self._fs.f.code_Renamed
		code[pc] = Lua.SETARG_B(code[pc], self.oInt2fb(cc.na))
		code[pc] = Lua.SETARG_C(code[pc], self.oInt2fb(cc.nh))

	def oInt2fb(x):
		e = 0
		while x < 0 or x >= 16:
			x = ((x + 1) >> 1)
			e += 1
		return x if (x < 8) else (((e + 1) << 3) | (x - 8))

	oInt2fb = staticmethod(oInt2fb)

	def recfield(self, cc):
		reg = self._fs.freereg_Renamed
		key = Expdesc()
		val = Expdesc()
		if self._token == self._TK_NAME:
			self.checkname(key)
		else:
			self.yindex(key)
		cc.nh += 1
		self.checknext('=')
		self._fs.kExp2RK(key)
		self.expr(val)
		self._fs.kCodeABC(Lua.OP_SETTABLE, cc.t.info_Renamed, self._fs.kExp2RK(key), self._fs.kExp2RK(val))
		self._fs.freereg_Renamed = reg

	def lastlistfield(self, cc):
		if cc.tostore == 0:
			return 
		if self.hasmultret(cc.v.k):
			self._fs.kSetmultret(cc.v)
			self._fs.kSetlist(cc.t.info_Renamed, cc.na, Lua.MULTRET)
			cc.na -= 1
		else:
			if cc.v.k != Expdesc.VVOID:
				self._fs.kExp2nextreg(cc.v)
			self._fs.kSetlist(cc.t.info_Renamed, cc.na, cc.tostore)

	def closelistfield(self, cc):
		if cc.v.k == Expdesc.VVOID:
			return 
		self._fs.kExp2nextreg(cc.v)
		cc.v.k = Expdesc.VVOID
		if cc.tostore == Lua.LFIELDS_PER_FLUSH:
			self._fs.kSetlist(cc.t.info_Renamed, cc.na, cc.tostore)
			cc.tostore = 0

	def expr(self, v):
		self.subexpr(v, 0)

	def explist1(self, v):
		n = 1
		self.expr(v)
		while self.testnext(','):
			self._fs.kExp2nextreg(v)
			self.expr(v)
			n += 1
		return n

	def exprstat(self):
		v = LHSAssign()
		self.primaryexp(v.v)
		if v.v.k == Expdesc.VCALL:
			self._fs.setargc(v.v, 1)
		else:
			v.prev = None
			self.assignment(v, 1)

	def check_conflict(self, lh, v):
		extra = self._fs.freereg_Renamed
		conflict = False
		while lh != None:
			if lh.v.k == Expdesc.VINDEXED:
				if lh.v.info_Renamed == v.info_Renamed:
					conflict = True
					lh.v.info_Renamed = extra
				if lh.v.aux_Renamed == v.info_Renamed:
					conflict = True
					lh.v.aux_Renamed = extra
			lh = lh.prev
		if conflict:
			self._fs.kCodeABC(Lua.OP_MOVE, self._fs.freereg_Renamed, v.info_Renamed, 0)
			self._fs.kReserveregs(1)

	def assignment(self, lh, nvars):
		e = Expdesc()
		kind = lh.v.k
		if not (Expdesc.VLOCAL <= kind and kind <= Expdesc.VINDEXED):
			self.xSyntaxerror("syntax error")
		if self.testnext(','):
			nv = LHSAssign(lh)
			self.primaryexp(nv.v)
			if nv.v.k == Expdesc.VLOCAL:
				self.check_conflict(lh, nv.v)
			self.assignment(nv, nvars + 1)
		else:
			self.checknext('=')
			nexps = self.explist1(e)
			if nexps != nvars:
				self.adjust_assign(nvars, nexps, e)
				if nexps > nvars:
					self._fs.freereg_Renamed -= (nexps - nvars)
			else:
				self._fs.kSetoneret(e)
				self._fs.kStorevar(lh.v, e)
				return 
		e.init(Expdesc.VNONRELOC, self._fs.freereg_Renamed - 1)
		self._fs.kStorevar(lh.v, e)

	def funcargs(self, f):
		args = Expdesc()
		line = self._linenumber
		if self._token == '(':
			if line != self._lastline_Renamed:
				self.xSyntaxerror("ambiguous syntax (function call x new statement)")
			self.xNext()
			if self._token == ')':
				args.Kind = Expdesc.VVOID
			else:
				self.explist1(args)
				self._fs.kSetmultret(args)
			self.check_match(')', '(', line)
		elif self._token == '{':
			self.constructor(args)
		elif self._token == self._TK_STRING:
			self.codestring(args, self._tokenS)
			self.xNext()
		else:
			self.xSyntaxerror("function arguments expected")
			return 
		base = f.info()
		if args.hasmultret():
			nparams = Lua.MULTRET
		else:
			if args.kind() != Expdesc.VVOID:
				self._fs.kExp2nextreg(args)
			nparams = self._fs.freereg_Renamed - (base + 1)
		f.init(Expdesc.VCALL, self._fs.kCodeABC(Lua.OP_CALL, base, nparams + 1, 2))
		self._fs.kFixline(line)
		self._fs.freereg_Renamed = base + 1

	def prefixexp(self, v):
		if self._token == '(':
			line = self._linenumber
			self.xNext()
			self.expr(v)
			self.check_match(')', '(', line)
			self._fs.kDischargevars(v)
			return 
		elif self._token == self._TK_NAME:
			self.singlevar(v)
			return 
		else:
			self.xSyntaxerror("unexpected symbol")
			return 

	def primaryexp(self, v):
		self.prefixexp(v)
		while True:
			if self._token == '.':
				self.field(v)
			elif self._token == '[':
				key = Expdesc()
				self._fs.kExp2anyreg(v)
				self.yindex(key)
				self._fs.kIndexed(v, key)
			elif self._token == ':':
				key = Expdesc()
				self.xNext()
				self.checkname(key)
				self._fs.kSelf(v, key)
				self.funcargs(v)
			elif self._token == '(' or self._token == self._TK_STRING or self._token == '{':
				self._fs.kExp2nextreg(v)
				self.funcargs(v)
			else:
				return 

	def retstat(self):
		self.xNext()
		first = 0
		if self.block_follow(self._token) or self._token == ';':
			first = 0
			nret = 0
		else:
			e = Expdesc()
			nret = self.explist1(e)
			if self.hasmultret(e.k):
				self._fs.kSetmultret(e)
				if e.k == Expdesc.VCALL and nret == 1:
					self._fs.setcode(e, Lua.SET_OPCODE(self._fs.getcode(e), Lua.OP_TAILCALL))
				first = self._fs.nactvar
				nret = Lua.MULTRET
			else:
				if nret == 1:
					first = self._fs.kExp2anyreg(e)
				else:
					self._fs.kExp2nextreg(e)
					first = self._fs.nactvar
		self._fs.kRet(first, nret)

	def simpleexp(self, v):
		if self._token == self._TK_NUMBER:
			v.init(Expdesc.VKNUM, 0)
			v.nval_Renamed = self._tokenR
		elif self._token == self._TK_STRING:
			self.codestring(v, self._tokenS)
		elif self._token == self._TK_NIL:
			v.init(Expdesc.VNIL, 0)
		elif self._token == self._TK_TRUE:
			v.init(Expdesc.VTRUE, 0)
		elif self._token == self._TK_FALSE:
			v.init(Expdesc.VFALSE, 0)
		elif self._token == self._TK_DOTS:
			if not self._fs.f.Vararg:
				self.xSyntaxerror("cannot use \"...\" outside a vararg function")
			v.init(Expdesc.VVARARG, self._fs.kCodeABC(Lua.OP_VARARG, 0, 1, 0))
		elif self._token == '{':
			self.constructor(v)
			return 
		elif self._token == self._TK_FUNCTION:
			self.xNext()
			self.body(v, False, self._linenumber)
			return 
		else:
			self.primaryexp(v)
			return 
		self.xNext()

	def statement(self):
		line = self._linenumber
		if self._token == self._TK_IF:
			self.ifstat(line)
			return False
		elif self._token == self._TK_WHILE:
			self.whilestat(line)
			return False
		elif self._token == self._TK_DO:
			self.xNext()
			self.block()
			self.check_match(self._TK_END, self._TK_DO, line)
			return False
		elif self._token == self._TK_FOR:
			self.forstat(line)
			return False
		elif self._token == self._TK_REPEAT:
			self.repeatstat(line)
			return False
		elif self._token == self._TK_FUNCTION:
			self.funcstat(line)
			return False
		elif self._token == self._TK_LOCAL:
			self.xNext()
			if self.testnext(self._TK_FUNCTION):
				self.localfunc()
			else:
				self.localstat()
			return False
		elif self._token == self._TK_RETURN:
			self.retstat()
			return True
		elif self._token == self._TK_BREAK:
			self.xNext()
			self.breakstat()
			return True
		else:
			self.exprstat()
			return False

	def getbinopr(op):
		if op == '+':
			return self._OPR_ADD
		elif op == '-':
			return self._OPR_SUB
		elif op == '*':
			return self._OPR_MUL
		elif op == '/':
			return self._OPR_DIV
		elif op == '%':
			return self._OPR_MOD
		elif op == '^':
			return self._OPR_POW
		elif op == self._TK_CONCAT:
			return self._OPR_CONCAT
		elif op == self._TK_NE:
			return self._OPR_NE
		elif op == self._TK_EQ:
			return self._OPR_EQ
		elif op == '<':
			return self._OPR_LT
		elif op == self._TK_LE:
			return self._OPR_LE
		elif op == '>':
			return self._OPR_GT
		elif op == self._TK_GE:
			return self._OPR_GE
		elif op == self._TK_AND:
			return self._OPR_AND
		elif op == self._TK_OR:
			return self._OPR_OR
		else:
			return self._OPR_NOBINOPR

	getbinopr = staticmethod(getbinopr)

	def getunopr(op):
		if op == self._TK_NOT:
			return self._OPR_NOT
		elif op == '-':
			return self._OPR_MINUS
		elif op == '#':
			return self._OPR_LEN
		else:
			return self._OPR_NOUNOPR

	getunopr = staticmethod(getunopr)

	def subexpr(self, v, limit):
		""" <summary>
		 Operator precedence parser.
		 <code>subexpr -> (simpleexp) | unop subexpr) { binop subexpr }</code>
		 where <var>binop</var> is any binary operator with a priority
		 higher than <var>limit</var>.
		 </summary>
		"""
		self.enterlevel()
		uop = self.getunopr(self._token)
		if uop != self._OPR_NOUNOPR:
			self.xNext()
			self.subexpr(v, self._UNARY_PRIORITY)
			self._fs.kPrefix(uop, v)
		else:
			self.simpleexp(v)
		# expand while operators have priorities higher than 'limit'
		op = self.getbinopr(self._token)
		while op != self._OPR_NOBINOPR and self._PRIORITY[op][0] > limit:
			v2 = Expdesc()
			self.xNext()
			self._fs.kInfix(op, v)
			# read sub-expression with higher priority
			nextop = self.subexpr(v2, self._PRIORITY[op][1])
			self._fs.kPosfix(op, v, v2)
			op = nextop
		self.leavelevel()
		return op

	def enterblock(self, f, bl, isbreakable):
		bl.breaklist = FuncState.NO_JUMP
		bl.isbreakable = isbreakable
		bl.nactvar = f.nactvar
		bl.upval = False
		bl.previous = f.bl
		f.bl = bl

	## assert f.freereg == f.nactvar
	def leaveblock(self, f):
		bl = f.bl
		f.bl = bl.previous
		self.removevars(bl.nactvar)
		if bl.upval:
			f.kCodeABC(Lua.OP_CLOSE, bl.nactvar, 0, 0)
		# loops have no body
		## assert (!bl.isbreakable) || (!bl.upval)
		## assert bl.nactvar == f.nactvar
		f.freereg_Renamed = f.nactvar # free registers
		f.kPatchtohere(bl.breaklist)

	# 
	# ** {======================================================================
	# ** Rules for Statements
	# ** =======================================================================
	# 
	def block(self):
		# block -> chunk
		bl = BlockCnt()
		self.enterblock(self._fs, bl, False)
		self.chunk()
		## assert bl.breaklist == FuncState.NO_JUMP
		self.leaveblock(self._fs)

	def breakstat(self):
		bl = self._fs.bl
		upval = False
		while bl != None and not bl.isbreakable:
			upval |= bl.upval
			bl = bl.previous
		if bl == None:
			self.xSyntaxerror("no loop to break")
		if upval:
			self._fs.kCodeABC(Lua.OP_CLOSE, bl.nactvar, 0, 0)
		bl.breaklist = self._fs.kConcat(bl.breaklist, self._fs.kJump())

	def funcstat(self, line):
		# funcstat -> FUNCTION funcname body
		b = Expdesc()
		v = Expdesc()
		self.xNext() # skip FUNCTION
		needself = self.funcname(v)
		self.body(b, needself, line)
		self._fs.kStorevar(v, b)
		self._fs.kFixline(line)
 # definition `happens' in the first line
	def checknext(self, c):
		self.check(c)
		self.xNext()

	def parlist(self):
		# parlist -> [ param { `,' param } ]
		f = self._fs.f
		nparams = 0
		if self._token != ')': # is `parlist' not empty? # param -> NAME # param -> `...'
			while (not f.Vararg) and self.testnext(','):
				if self._token == self._TK_NAME:
					self.new_localvar(self.str_checkname(), nparams)
					nparams += 1
					break
				elif self._token == self._TK_DOTS:
					self.xNext()
					f.setIsVararg()
					break
				else:
					self.xSyntaxerror("<name> or '...' expected")
		self.adjustlocalvars(nparams)
		f.numparams_Renamed = self._fs.nactvar # VARARG_HASARG not now used
		self._fs.kReserveregs(self._fs.nactvar)
 # reserve register for parameters
	def getlocvar(self, i):
		fstate = self._fs
		return fstate.f.locvars_Renamed[fstate.actvar[i]]

	def adjustlocalvars(self, nvars):
		self._fs.nactvar += nvars #(short)nvars
		while nvars != 0:
			self.getlocvar(self._fs.nactvar - nvars).startpc = self._fs.pc
			nvars -= 1

	def new_localvarliteral(self, v, n):
		self.new_localvar(v, n)

	def errorlimit(self, limit, what):
		msg = "main function has more than " + limit + " " + what if self._fs.f.linedefined_Renamed == 0 else "function at line " + self._fs.f.linedefined_Renamed + " has more than " + limit + " " + what
		self.xLexerror(msg, 0)

	def yChecklimit(self, v, l, m):
		if v > l:
			self.errorlimit(l, m)

	def new_localvar(self, name, n):
		self.yChecklimit(self._fs.nactvar + n + 1, Lua.MAXVARS, "local variables")
		self._fs.actvar[self._fs.nactvar + n] = self.registerlocalvar(name)

	def registerlocalvar(self, varname):
		f = self._fs.f
		f.ensureLocvars(self._L, self._fs.nlocvars, Int16.MaxValue)
		f.locvars_Renamed[self._fs.nlocvars].varname = varname
		result = self._fs.nlocvars
		self._fs.nlocvars += 1
		return result

	def body(self, e, needself, line):
		# body ->  `(' parlist `)' chunk END
		new_fs = FuncState(self)
		self.open_func(new_fs)
		new_fs.f.linedefined_Renamed = line
		self.checknext('(')
		if needself:
			self.new_localvarliteral("self", 0)
			self.adjustlocalvars(1)
		self.parlist()
		self.checknext(')')
		self.chunk()
		new_fs.f.lastlinedefined_Renamed = self._linenumber
		self.check_match(self._TK_END, self._TK_FUNCTION, line)
		self.close_func()
		self.pushclosure(new_fs, e)

	def UPVAL_K(self, upvaldesc):
		return ((upvaldesc >> 8)) & 0xFF

	def UPVAL_INFO(self, upvaldesc):
		return upvaldesc & 0xFF

	def UPVAL_ENCODE(self, k, info):
		## assert (k & 0xFF) == k && (info & 0xFF) == info
		return ((k & 0xFF) << 8) | (info & 0xFF)

	def pushclosure(self, func, v):
		f = self._fs.f
		f.ensureProtos(self._L, self._fs.np)
		ff = func.f
		f.p[self._fs.np] = ff
		self._fs.np += 1
		v.init(Expdesc.VRELOCABLE, self._fs.kCodeABx(Lua.OP_CLOSURE, 0, self._fs.np - 1))
		i = 0
		while i < ff.nups_Renamed:
			upvalue = func.upvalues[i]
			o = Lua.OP_MOVE if (self.UPVAL_K(upvalue) == Expdesc.VLOCAL) else Lua.OP_GETUPVAL
			self._fs.kCodeABC(o, 0, self.UPVAL_INFO(upvalue), 0)
			i += 1

	def funcname(self, v):
		# funcname -> NAME {field} [`:' NAME]
		needself = False
		self.singlevar(v)
		while self._token == '.':
			self.field(v)
		if self._token == ':':
			needself = True
			self.field(v)
		return needself

	def field(self, v):
		# field -> ['.' | ':'] NAME
		key = Expdesc()
		self._fs.kExp2anyreg(v)
		self.xNext() # skip the dot or colon
		self.checkname(key)
		self._fs.kIndexed(v, key)

	def repeatstat(self, line):
		# repeatstat -> REPEAT block UNTIL cond
		repeat_init = self._fs.kGetlabel()
		bl1 = BlockCnt()
		bl2 = BlockCnt()
		self.enterblock(self._fs, bl1, True) # loop block
		self.enterblock(self._fs, bl2, False) # scope block
		self.xNext() # skip REPEAT
		self.chunk()
		self.check_match(self._TK_UNTIL, self._TK_REPEAT, line)
		condexit = self.cond() # read condition (inside scope block)
		if not bl2.upval: # no upvalues?
			self.leaveblock(self._fs) # finish scope
			self._fs.kPatchlist(condexit, repeat_init)
		else: # close the loop # complete semantics when there are upvalues
			self.breakstat() # if condition then break
			self._fs.kPatchtohere(condexit) # else...
			self.leaveblock(self._fs) # finish scope...
			self._fs.kPatchlist(self._fs.kJump(), repeat_init) # and repeat
		self.leaveblock(self._fs)
 # finish loop
	def cond(self):
		# cond -> exp
		v = Expdesc()
		self.expr(v) # read condition
		if v.k == Expdesc.VNIL:
			v.k = Expdesc.VFALSE # `falses' are all equal here
		self._fs.kGoiftrue(v)
		return v.f

	def open_func(self, funcstate):
		f = Proto(self._source_Renamed, 2) # registers 0/1 are always valid
		funcstate.f = f
		funcstate.ls = self
		funcstate.L = self._L
		funcstate.prev = self._fs # linked list of funcstates
		self._fs = funcstate

	def localstat(self):
		# stat -> LOCAL NAME {`,' NAME} [`=' explist1]
		nvars = 0
		e = Expdesc()
		while self.testnext(','):
			self.new_localvar(self.str_checkname(), nvars)
			nvars += 1
		if self.testnext('='):
			nexps = self.explist1(e)
		else:
			e.k = Expdesc.VVOID
			nexps = 0
		self.adjust_assign(nvars, nexps, e)
		self.adjustlocalvars(nvars)

	def forstat(self, line):
		# forstat -> FOR (fornum | forlist) END
		bl = BlockCnt()
		self.enterblock(self._fs, bl, True) # scope for loop and control variables
		self.xNext() # skip `for'
		varname = self.str_checkname() # first variable name
		if self._token == '=':
			self.fornum(varname, line)
		elif self._token == ',' or self._token == self._TK_IN:
			self.forlist(varname)
		else:
			self.xSyntaxerror("\"=\" or \"in\" expected")
		self.check_match(self._TK_END, self._TK_FOR, line)
		self.leaveblock(self._fs)
 # loop scope (`break' jumps to this point)
	def fornum(self, varname, line):
		# fornum -> NAME = exp1,exp1[,exp1] forbody
		base = self._fs.freereg_Renamed
		self.new_localvarliteral("(for index)", 0)
		self.new_localvarliteral("(for limit)", 1)
		self.new_localvarliteral("(for step)", 2)
		self.new_localvar(varname, 3)
		self.checknext('=')
		self.exp1() # initial value
		self.checknext(',')
		self.exp1() # limit
		if self.testnext(','):
			self.exp1()
		else: # optional step # default step = 1
			self._fs.kCodeABx(Lua.OP_LOADK, self._fs.freereg_Renamed, self._fs.kNumberK(1))
			self._fs.kReserveregs(1)
		self.forbody(base, line, 1, True)

	def exp1(self):
		e = Expdesc()
		self.expr(e)
		k = e.k
		self._fs.kExp2nextreg(e)
		return k

	def forlist(self, indexname):
		# forlist -> NAME {,NAME} IN explist1 forbody
		e = Expdesc()
		nvars = 0
		base = self._fs.freereg_Renamed
		# create control variables
		self.new_localvarliteral("(for generator)", nvars)
		nvars += 1
		self.new_localvarliteral("(for state)", nvars)
		nvars += 1
		self.new_localvarliteral("(for control)", nvars)
		nvars += 1
		# create declared variables
		self.new_localvar(indexname, nvars)
		nvars += 1
		while self.testnext(','):
			self.new_localvar(self.str_checkname(), nvars)
			nvars += 1
		self.checknext(self._TK_IN)
		line = self._linenumber
		self.adjust_assign(3, self.explist1(e), e)
		self._fs.kCheckstack(3) # extra space to call generator
		self.forbody(base, line, nvars - 3, False)

	def forbody(self, base, line, nvars, isnum):
		# forbody -> DO block
		bl = BlockCnt()
		self.adjustlocalvars(3) # control variables
		self.checknext(self._TK_DO)
		prep = self._fs.kCodeAsBx(Lua.OP_FORPREP, base, FuncState.NO_JUMP) if isnum else self._fs.kJump()
		self.enterblock(self._fs, bl, False) # scope for declared variables
		self.adjustlocalvars(nvars)
		self._fs.kReserveregs(nvars)
		self.block()
		self.leaveblock(self._fs) # end of scope for declared variables
		self._fs.kPatchtohere(prep)
		endfor = self._fs.kCodeAsBx(Lua.OP_FORLOOP, base, FuncState.NO_JUMP) if isnum else self._fs.kCodeABC(Lua.OP_TFORLOOP, base, 0, nvars)
		self._fs.kFixline(line) # pretend that `OP_FOR' starts the loop
		self._fs.kPatchlist((endfor if isnum else self._fs.kJump()), prep + 1)

	def ifstat(self, line):
		# ifstat -> IF cond THEN block {ELSEIF cond THEN block} [ELSE block] END
		escapelist = FuncState.NO_JUMP
		flist = self.test_then_block() # IF cond THEN block
		while self._token == self._TK_ELSEIF:
			escapelist = self._fs.kConcat(escapelist, self._fs.kJump())
			self._fs.kPatchtohere(flist)
			flist = self.test_then_block() # ELSEIF cond THEN block
		if self._token == self._TK_ELSE:
			escapelist = self._fs.kConcat(escapelist, self._fs.kJump())
			self._fs.kPatchtohere(flist)
			self.xNext() # skip ELSE (after patch, for correct line info)
			self.block()
		else: # `else' part
			escapelist = self._fs.kConcat(escapelist, flist)
		self._fs.kPatchtohere(escapelist)
		self.check_match(self._TK_END, self._TK_IF, line)

	def test_then_block(self):
		# test_then_block -> [IF | ELSEIF] cond THEN block
		self.xNext() # skip IF or ELSEIF
		condexit = self.cond()
		self.checknext(self._TK_THEN)
		self.block() # `then' part
		return condexit

	def whilestat(self, line):
		# whilestat -> WHILE cond DO block END
		bl = BlockCnt()
		self.xNext() # skip WHILE
		whileinit = self._fs.kGetlabel()
		condexit = self.cond()
		self.enterblock(self._fs, bl, True)
		self.checknext(self._TK_DO)
		self.block()
		self._fs.kPatchlist(self._fs.kJump(), whileinit)
		self.check_match(self._TK_END, self._TK_WHILE, line)
		self.leaveblock(self._fs)
		self._fs.kPatchtohere(condexit)
 # false conditions finish the loop
	def hasmultret(k):
		return k == Expdesc.VCALL or k == Expdesc.VVARARG

	hasmultret = staticmethod(hasmultret)

	def adjust_assign(self, nvars, nexps, e):
		extra = nvars - nexps
		if self.hasmultret(e.k):
			extra += 1 # includes call itself
			if extra < 0:
				extra = 0
			self._fs.kSetreturns(e, extra) # last exp. provides the difference
			if extra > 1:
				self._fs.kReserveregs(extra - 1)
		else:
			if e.k != Expdesc.VVOID:
				self._fs.kExp2nextreg(e) # close last expression
			if extra > 0:
				reg = self._fs.freereg_Renamed
				self._fs.kReserveregs(extra)
				self._fs.kNil(reg, extra)

	def localfunc(self):
		b = Expdesc()
		self.new_localvar(self.str_checkname(), 0)
		v = Expdesc(Expdesc.VLOCAL, self._fs.freereg_Renamed)
		self._fs.kReserveregs(1)
		self.adjustlocalvars(1)
		self.body(b, False, self._linenumber)
		self._fs.kStorevar(v, b)
		# debug information will only see the variable after this point!
		self._fs.getlocvar(self._fs.nactvar - 1).startpc = self._fs.pc

	def yindex(self, v):
		# index -> '[' expr ']'
		self.xNext() # skip the '['
		self.expr(v)
		self._fs.kExp2val(v)
		self.checknext(']')

	def xLookahead(self):
		## assert lookahead == TK_EOS
		self._lookahead = self.llex()
		self._lookaheadR = self._semR
		self._lookaheadS = self._semS

	def listfield(self, cc):
		self.expr(cc.v)
		self.yChecklimit(cc.na, Lua.MAXARG_Bx, "items in a constructor")
		cc.na += 1
		cc.tostore += 1

	def indexupvalue(self, funcstate, name, v):
		f = funcstate.f
		oldsize = f.sizeupvalues
		i = 0
		while i < f.nups_Renamed:
			entry = funcstate.upvalues[i]
			if self.UPVAL_K(entry) == v.k and self.UPVAL_INFO(entry) == v.info_Renamed:
				## assert name.equals(f.upvalues[i])
				return i
			i += 1
		# new one
		self.yChecklimit(f.nups_Renamed + 1, Lua.MAXUPVALUES, "upvalues")
		f.ensureUpvals(self._L, f.nups_Renamed)
		f.upvalues[f.nups_Renamed] = name
		## assert v.k == Expdesc.VLOCAL || v.k == Expdesc.VUPVAL
		funcstate.upvalues[f.nups_Renamed] = self.UPVAL_ENCODE(v.k, v.info_Renamed)
		result = f.nups_Renamed
		f.nups_Renamed += 1
		return result

class LHSAssign(object):
	def __init__(self, prev):
		self._v = Expdesc()
		self._prev = prev

	def __init__(self, prev):
		self._v = Expdesc()
		self._prev = prev

class ConsControl(object): # last list item read # table descriptor # total number of `record' elements # total number of array elements # number of array elements pending to be stored
	def __init__(self, t):
		self._v = Expdesc()
		self._t = t