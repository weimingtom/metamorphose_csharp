﻿# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Expdesc.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class Expdesc(object):
	""" <summary>
	 Equivalent to struct expdesc. </summary>
	""" # no value # info = index into 'k' # nval = numerical value # info = local register # info = index into 'upvalues' # info = index of table;
	# aux = index of global name in 'k' # info = table register
	# aux = index register (or 'k') # info = instruction pc # info = instruction pc # info = result register # info = instruction pc # info = instruction pc # one of V* enums above
	def __init__(self, k, i):
		self._VVOID = 0
		self._VNIL = 1
		self._VTRUE = 2
		self._VFALSE = 3
		self._VK = 4
		self._VKNUM = 5
		self._VLOCAL = 6
		self._VUPVAL = 7
		self._VGLOBAL = 8
		self._VINDEXED = 9
		self._VJMP = 10
		self._VRELOCABLE = 11
		self._VNONRELOC = 12
		self._VCALL = 13
		self._VVARARG = 14
		self.init(k, i)

	def __init__(self, k, i):
		self._VVOID = 0
		self._VNIL = 1
		self._VTRUE = 2
		self._VFALSE = 3
		self._VK = 4
		self._VKNUM = 5
		self._VLOCAL = 6
		self._VUPVAL = 7
		self._VGLOBAL = 8
		self._VINDEXED = 9
		self._VJMP = 10
		self._VRELOCABLE = 11
		self._VNONRELOC = 12
		self._VCALL = 13
		self._VVARARG = 14
		self.init(k, i)

	def init(self, kind, i):
		""" <summary>
		 Equivalent to init_exp from lparser.c </summary>
		"""
		self._t = FuncState.NO_JUMP
		self._f = FuncState.NO_JUMP
		self._k = kind
		self._info_Renamed = i

	def init(self, e):
		# Must initialise all members of this.
		self._k = e.k
		self._info_Renamed = e.info_Renamed
		self._aux_Renamed = e.aux_Renamed
		self._nval_Renamed = e.nval_Renamed
		self._t = e.t
		self._f = e.f

	def kind(self):
		return self._k

	def set_Kind(self, value):
		self._k = value

	Kind = property(fset=set_Kind)

	def info(self):
		return self._info_Renamed

	def set_Info(self, value):
		self._info_Renamed = value

	Info = property(fset=set_Info)

	def aux(self):
		return self._aux_Renamed

	def nval(self):
		return self._nval_Renamed

	def set_Nval(self, value):
		self._nval_Renamed = value

	Nval = property(fset=set_Nval)

	def hasmultret(self):
		""" <summary>
		 Equivalent to hasmultret from lparser.c </summary>
		"""
		return self._k == self._VCALL or self._k == self._VVARARG

	def hasjumps(self):
		""" <summary>
		 Equivalent to hasjumps from lcode.c. </summary>
		"""
		return self._t != self._f

	def nonreloc(self, i):
		self._k = self._VNONRELOC
		self._info_Renamed = i

	def reloc(self, i):
		self._k = self._VRELOCABLE
		self._info_Renamed = i

	def upval(self, i):
		self._k = self._VUPVAL
		self._info_Renamed = i