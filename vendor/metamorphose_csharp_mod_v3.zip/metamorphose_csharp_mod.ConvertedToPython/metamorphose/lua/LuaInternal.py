﻿from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/LuaInternal.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class LuaInternal(LuaJavaCallback):
	""" <summary>
	 Class used to implement internal callbacks.  Currently there is only
	 one callback used, one that parses or loads a Lua chunk into binary
	 form.
	 </summary>
	"""
	def __init__(self, in_, chunkname):
		self._reader = in_
		self._chunkname = chunkname

	def __init__(self, in_, chunkname):
		self._reader = in_
		self._chunkname = chunkname

	def luaFunction(self, L):
		try:
			p = None
			# In either the stream or the reader case there is a way of
			# converting the input to the other type.
			if self._stream != None:
				self._stream.mark(1)
				c = self._stream.read()
				self._stream.reset()
				# Convert to Reader if looks like source code instead of
				# binary.
				if c == Loader.HEADER[0]:
					l = Loader(self._stream, self._chunkname)
					p = l.undump()
				else:
					self._reader = InputStreamReader(self._stream, "UTF-8")
					p = Syntax.parser(L, self._reader, self._chunkname)
			else:
				# Convert to Stream if looks like binary (dumped via
				# string.dump) instead of source code.
				if self._reader.markSupported():
					self._reader.mark(1)
					c = self._reader.read()
					self._reader.reset()
					if c == Loader.HEADER[0]:
						self._stream = FromReader(self._reader)
						l = Loader(self._stream, self._chunkname)
						p = l.undump()
					else:
						p = Syntax.parser(L, self._reader, self._chunkname)
				else:
					p = Syntax.parser(L, self._reader, self._chunkname)
			L.push(LuaFunction(p, Array.CreateInstance(UpVal, 0), L.Globals))
			return 1
		except IOException, e:
			L.push("cannot read " + self._chunkname + ": " + e.ToString())
			L.dThrow(Lua.ERRFILE)
			return 0
		finally:
			pass
		