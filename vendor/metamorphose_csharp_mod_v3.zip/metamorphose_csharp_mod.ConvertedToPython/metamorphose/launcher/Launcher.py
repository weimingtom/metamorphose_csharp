﻿from System import *
from System.Windows.Forms import *
from metamorphose.test import *

class Launcher(object):
	def Main(args):
		Application.EnableVisualStyles()
		Application.SetCompatibleTextRenderingDefault(False)
		form1 = Form()
		form1.Text = "hello"
		Test001()

	Main = staticmethod(Main)

Launcher.Main(None)