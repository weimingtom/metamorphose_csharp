﻿using System;
using System.Collections.Generic;
using System.Text;

namespace metamorphose.java
{
    public class InputStreamReader : Reader
    {
        public InputStreamReader(InputStream i, String charsetName)
        {

        }
    }
}
