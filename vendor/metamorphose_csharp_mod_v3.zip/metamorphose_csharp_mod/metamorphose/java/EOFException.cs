﻿using System;
using System.Collections.Generic;
using System.Text;

namespace metamorphose.java
{
    public class EOFException : Exception
    {
        public EOFException()
        {
            
        }
    }
}
