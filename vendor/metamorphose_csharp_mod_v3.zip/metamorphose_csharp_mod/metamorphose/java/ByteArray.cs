﻿using System;
using System.Collections.Generic;
using System.Text;

namespace metamorphose.java
{
    //FIXME:
    public class ByteArray
    {
        public void clear()
        {

        }

        public void writeBytes(ByteArray b, int off = 0, int len = 0)
        {

        }

        public void writeMultiByte(string str, string encode)
        {

        }

        public int getLength()
        {
            return 0;
        }

        public byte get(int index)
        {
            return 0;
        }
    }
}
