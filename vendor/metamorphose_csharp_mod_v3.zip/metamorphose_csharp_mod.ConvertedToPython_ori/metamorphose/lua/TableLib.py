﻿from System.Collections import *
from System.Text import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/TableLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class TableLib(LuaJavaCallback):
	""" <summary>
	 Contains Lua's table library.
	 The library can be opened using the <seealso cref="#open"/> method.
	 </summary>
	"""
	# Each function in the table library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	def __init__(self, which):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._CONCAT = 1
		self._INSERT = 2
		self._MAXN = 3
		self._REMOVE = 4
		self._SORT = 5
		self._GETN = 6
		self._which = which

	def luaFunction(self, L):
		""" <summary>
		 Implements all of the functions in the Lua table library.  Do not
		 call directly. </summary>
		 <param name="L">  the Lua state in which to execute. </param>
		 <returns> number of returned parameters, as per convention. </returns>
		"""
		if self._which == self._CONCAT:
			return self.concat(L)
		elif self._which == self._INSERT:
			return self.insert(L)
		elif self._which == self._MAXN:
			return self.maxn(L)
		elif self._which == self._REMOVE:
			return self.remove(L)
		elif self._which == self._SORT:
			return self.sort(L)
		elif self._which == 		#FIXME: added
self._GETN:
			return self.getn(L)
		return 0

	def open(L):
		""" <summary>
		 Opens the string library into the given Lua state.  This registers
		 the symbols of the string library in a newly created table called
		 "string". </summary>
		 <param name="L">  The Lua state into which to open. </param>
		"""
		L.register("table")
		TableLib.r(L, "concat", self._CONCAT)
		TableLib.r(L, "insert", self._INSERT)
		TableLib.r(L, "getn", self._GETN) #FIXME: added
		TableLib.r(L, "maxn", self._MAXN)
		TableLib.r(L, "remove", self._REMOVE)
		TableLib.r(L, "sort", self._SORT)

	open = staticmethod(open)

	def r(L, name, which):
		""" <summary>
		 Register a function. </summary>
		"""
		f = TableLib(which)
		lib = L.getGlobal("table")
		L.setField(lib, name, f)

	r = staticmethod(r)

	def concat(L):
		""" <summary>
		 Implements table.concat. </summary>
		"""
		sep = L.optString(2, "")
		L.checkType(1, Lua.TTABLE)
		i = L.optInt(3, 1)
		last = L.optInt(4, L.objLen(L.value(1)))
		b = StringBuilder()
		t = L.value(1)
		while i <= last:
			v = L.rawGetI(t, i)
			L.argCheck(L.isString(v), 1, "table contains non-strings")
			b.Append(L.toString(v))
			if i != last:
				b.Append(L.toString(sep))
			i += 1
		L.pushString(b.ToString())
		return 1

	concat = staticmethod(concat)

	def insert(L):
		""" <summary>
		 Implements table.insert. </summary>
		"""
		e = TableLib.aux_getn(L, 1) + 1 # first empty element # where to insert new element
		t = L.value(1)
		if L.Top == 2: # called with only 2 arguments
			pos = e # insert new element at the end
		elif L.Top == 3:
			pos = L.checkInt(2) # 2nd argument is the position
			if pos > e:
				e = pos # grow array if necessary
			i = e
			while i > pos: # move up elements
				# t[i] = t[i-1]
				L.rawSetI(t, i, L.rawGetI(t, i - 1))
				i -= 1
		else:
			return L.error("wrong number of arguments to 'insert'")
		L.rawSetI(t, pos, L.value(-1)) # t[pos] = v
		return 0

	insert = staticmethod(insert)

	def maxn(L):
		""" <summary>
		 Implements table.maxn. </summary>
		"""
		max = 0
		L.checkType(1, Lua.TTABLE)
		t = L.value(1)
		e = t.keys()
		while e.hasMoreElements():
			o = e.nextElement()
			if Lua.type(o) == Lua.TNUMBER:
				v = L.toNumber(o)
				if v > max:
					max = v
		L.pushNumber(max)
		return 1

	maxn = staticmethod(maxn)

	def remove(L):
		""" <summary>
		 Implements table.remove. </summary>
		"""
		e = TableLib.aux_getn(L, 1)
		pos = L.optInt(2, e)
		if e == 0:
			return 0 # table is 'empty'
		t = L.value(1)
		o = L.rawGetI(t, pos) # result = t[pos]
		while pos < e:
			L.rawSetI(t, pos, L.rawGetI(t, pos + 1))
			pos += 1 # t[pos] = t[pos+1]
		L.rawSetI(t, e, Lua.NIL) # t[e] = nil
		L.push(o)
		return 1

	remove = staticmethod(remove)

	def sort(L):
		""" <summary>
		 Implements table.sort. </summary>
		"""
		n = TableLib.aux_getn(L, 1)
		if not L.isNoneOrNil(2): # is there a 2nd argument?
			L.checkType(2, Lua.TFUNCTION)
		L.Top = 2 # make sure there is two arguments
		TableLib.auxsort(L, 1, n)
		return 0

	sort = staticmethod(sort)

	def auxsort(L, l, u):
		t = L.value(1)
		while l < u: # for tail recursion
			# sort elements a[l], a[l+u/2], and a[u]
			o1 = L.rawGetI(t, l)
			o2 = L.rawGetI(t, u)
			if TableLib.sort_comp(L, o2, o1): # a[u] < a[l]?
				L.rawSetI(t, l, o2)
				L.rawSetI(t, u, o1)
			if u - l == 1:
				break # only 2 elements
			i = (l + u) / 2
			o1 = L.rawGetI(t, i)
			o2 = L.rawGetI(t, l)
			if TableLib.sort_comp(L, o1, o2): # a[i]<a[l]?
				L.rawSetI(t, i, o2)
				L.rawSetI(t, l, o1)
			else:
				o2 = L.rawGetI(t, u)
				if TableLib.sort_comp(L, o2, o1): # a[u]<a[i]?
					L.rawSetI(t, i, o2)
					L.rawSetI(t, u, o1)
			if u - l == 2:
				break # only 3 elements
			p = L.rawGetI(t, i) # Pivot
			o2 = L.rawGetI(t, u - 1)
			L.rawSetI(t, i, o2)
			L.rawSetI(t, u - 1, p)
			# a[l] <= P == a[u-1] <= a[u], only need to sort from l+1 to u-2
			i = l
			j = u - 1
			# NB: Pivot P is in p
			while True: # invariant: a[l..i] <= P <= a[j..u]
				# repeat ++i until a[i] >= P
				while True:
					o1 = L.rawGetI(t, i += 1)
					if not TableLib.sort_comp(L, o1, p):
						break
					if i > u:
						L.error("invalid order function for sorting")
				# repreat --j until a[j] <= P
				while True:
					o2 = L.rawGetI(t, j -= 1)
					if not TableLib.sort_comp(L, p, o2):
						break
					if j < l:
						L.error("invalid order function for sorting")
				if j < i:
					break
				L.rawSetI(t, i, o2)
				L.rawSetI(t, j, o1)
			o1 = L.rawGetI(t, u - 1)
			o2 = L.rawGetI(t, i)
			L.rawSetI(t, u - 1, o2)
			L.rawSetI(t, i, o1) # swap pivot (a[u-1]) with a[i]
			# a[l..i-1 <= a[i] == P <= a[i+1..u]
			# adjust so that smaller half is in [j..i] and larger one in [l..u]
			if i - l < u - i:
				j = l
				i = i - 1
				l = i + 2
			else:
				j = i + 1
				i = u
				u = j - 2
			TableLib.auxsort(L, j, i)

	auxsort = staticmethod(auxsort)
 # call recursively the smaller one # repeat the routine for the larger one
	def sort_comp(L, a, b):
		if not L.isNil(L.value(2)): # function?
			L.pushValue(2)
			L.push(a)
			L.push(b)
			L.call(2, 1)
			res = L.toBoolean(L.value(-1))
			L.pop(1)
			return res
		else: # a < b?
			return L.lessThan(a, b)

	sort_comp = staticmethod(sort_comp)

	def aux_getn(L, n):
		L.checkType(n, Lua.TTABLE)
		t = L.value(n)
		return t.getn()

	aux_getn = staticmethod(aux_getn)

	#FIXME: added
	def getn(L):
		L.pushNumber(TableLib.aux_getn(L, 1))
		return 1

	getn = staticmethod(getn)