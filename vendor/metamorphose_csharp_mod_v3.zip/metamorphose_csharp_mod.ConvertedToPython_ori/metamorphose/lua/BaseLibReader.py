﻿from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/BaseLibReader.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class BaseLibReader(Reader):
	""" <summary>
	 Extends <seealso cref="java.io.Reader"/> to create a Reader from a Lua
	 function.  So that the <code>load</code> function from Lua's base
	 library can be implemented.
	 </summary>
	""" # = 0;
	def __init__(self, L, f):
		self._s = ""
		self._mark_Renamed = -1
		self._L = L
		self._f = f

	def close(self):
		self._f = None

	def mark(self, l):
		if l > 1:
			raise IOException("Readahead must be <= 1")
		self._mark_Renamed = self._i

	def markSupported(self):
		return True

	def read(self):
		if self._i >= self._s.Length:
			self._L.push(self._f)
			self._L.call(0, 1)
			if self._L.isNil(self._L.value(-1)):
				return -1
			elif self._L.isString(self._L.value(-1)):
				self._s = self._L.toString(self._L.value(-1))
				if self._s.Length == 0:
					return -1
				if self._mark_Renamed == self._i:
					self._mark_Renamed = 0
				else:
					self._mark_Renamed = -1
				self._i = 0
			else:
				self._L.error("reader function must return a string")
		return self._s[self._i += 1]

	def read(self, cbuf, off, len):
		j = 0 # loop index required after loop
		j = 0
		while j < len:
			c = self.read()
			if c == -1:
				if j == 0:
					return -1
				else:
					return j
			cbuf[off + j] = c
			j += 1
		return j

	def reset(self):
		if self._mark_Renamed < 0:
			raise IOException("reset() not supported now")
		self._i = self._mark_Renamed