﻿from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/StringReader.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class StringReader(Reader):
	""" <summary>
	 Ersatz replacement for <seealso cref="java.io.StringReader"/> from JSE. </summary>
	"""
	# <summary>
	# Index of the current read position.  -1 if closed. </summary> # = 0
	# <summary>
	# Index of the current mark (set with <seealso cref="#mark"/>).
	# </summary> # = 0;
	def __init__(self, s):
		self._s = s

	def close(self):
		self._current = -1

	def mark(self, limit):
		self._mark_Renamed = self._current

	def markSupported(self):
		return True

	def read(self):
		if self._current < 0:
			raise IOException()
		if self._current >= self._s.Length:
			return -1
		return self._s[self._current += 1]

	def read(self, cbuf, off, len):
		if self._current < 0 or len < 0:
			raise IOException()
		if self._current >= self._s.Length:
			return 0
		if self._current + len > self._s.Length:
			len = self._s.Length - self._current
		i = 0
		while i < len:
			cbuf[off + i] = self._s[self._current + i]
			i += 1
		self._current += len
		return len

	def reset(self):
		self._current = self._mark_Renamed