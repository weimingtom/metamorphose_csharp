﻿from System import *
from System.Collections import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/BaseLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class BaseLib(LuaJavaCallback):
	""" <summary>
	 Contains Lua's base library.  The base library is generally
	 considered essential for running any Lua program.  The base library
	 can be opened using the <seealso cref="#open"/> method.
	 </summary>
	"""
	# :todo: consider making the enums contiguous so that the compiler
	# uses the compact and faster form of switch.
	# Each function in the base library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	# private static final int GCINFO = 5;
	# The coroutine functions (which reside in the table "coroutine") are also
	# part of the base library.
	# <summary>
	# Lua value that represents the generator function for ipairs.  In
	# PUC-Rio this is implemented as an upvalue of ipairs.
	# </summary>
	# <summary>
	# Lua value that represents the generator function for pairs.  In
	# PUC-Rio this is implemented as an upvalue of pairs.
	# </summary>
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	# <summary>
	# For wrapped threads created by coroutine.wrap, this references the
	# Lua thread object.
	# </summary>
	def __init__(self, L):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._ASSERT = 1
		self._COLLECTGARBAGE = 2
		self._DOFILE = 3
		self._ERROR = 4
		self._GETFENV = 6
		self._GETMETATABLE = 7
		self._LOADFILE = 8
		self._LOAD = 9
		self._LOADSTRING = 10
		self._NEXT = 11
		self._PCALL = 12
		self._PRINT = 13
		self._RAWEQUAL = 14
		self._RAWGET = 15
		self._RAWSET = 16
		self._SELECT = 17
		self._SETFENV = 18
		self._SETMETATABLE = 19
		self._TONUMBER = 20
		self._TOSTRING = 21
		self._TYPE = 22
		self._UNPACK = 23
		self._XPCALL = 24
		self._IPAIRS = 25
		self._PAIRS = 26
		self._IPAIRS_AUX = 27
		self._PAIRS_AUX = 28
		self._CREATE = 50
		self._RESUME = 51
		self._RUNNING = 52
		self._STATUS = 53
		self._WRAP = 54
		self._YIELD = 55
		self._WRAP_AUX = 56
		self._IPAIRS_AUX_FUN = BaseLib(self._IPAIRS_AUX)
		self._PAIRS_AUX_FUN = BaseLib(self._PAIRS_AUX)
		# <summary>
		# Instance constructor used by coroutine.wrap. </summary>
		# <summary>
		# Implements all of the functions in the Lua base library.  Do not
		# call directly. </summary>
		# <param name="L">  the Lua state in which to execute. </param>
		# <returns> number of returned parameters, as per convention. </returns>
		# <summary>
		# Opens the base library into the given Lua state.  This registers
		# the symbols of the base library in the global table. </summary>
		# <param name="L">  The Lua state into which to open. </param>
		# set global _G
		# set global _VERSION
		# <summary>
		# Register a function. </summary>
		# <summary>
		# Register a function in the coroutine table. </summary>
		# <summary>
		# Implements assert.  <code>assert</code> is a keyword in some
		# versions of Java, so this function has a mangled name.
		# </summary>
		# <summary>
		# Used by <seealso cref="#collectgarbage"/>. </summary>
		self._CGOPTS = Array[str](("stop", "restart", "collect", "count", "step", "setpause", "setstepmul"))
		# <summary>
		# Used by <seealso cref="#collectgarbage"/>. </summary>
		self._CGOPTSNUM = Array[int]((Lua.GCSTOP, Lua.GCRESTART, Lua.GCCOLLECT, Lua.GCCOUNT, Lua.GCSTEP, Lua.GCSETPAUSE, Lua.GCSETSTEPMUL))
		# <summary>
		# Implements collectgarbage. </summary>
		# <summary>
		# Implements dofile. </summary>
		# <summary>
		# Implements error. </summary>
		# NOTREACHED
		# <summary>
		# Helper for getfenv and setfenv. </summary>
		# <summary>
		# Implements getfenv. </summary>
		# <summary>
		# Implements getmetatable. </summary> # return metatable # return __metatable field
		# <summary>
		# Implements load. </summary>
		# <summary>
		# Implements loadfile. </summary>
		# <summary>
		# Implements loadstring. </summary>
		# "binary" dumped into string using string.dump. # OK? # put before error message # return nil plus error message
		# <summary>
		# Implements next. </summary> # Create a 2nd argument is there isn't one
		# <summary>
		# Implements ipairs. </summary>
		# <summary>
		# Generator for ipairs. </summary>
		# <summary>
		# Implements pairs.  PUC-Rio uses "next" as the generator for pairs.
		# Jill doesn't do that because it would be way too slow.  We use the
		# <seealso cref="java.util.Enumeration"/> returned from
		# <seealso cref="java.util.Hashtable#keys"/>.  The <seealso cref="#pairsaux"/> method
		# implements the step-by-step iteration.
		# </summary> # return generator, # state, # and initial value.
		# <summary>
		# Generator for pairs.  This expects a <var>state</var> and
		# <var>var</var> as (Lua) arguments.
		# The state is setup by <seealso cref="#pairs"/> and is a
		# pair of {LuaTable, Enumeration} stored in a 2-element array.  The
		# <var>var</var> is not used.  This is in contrast to the PUC-Rio
		# implementation, where the state is the table, and the var is used
		# to generated the next key in sequence.  The implementation, of
		# pairs and pairsaux, has no control over <var>var</var>,  Lua's
		# semantics of <code>for</code> force it to be the previous result
		# returned by this function.  In Jill this value is not suitable to
		# use for enumeration, which is why it isn't used.
		# </summary>
		# <summary>
		# Implements pcall. </summary>
		# <summary>
		# The <seealso cref="PrintStream"/> used by print.  Makes it more convenient if
		# redirection is desired.  For example, client code could implement
		# their own instance which sent output to the screen of a JME device.
		# </summary>
		self._OUT = SystemUtil.Out
		self._thread = L

	def __init__(self, L):
		self._ASSERT = 1
		self._COLLECTGARBAGE = 2
		self._DOFILE = 3
		self._ERROR = 4
		self._GETFENV = 6
		self._GETMETATABLE = 7
		self._LOADFILE = 8
		self._LOAD = 9
		self._LOADSTRING = 10
		self._NEXT = 11
		self._PCALL = 12
		self._PRINT = 13
		self._RAWEQUAL = 14
		self._RAWGET = 15
		self._RAWSET = 16
		self._SELECT = 17
		self._SETFENV = 18
		self._SETMETATABLE = 19
		self._TONUMBER = 20
		self._TOSTRING = 21
		self._TYPE = 22
		self._UNPACK = 23
		self._XPCALL = 24
		self._IPAIRS = 25
		self._PAIRS = 26
		self._IPAIRS_AUX = 27
		self._PAIRS_AUX = 28
		self._CREATE = 50
		self._RESUME = 51
		self._RUNNING = 52
		self._STATUS = 53
		self._WRAP = 54
		self._YIELD = 55
		self._WRAP_AUX = 56
		self._IPAIRS_AUX_FUN = BaseLib(self._IPAIRS_AUX)
		self._PAIRS_AUX_FUN = BaseLib(self._PAIRS_AUX)
		self._CGOPTS = Array[str](("stop", "restart", "collect", "count", "step", "setpause", "setstepmul"))
		self._CGOPTSNUM = Array[int]((Lua.GCSTOP, Lua.GCRESTART, Lua.GCCOLLECT, Lua.GCCOUNT, Lua.GCSTEP, Lua.GCSETPAUSE, Lua.GCSETSTEPMUL))
		self._OUT = SystemUtil.Out
		self._thread = L

	def luaFunction(self, L):
		if self._which == self._ASSERT:
			return self.assertFunction(L)
		elif self._which == self._COLLECTGARBAGE:
			return self.collectgarbage(L)
		elif self._which == self._DOFILE:
			return self.dofile(L)
		elif self._which == self._ERROR:
			return self.error(L)
		elif self._which == self._GETFENV:
			return self.getfenv(L)
		elif self._which == self._GETMETATABLE:
			return self.getmetatable(L)
		elif self._which == self._IPAIRS:
			return self.ipairs(L)
		elif self._which == self._LOAD:
			return self.load(L)
		elif self._which == self._LOADFILE:
			return self.loadfile(L)
		elif self._which == self._LOADSTRING:
			return self.loadstring(L)
		elif self._which == self._NEXT:
			return self.next(L)
		elif self._which == self._PAIRS:
			return self.pairs(L)
		elif self._which == self._PCALL:
			return self.pcall(L)
		elif self._which == self._PRINT:
			return self.print(L)
		elif self._which == self._RAWEQUAL:
			return self.rawequal(L)
		elif self._which == self._RAWGET:
			return self.rawget(L)
		elif self._which == self._RAWSET:
			return self.rawset(L)
		elif self._which == self._SELECT:
			return self.select(L)
		elif self._which == self._SETFENV:
			return self.setfenv(L)
		elif self._which == self._SETMETATABLE:
			return self.setmetatable(L)
		elif self._which == self._TONUMBER:
			return self.tonumber(L)
		elif self._which == self._TOSTRING:
			return self.tostring(L)
		elif self._which == self._TYPE:
			return self.type(L)
		elif self._which == self._UNPACK:
			return self.unpack(L)
		elif self._which == self._XPCALL:
			return self.xpcall(L)
		elif self._which == self._IPAIRS_AUX:
			return self.ipairsaux(L)
		elif self._which == self._PAIRS_AUX:
			return self.pairsaux(L)
		elif self._which == self._CREATE:
			return self.create(L)
		elif self._which == self._RESUME:
			return self.resume(L)
		elif self._which == self._RUNNING:
			return self.running(L)
		elif self._which == self._STATUS:
			return self.status(L)
		elif self._which == self._WRAP:
			return self.wrap(L)
		elif self._which == self._YIELD:
			return self.yield(L)
		elif self._which == self._WRAP_AUX:
			return self.wrapaux(L)
		return 0

	def open(L):
		L.setGlobal("_G", L.Globals)
		L.setGlobal("_VERSION", Lua.VERSION)
		BaseLib.r(L, "assert", self._ASSERT)
		BaseLib.r(L, "collectgarbage", self._COLLECTGARBAGE)
		BaseLib.r(L, "dofile", self._DOFILE)
		BaseLib.r(L, "error", self._ERROR)
		BaseLib.r(L, "getfenv", self._GETFENV)
		BaseLib.r(L, "getmetatable", self._GETMETATABLE)
		BaseLib.r(L, "ipairs", self._IPAIRS)
		BaseLib.r(L, "loadfile", self._LOADFILE)
		BaseLib.r(L, "load", self._LOAD)
		BaseLib.r(L, "loadstring", self._LOADSTRING)
		BaseLib.r(L, "next", self._NEXT)
		BaseLib.r(L, "pairs", self._PAIRS)
		BaseLib.r(L, "pcall", self._PCALL)
		BaseLib.r(L, "print", self._PRINT)
		BaseLib.r(L, "rawequal", self._RAWEQUAL)
		BaseLib.r(L, "rawget", self._RAWGET)
		BaseLib.r(L, "rawset", self._RAWSET)
		BaseLib.r(L, "select", self._SELECT)
		BaseLib.r(L, "setfenv", self._SETFENV)
		BaseLib.r(L, "setmetatable", self._SETMETATABLE)
		BaseLib.r(L, "tonumber", self._TONUMBER)
		BaseLib.r(L, "tostring", self._TOSTRING)
		BaseLib.r(L, "type", self._TYPE)
		BaseLib.r(L, "unpack", self._UNPACK)
		BaseLib.r(L, "xpcall", self._XPCALL)
		L.register("coroutine")
		BaseLib.c(L, "create", self._CREATE)
		BaseLib.c(L, "resume", self._RESUME)
		BaseLib.c(L, "running", self._RUNNING)
		BaseLib.c(L, "status", self._STATUS)
		BaseLib.c(L, "wrap", self._WRAP)
		BaseLib.c(L, "yield", self._YIELD)

	open = staticmethod(open)

	def r(L, name, which):
		f = BaseLib(which)
		L.setGlobal(name, f)

	r = staticmethod(r)

	def c(L, name, which):
		f = BaseLib(which)
		L.setField(L.getGlobal("coroutine"), name, f)

	c = staticmethod(c)

	def assertFunction(L):
		L.checkAny(1)
		if not L.toBoolean(L.value(1)):
			L.error(L.optString(2, "assertion failed!"))
		return L.Top

	assertFunction = staticmethod(assertFunction)

	def collectgarbage(L):
		o = L.checkOption(1, "collect", self._CGOPTS)
		ex = L.optInt(2, 0)
		res = L.gc(self._CGOPTSNUM[o], ex)
		if self._CGOPTSNUM[o] == Lua.GCCOUNT:
			b = L.gc(Lua.GCCOUNTB, 0)
			L.pushNumber(res + (b) / 1024)
			return 1
		elif self._CGOPTSNUM[o] == Lua.GCSTEP:
			L.pushBoolean(res != 0)
			return 1
		else:
			L.pushNumber(res)
			return 1

	collectgarbage = staticmethod(collectgarbage)

	def dofile(L):
		fname = L.optString(1, None)
		n = L.Top
		if L.loadFile(fname) != 0:
			L.error(L.value(-1))
		L.call(0, Lua.MULTRET)
		return L.Top - n

	dofile = staticmethod(dofile)

	def error(L):
		level = L.optInt(2, 1)
		L.Top = 1
		if L.isString(L.value(1)) and level > 0:
			L.insert(L.where(level), 1)
			L.concat(2)
		L.error(L.value(1))
		return 0

	error = staticmethod(error)

	def getfunc(L):
		o = L.value(1)
		if L.isFunction(o):
			return o
		else:
			level = L.optInt(1, 1)
			L.argCheck(level >= 0, 1, "level must be non-negative")
			ar = L.getStack(level)
			if ar == None:
				L.argError(1, "invalid level")
			L.getInfo("f", ar)
			o = L.value(-1)
			if L.isNil(o):
				L.error("no function environment for tail call at level " + level)
			L.pop(1)
			return o

	getfunc = staticmethod(getfunc)

	def getfenv(L):
		o = BaseLib.getfunc(L)
		if Lua.isJavaFunction(o):
			L.push(L.Globals)
		else:
			f = o
			L.push(f.getEnv())
		return 1

	getfenv = staticmethod(getfenv)

	def getmetatable(L):
		L.checkAny(1)
		mt = L.getMetatable(L.value(1))
		if mt == None:
			L.pushNil()
			return 1
		protectedmt = L.getMetafield(L.value(1), "__metatable")
		if L.isNil(protectedmt):
			L.push(mt)
		else:
			L.push(protectedmt)
		return 1

	getmetatable = staticmethod(getmetatable)

	def load(L):
		cname = L.optString(2, "=(load)")
		L.checkType(1, Lua.TFUNCTION)
		r = BaseLibReader(L, L.value(1))
		status = L.load(r, cname)
		return BaseLib.load_aux(L, status)

	load = staticmethod(load)

	def loadfile(L):
		fname = L.optString(1, None)
		return BaseLib.load_aux(L, L.loadFile(fname))

	loadfile = staticmethod(loadfile)

	def loadstring(L):
		s = L.checkString(1)
		chunkname = L.optString(2, s)
		if s.StartsWith("\x001B"):
			return BaseLib.load_aux(L, L.load(DumpedInput(s), chunkname))
		else:
			return BaseLib.load_aux(L, L.loadString(s, chunkname))

	loadstring = staticmethod(loadstring)

	def load_aux(L, status):
		if status == 0:
			return 1
		else:
			L.insert(Lua.NIL, -1)
			return 2

	load_aux = staticmethod(load_aux)

	def next(L):
		L.checkType(1, Lua.TTABLE)
		L.Top = 2
		if L.next(1):
			return 2
		L.push(Lua.NIL)
		return 1

	next = staticmethod(next)

	def ipairs(L):
		L.checkType(1, Lua.TTABLE)
		L.push(self._IPAIRS_AUX_FUN)
		L.pushValue(1)
		L.pushNumber(0)
		return 3

	ipairs = staticmethod(ipairs)

	def ipairsaux(L):
		i = L.checkInt(2)
		L.checkType(1, Lua.TTABLE)
		i += 1
		v = L.rawGetI(L.value(1), i)
		if L.isNil(v):
			return 0
		L.pushNumber(i)
		L.push(v)
		return 2

	ipairsaux = staticmethod(ipairsaux)

	def pairs(L):
		L.checkType(1, Lua.TTABLE)
		L.push(self._PAIRS_AUX_FUN)
		t = L.value(1)
		L.push(Array[Object]((t, t.keys())))
		L.push(Lua.NIL)
		return 3

	pairs = staticmethod(pairs)

	def pairsaux(L):
		a = L.value(1)
		t = a[0]
		e = a[1]
		if not e.hasMoreElements():
			return 0
		key = e.nextElement()
		L.push(key)
		L.push(t.getlua(key))
		return 2

	pairsaux = staticmethod(pairsaux)

	def pcall(L):
		L.checkAny(1)
		status = L.pcall(L.Top - 1, Lua.MULTRET, None)
		b = (status == 0)
		L.insert(Lua.valueOfBoolean(b), 1)
		return L.Top

	pcall = staticmethod(pcall)

	def print(L):
		""" <summary>
		 Implements print. </summary>
		"""
		n = L.Top
		tostring = L.getGlobal("tostring")
		i = 1
		while i <= n:
			L.push(tostring)
			L.pushValue(i)
			L.call(1, 1)
			s = L.toString(L.value(-1))
			if s == None:
				return L.error("'tostring' must return a string to 'print'")
			if i > 1:
				self._OUT.print('\t')
			self._OUT.print(s)
			L.pop(1)
			i += 1
		self._OUT.println()
		return 0

	print = staticmethod(print)

	def rawequal(L):
		""" <summary>
		 Implements rawequal. </summary>
		"""
		L.checkAny(1)
		L.checkAny(2)
		L.pushBoolean(L.rawEqual(L.value(1), L.value(2)))
		return 1

	rawequal = staticmethod(rawequal)

	def rawget(L):
		""" <summary>
		 Implements rawget. </summary>
		"""
		L.checkType(1, Lua.TTABLE)
		L.checkAny(2)
		L.push(L.rawGet(L.value(1), L.value(2)))
		return 1

	rawget = staticmethod(rawget)

	def rawset(L):
		""" <summary>
		 Implements rawset. </summary>
		"""
		L.checkType(1, Lua.TTABLE)
		L.checkAny(2)
		L.checkAny(3)
		L.rawSet(L.value(1), L.value(2), L.value(3))
		return 0

	rawset = staticmethod(rawset)

	def select(L):
		""" <summary>
		 Implements select. </summary>
		"""
		n = L.Top
		if L.type(1) == Lua.TSTRING and "#".Equals(L.toString(L.value(1))):
			L.pushNumber(n - 1)
			return 1
		i = L.checkInt(1)
		if i < 0:
			i = n + i
		elif i > n:
			i = n
		L.argCheck(1 <= i, 1, "index out of range")
		return n - i

	select = staticmethod(select)

	def setfenv(L):
		""" <summary>
		 Implements setfenv. </summary>
		"""
		L.checkType(2, Lua.TTABLE)
		o = BaseLib.getfunc(L)
		first = L.value(1)
		if L.isNumber(first) and L.toNumber(first) == 0:
			# :todo: change environment of current thread.
			return 0
		elif Lua.isJavaFunction(o) or not L.setFenv(o, L.value(2)):
			L.error("'setfenv' cannot change environment of given object")
		L.push(o)
		return 1

	setfenv = staticmethod(setfenv)

	def setmetatable(L):
		""" <summary>
		 Implements setmetatable. </summary>
		"""
		L.checkType(1, Lua.TTABLE)
		t = L.type(2)
		L.argCheck(t == Lua.TNIL or t == Lua.TTABLE, 2, "nil or table expected")
		if not L.isNil(L.getMetafield(L.value(1), "__metatable")):
			L.error("cannot change a protected metatable")
		L.setMetatable(L.value(1), L.value(2))
		L.Top = 1
		return 1

	setmetatable = staticmethod(setmetatable)

	def tonumber(L):
		""" <summary>
		 Implements tonumber. </summary>
		"""
		base = L.optInt(2, 10)
		if base == 10: # standard conversion
			L.checkAny(1)
			o = L.value(1)
			if L.isNumber(o):
				L.pushNumber(L.toNumber(o))
				return 1
		else:
			s = L.checkString(1)
			L.argCheck(2 <= base and base <= 36, 2, "base out of range")
			# :todo: consider stripping space and sharing some code with
			# Lua.vmTostring
			try:
				i = Convert.ToInt32(s, base)
				L.pushNumber(i)
				return 1
			except NumberFormatException, :
			finally:
		L.push(Lua.NIL)
		return 1

	tonumber = staticmethod(tonumber)

	def tostring(L):
		""" <summary>
		 Implements tostring. </summary>
		"""
		L.checkAny(1)
		o = L.value(1)
		if L.callMeta(1, "__tostring"): # is there a metafield?
			return 1 # use its value
		if L.type(1) == Lua.TNUMBER:
			L.push(L.toString(o))
		elif L.type(1) == Lua.TSTRING:
			L.push(o)
		elif L.type(1) == Lua.TBOOLEAN:
			if L.toBoolean(o):
				L.pushLiteral("true")
			else:
				L.pushLiteral("false")
		elif L.type(1) == Lua.TNIL:
			L.pushLiteral("nil")
		else:
			L.push(o.ToString())
		return 1

	tostring = staticmethod(tostring)

	def type(L):
		""" <summary>
		 Implements type. </summary>
		"""
		L.checkAny(1)
		L.push(L.typeNameOfIndex(1))
		return 1

	type = staticmethod(type)

	def unpack(L):
		""" <summary>
		 Implements unpack. </summary>
		"""
		L.checkType(1, Lua.TTABLE)
		t = L.value(1)
		i = L.optInt(2, 1)
		e = L.optInt(3, t.getn())
		n = e - i + 1 # number of elements
		if n <= 0:
			return 0 # empty range
		# i already initialised to start index, which isn't necessarily 1
		while i <= e:
			L.push(t.getnum(i))
			i += 1
		return n

	unpack = staticmethod(unpack)

	def xpcall(L):
		""" <summary>
		 Implements xpcall. </summary>
		"""
		L.checkAny(2)
		errfunc = L.value(2)
		L.Top = 1 # remove error function from stack
		status = L.pcall(0, Lua.MULTRET, errfunc)
		L.insert(Lua.valueOfBoolean(status == 0), 1)
		return L.Top

	xpcall = staticmethod(xpcall)
 # return status + all results
	def create(L):
		""" <summary>
		 Implements coroutine.create. </summary>
		"""
		NL = L.newThread()
		faso = L.value(1)
		L.argCheck(L.isFunction(faso) and not Lua.isJavaFunction(faso), 1, "Lua function expected")
		L.Top = 1 # function is at top
		L.xmove(NL, 1) # move function from L to NL
		L.push(NL)
		return 1

	create = staticmethod(create)

	def resume(L):
		""" <summary>
		 Implements coroutine.resume. </summary>
		"""
		co = L.toThread(L.value(1))
		L.argCheck(co != None, 1, "coroutine expected")
		r = BaseLib.auxresume(L, co, L.Top - 1)
		if r < 0:
			L.insert(Lua.valueOfBoolean(False), -1)
			return 2 # return false + error message
		L.insert(Lua.valueOfBoolean(True), L.Top - (r - 1))
		return r + 1

	resume = staticmethod(resume)
 # return true + 'resume' returns
	def running(L):
		""" <summary>
		 Implements coroutine.running. </summary>
		"""
		if L.Main:
			return 0 # main thread is not a coroutine
		L.push(L)
		return 1

	running = staticmethod(running)

	def status(L):
		""" <summary>
		 Implements coroutine.status. </summary>
		"""
		co = L.toThread(L.value(1))
		L.argCheck(co != None, 1, "coroutine expected")
		if L == co:
			L.pushLiteral("running")
		else:
			if co.status() == Lua.YIELD:
				L.pushLiteral("suspended")
			elif co.status() == 0:
				ar = co.getStack(0)
				if ar != None: # does it have frames?
					L.pushLiteral("normal") # it is running
				elif co.Top == 0:
					L.pushLiteral("dead")
				else:
					L.pushLiteral("suspended")
			else: # initial state # some error occured
				L.pushLiteral("dead")
		return 1

	status = staticmethod(status)

	def wrap(L):
		""" <summary>
		 Implements coroutine.wrap. </summary>
		"""
		BaseLib.create(L)
		L.push(BaseLib.wrapit(L.toThread(L.value(-1))))
		return 1

	wrap = staticmethod(wrap)

	def wrapit(L):
		""" <summary>
		 Helper for wrap.  Returns a LuaJavaCallback that has access to the
		 Lua thread. </summary>
		 <param name="L"> the Lua thread to be wrapped. </param>
		"""
		return BaseLib(L)

	wrapit = staticmethod(wrapit)

	def wrapaux(self, L):
		""" <summary>
		 Helper for wrap.  This implements the function returned by wrap. </summary>
		"""
		co = self._thread
		r = self.auxresume(L, co, L.Top)
		if r < 0:
			if L.isString(L.value(-1)): # error object is a string?
				w = L.where(1)
				L.insert(w, -1)
				L.concat(2)
			L.error(L.value(-1)) # propagate error
		return r

	def auxresume(L, co, narg):
		# if (!co.checkStack...
		if co.status() == 0 and co.Top == 0:
			L.pushLiteral("cannot resume dead coroutine")
			return -1 # error flag;
		L.xmove(co, narg)
		status = co.resume(narg)
		if status == 0 or status == Lua.YIELD:
			nres = co.Top
			# if (!L.checkStack...
			co.xmove(L, nres) # move yielded values
			return nres
		co.xmove(L, 1) # move error message
		return -1

	auxresume = staticmethod(auxresume)
 # error flag;
	def yield(L):
		""" <summary>
		 Implements coroutine.yield. </summary>
		"""
		return L.yield(L.Top)

	yield = staticmethod(yield)