﻿from System import *
from System.Collections import *
from System.Text import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/StringLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class StringLib(LuaJavaCallback):
	""" <summary>
	 Contains Lua's string library.
	 The library can be opened using the <seealso cref="#open"/> method.
	 </summary>
	"""
	# Each function in the string library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	def __init__(self, which):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._BYTE = 1
		self._CHAR = 2
		self._DUMP = 3
		self._FIND = 4
		self._FORMAT = 5
		self._GFIND = 6
		self._GMATCH = 7
		self._GSUB = 8
		self._LEN = 9
		self._LOWER = 10
		self._MATCH = 11
		self._REP = 12
		self._REVERSE = 13
		self._SUB = 14
		self._UPPER = 15
		self._GMATCH_AUX = 16
		self._GMATCH_AUX_FUN = StringLib(self._GMATCH_AUX)
		self._which = which

	def formatISO(self):
		""" <summary>
		 Adjusts the output of string.format so that %e and %g use 'e'
		 instead of 'E' to indicate the exponent.  In other words so that
		 string.format follows the ISO C (ISO 9899) standard for printf.
		 </summary>
		"""
		FormatItem.E_LOWER = 'e'

	def luaFunction(self, L):
		""" <summary>
		 Implements all of the functions in the Lua string library.  Do not
		 call directly. </summary>
		 <param name="L">  the Lua state in which to execute. </param>
		 <returns> number of returned parameters, as per convention. </returns>
		"""
		if self._which == self._BYTE:
			return self.byteFunction(L)
		elif self._which == self._CHAR:
			return self.charFunction(L)
		elif self._which == self._DUMP:
			return self.dump(L)
		elif self._which == self._FIND:
			return self.find(L)
		elif self._which == self._FORMAT:
			return self.format(L)
		elif self._which == self._GMATCH:
			return self.gmatch(L)
		elif self._which == self._GSUB:
			return self.gsub(L)
		elif self._which == self._LEN:
			return self.len(L)
		elif self._which == self._LOWER:
			return self.lower(L)
		elif self._which == self._MATCH:
			return self.match(L)
		elif self._which == self._REP:
			return self.rep(L)
		elif self._which == self._REVERSE:
			return self.reverse(L)
		elif self._which == self._SUB:
			return self.sub(L)
		elif self._which == self._UPPER:
			return self.upper(L)
		elif self._which == self._GMATCH_AUX:
			return self.gmatchaux(L)
		return 0

	def open(L):
		""" <summary>
		 Opens the string library into the given Lua state.  This registers
		 the symbols of the string library in a newly created table called
		 "string". </summary>
		 <param name="L">  The Lua state into which to open. </param>
		"""
		lib = L.register("string")
		StringLib.r(L, "byte", self._BYTE)
		StringLib.r(L, "char", self._CHAR)
		StringLib.r(L, "dump", self._DUMP)
		StringLib.r(L, "find", self._FIND)
		StringLib.r(L, "format", self._FORMAT)
		StringLib.r(L, "gfind", self._GFIND)
		StringLib.r(L, "gmatch", self._GMATCH)
		StringLib.r(L, "gsub", self._GSUB)
		StringLib.r(L, "len", self._LEN)
		StringLib.r(L, "lower", self._LOWER)
		StringLib.r(L, "match", self._MATCH)
		StringLib.r(L, "rep", self._REP)
		StringLib.r(L, "reverse", self._REVERSE)
		StringLib.r(L, "sub", self._SUB)
		StringLib.r(L, "upper", self._UPPER)
		mt = LuaTable()
		L.setMetatable("", mt) # set string metatable
		L.setField(mt, "__index", lib)

	open = staticmethod(open)

	def r(L, name, which):
		""" <summary>
		 Register a function. </summary>
		"""
		f = StringLib(which)
		lib = L.getGlobal("string")
		L.setField(lib, name, f)

	r = staticmethod(r)

	def byteFunction(L):
		""" <summary>
		 Implements string.byte.  Name mangled to avoid keyword. </summary>
		"""
		s = L.checkString(1)
		posi = StringLib.posrelat(L.optInt(2, 1), s)
		pose = StringLib.posrelat(L.optInt(3, posi), s)
		if posi <= 0:
			posi = 1
		if pose > s.Length:
			pose = s.Length
		if posi > pose:
			return 0 # empty interval; return no values
		n = pose - posi + 1
		i = 0
		while i < n:
			L.pushNumber(s[posi + i - 1])
			i += 1
		return n

	byteFunction = staticmethod(byteFunction)

	def charFunction(L):
		""" <summary>
		 Implements string.char.  Name mangled to avoid keyword. </summary>
		"""
		n = L.Top # number of arguments
		b = StringBuilder()
		i = 1
		while i <= n:
			c = L.checkInt(i)
			L.argCheck(c == c, i, "invalid value")
			b.Append(c)
			i += 1
		L.push(b.ToString())
		return 1

	charFunction = staticmethod(charFunction)

	def dump(L):
		""" <summary>
		 Implements string.dump. </summary>
		"""
		L.checkType(1, Lua.TFUNCTION)
		L.Top = 1
		try:
			s = ByteArrayOutputStream()
			Lua.dump(L.value(1), s)
			a = s.toByteArray()
			s = None
			b = StringBuilder()
			i = 0
			while i < a.getLength():
				b.Append((a.get(i) & 0xff))
				i += 1
			L.pushString(b.ToString())
			return 1
		except IOException, :
			L.error("unabe to dump given function")
		finally:
		# NOTREACHED
		return 0

	dump = staticmethod(dump)

	def findAux(L, isFind):
		""" <summary>
		 Helper for find and match.  Equivalent to str_find_aux. </summary>
		"""
		s = L.checkString(1)
		p = L.checkString(2)
		l1 = s.Length
		l2 = p.Length
		init = StringLib.posrelat(L.optInt(3, 1), s) - 1
		if init < 0:
			init = 0
		elif init > l1:
			init = l1
		if isFind and (L.toBoolean(L.value(4)) or StringLib.strpbrk(p, MatchState.SPECIALS) < 0): # or no special characters? -  explicit request # do a plain search
			off = StringLib.lmemfind(s.Substring(init), l1 - init, p, l2)
			if off >= 0:
				L.pushNumber(init + off + 1)
				L.pushNumber(init + off + l2)
				return 2
		else:
			ms = MatchState(L, s, l1)
			anchor = p[0] == '^'
			si = init # start # end # else
			while si += 1 < ms.end and not anchor:
				ms.level = 0
				res = ms.match(si, p, 1 if anchor else 0)
				if res >= 0:
					if isFind:
						L.pushNumber(si + 1)
						L.pushNumber(res)
						return ms.push_captures(-1, -1) + 2
					return ms.push_captures(si, res)
		L.pushNil() # not found
		return 1

	findAux = staticmethod(findAux)

	def find(L):
		""" <summary>
		 Implements string.find. </summary>
		"""
		return StringLib.findAux(L, True)

	find = staticmethod(find)

	def gmatch(L):
		""" <summary>
		 Implement string.match.  Operates slightly differently from the
		 PUC-Rio code because instead of storing the iteration state as
		 upvalues of the C closure the iteration state is stored in an
		 Object[3] and kept on the stack.
		 </summary>
		"""
		state = Array.CreateInstance(Object, 3)
		state[0] = L.checkString(1)
		state[1] = L.checkString(2)
		state[2] = System.Nullable[int](0)
		L.push(self._GMATCH_AUX_FUN)
		L.push(state)
		return 2

	gmatch = staticmethod(gmatch)

	def gmatchaux(L):
		""" <summary>
		 Expects the iteration state, an Object[3] (see {@link
		 #gmatch}), to be first on the stack.
		 </summary>
		"""
		state = L.value(1)
		s = state[0]
		p = state[1]
		i = (state[2])
		ms = MatchState(L, s, s.Length)
		while i <= ms.end:
			ms.level = 0
			e = ms.match(i, p, 0)
			if e >= 0:
				newstart = e
				if e == i: # empty match?
					newstart += 1 # go at least one position
				state[2] = System.Nullable[int](newstart)
				return ms.push_captures(i, e)
			i += 1
		return 0

	gmatchaux = staticmethod(gmatchaux)
 # not found.
	def gsub(L):
		""" <summary>
		 Implements string.gsub. </summary>
		"""
		s = L.checkString(1)
		sl = s.Length
		p = L.checkString(2)
		maxn = L.optInt(4, sl + 1)
		anchor = False
		if p.Length > 0:
			anchor = p[0] == '^'
		if anchor:
			p = p.Substring(1)
		ms = MatchState(L, s, sl)
		b = StringBuilder()
		n = 0
		si = 0
		while n < maxn:
			ms.level = 0
			e = ms.match(si, p, 0)
			if e >= 0:
				n += 1
				ms.addvalue(b, si, e)
			if e >= 0 and e > si: # non empty match?
				si = e # skip it
			elif si < ms.end:
				b.Append(s[si += 1])
			else:
				break
			if anchor:
				break
		b.Append(s.Substring(si))
		L.pushString(b.ToString())
		L.pushNumber(n) # number of substitutions
		return 2

	gsub = staticmethod(gsub)

	def addquoted(L, b, arg):
		s = L.checkString(arg)
		l = s.Length
		b.Append('"')
		i = 0
		while i < l:
			if s[i] == '"' or s[i] == '\\' or s[i] == '\n':
				b.Append('\\')
				b.Append(s[i])
			elif s[i] == '\r':
				b.Append("\\r")
			elif s[i] == '\0':
				b.Append("\\x0000")
			else:
				b.Append(s[i])
			i += 1
		b.Append('"')

	addquoted = staticmethod(addquoted)

	def format(L):
		arg = 1
		strfrmt = L.checkString(1)
		sfl = strfrmt.Length
		b = StringBuilder()
		i = 0
		while i < sfl:
			if strfrmt[i] != MatchState.L_ESC:
				b.Append(strfrmt[i += 1])
			elif strfrmt[i += 1] == MatchState.L_ESC:
				b.Append(strfrmt[i += 1])
			else: # format item
				arg += 1
				item = FormatItem(L, strfrmt.Substring(i))
				i += item.length()
				if item.type() == 'c':
					item.formatChar(b, L.checkNumber(arg))
				elif item.type() == 'd' or item.type() == 'i' or item.type() == 'o' or item.type() == 'u' or item.type() == 'x' or item.type() == 'X':
					# :todo: should be unsigned conversions cope better with
					# negative number?
					item.formatInteger(b, L.checkNumber(arg))
				elif item.type() == 'e' or item.type() == 'E' or item.type() == 'f' or item.type() == 'g' or item.type() == 'G':
					item.formatFloat(b, L.checkNumber(arg))
				elif item.type() == 'q':
					StringLib.addquoted(L, b, arg)
				elif item.type() == 's':
					item.formatString(b, L.checkString(arg))
				else:
					return L.error("invalid option to 'format'")
		L.pushString(b.ToString())
		return 1

	format = staticmethod(format)

	def len(L):
		""" <summary>
		 Implements string.len. </summary>
		"""
		s = L.checkString(1)
		L.pushNumber(s.Length)
		return 1

	len = staticmethod(len)

	def lower(L):
		""" <summary>
		 Implements string.lower. </summary>
		"""
		s = L.checkString(1)
		L.push(s.ToLower())
		return 1

	lower = staticmethod(lower)

	def match(L):
		""" <summary>
		 Implements string.match. </summary>
		"""
		return StringLib.findAux(L, False)

	match = staticmethod(match)

	def rep(L):
		""" <summary>
		 Implements string.rep. </summary>
		"""
		s = L.checkString(1)
		n = L.checkInt(2)
		b = StringBuilder()
		i = 0
		while i < n:
			b.Append(s)
			i += 1
		L.push(b.ToString())
		return 1

	rep = staticmethod(rep)

	def reverse(L):
		""" <summary>
		 Implements string.reverse. </summary>
		"""
		s = L.checkString(1)
		b = StringBuilder()
		l = s.Length
		while l -= 1 >= 0:
			b.Append(s[l])
		L.push(b.ToString())
		return 1

	reverse = staticmethod(reverse)

	def posrelat(pos, s):
		""" <summary>
		 Helper for <seealso cref="#sub"/> and friends. </summary>
		"""
		if pos >= 0:
			return pos
		len = s.Length
		return len + pos + 1

	posrelat = staticmethod(posrelat)

	def sub(L):
		""" <summary>
		 Implements string.sub. </summary>
		"""
		s = L.checkString(1)
		start = StringLib.posrelat(L.checkInt(2), s)
		end = StringLib.posrelat(L.optInt(3, -1), s)
		if start < 1:
			start = 1
		if end > s.Length:
			end = s.Length
		if start <= end:
			L.push(s.Substring(start - 1, end - (start - 1)))
		else:
			L.pushLiteral("")
		return 1

	sub = staticmethod(sub)

	def upper(L):
		""" <summary>
		 Implements string.upper. </summary>
		"""
		s = L.checkString(1)
		L.push(s.ToUpper())
		return 1

	upper = staticmethod(upper)

	def lmemfind(s1, l1, s2, l2):
		""" <returns>  character index of start of match (-1 if no match). </returns>"""
		if l2 == 0:
			return 0 # empty strings are everywhere
		elif l2 > l1:
			return -1 # avoids a negative l1
		return s1.IndexOf(s2)

	lmemfind = staticmethod(lmemfind)

	def strpbrk(s, set):
		""" <summary>
		 Just like C's strpbrk. </summary>
		 <returns> an index into <var>s</var> or -1 for no match. </returns>
		"""
		l = set.Length
		i = 0
		while i < l:
			idx = s.IndexOf(set[i])
			if idx >= 0:
				return idx
			i += 1
		return -1

	strpbrk = staticmethod(strpbrk)

class MatchState(object):
	# <summary>
	# The entire string that is the subject of the match. </summary>
	# <summary>
	# The subject's length. </summary>
	# <summary>
	# Total number of captures (finished or unfinished). </summary>
	# <summary>
	# Each capture element is a 2-element array of (index, len). </summary>
	# :todo: consider adding the pattern string as a member (and removing
	# p parameter from methods).
	# :todo: consider removing end parameter, if end always == // src.length()
	def __init__(self, L, src, end):
		self._capture_Renamed = ArrayList()
		# <summary>
		# Returns the length of capture <var>i</var>.
		# </summary>
		# <summary>
		# Returns the init index of capture <var>i</var>.
		# </summary>
		# <summary>
		# Returns the 2-element array for the capture <var>i</var>.
		# </summary> # relies on wraparound.
		# assert pi < p.length() // checked by callers # look for a ']' # skip escapes (e.g. '%]')
		# <param name="c">   char match. </param>
		# <param name="cl">  character class. </param>
		# <param name="pi">  index in p of start of class. </param>
		# <param name="ec">  index in p of end of class. </param>
		# :todo: consider changing char c to int c, then -1 could be used
		# represent a guard value at the beginning and end of all strings (a
		# better NUL).  -1 of course would match no positive class.
		# assert p.charAt(pi) == '[';
		# assert p.charAt(ec) == ']'; # skip the '6' # matches any char
		# Generally all the various match functions from PUC-Rio which take a
		# MatchState and return a "const char *" are transformed into
		# instance methods that take and return string indexes. # string ends out of balance # counts maximum expand for item
		# keeps trying to match with the maximum repetitions # else didn't match; reduce 1 repetition to try again # try with one more repetition # match failed # close it # match failed? # undo capture
		#FIXME:&& src.regionMatches(false, captureInit(l), src, si, len)
		self._L_ESC = '%'
		self._SPECIALS = "^$*+?.([%-"
		self._CAP_UNFINISHED = -1
		self._CAP_POSITION = -2
		self._L = L
		self._src = src
		self._end = end

	def captureLen(self, i):
		c = self._capture_Renamed[i]
		return c[1]

	def captureInit(self, i):
		c = self._capture_Renamed[i]
		return c[0]

	def capture(self, i):
		return self._capture_Renamed[i]

	def capInvalid(self):
		return self._L.error("invalid capture index")

	def malBra(self):
		return self._L.error("malformed pattern (missing '[')")

	def capUnfinished(self):
		return self._L.error("unfinished capture")

	def malEsc(self):
		return self._L.error("malformed pattern (ends with '%')")

	def check_capture(self, l):
		l -= '1'
		if l >= self._level or self.captureLen(l) == self._CAP_UNFINISHED:
			self.capInvalid()
		return l

	def capture_to_close(self):
		lev = self._level
		lev -= 1
		while lev >= 0:
			if self.captureLen(lev) == self._CAP_UNFINISHED:
				return lev
			lev -= 1
		return self.capInvalid()

	def classend(self, p, pi):
		if p[pi += 1] == self._L_ESC:
			return pi + 1
		elif p[pi += 1] == '[':
			if p.Length == pi:
				return self.malBra()
			if p[pi] == '^':
				pi += 1
			while p[pi] != ']':
				if p.Length == pi:
					return self.malBra()
				if p[pi += 1] == self._L_ESC:
					if p.Length == pi:
						return self.malBra()
					pi += 1
					if p.Length == pi:
						return self.malBra()
			return pi + 1
		else:
			return pi

	def match_class(c, cl):
		if Char.ToLower(cl) == 'a':
			res = Syntax.isalpha(c)
		elif Char.ToLower(cl) == 'c':
			res = Syntax.iscntrl(c)
		elif Char.ToLower(cl) == 'd':
			res = Syntax.isdigit(c)
		elif Char.ToLower(cl) == 'l':
			res = Syntax.islower(c)
		elif Char.ToLower(cl) == 'p':
			res = Syntax.ispunct(c)
		elif Char.ToLower(cl) == 's':
			res = Syntax.isspace(c)
		elif Char.ToLower(cl) == 'u':
			res = Syntax.isupper(c)
		elif Char.ToLower(cl) == 'w':
			res = Syntax.isalnum(c)
		elif Char.ToLower(cl) == 'x':
			res = Syntax.isxdigit(c)
		elif Char.ToLower(cl) == 'z':
			res = (c == 0)
		else:
			return (cl == c)
		return res if Char.IsLower(cl) else not res

	match_class = staticmethod(match_class)

	def matchbracketclass(c, p, pi, ec):
		sig = True
		if p[pi + 1] == '^':
			sig = False
			pi += 1
		while pi += 1 < ec:
			if p[pi] == self._L_ESC:
				pi += 1
				if MatchState.match_class(c, p[pi]):
					return sig
			elif (p[pi + 1] == '-') and (pi + 2 < ec):
				pi += 2
				if p[pi - 2] <= c and c <= p[pi]:
					return sig
			elif p[pi] == c:
				return sig
		return not sig

	matchbracketclass = staticmethod(matchbracketclass)

	def singlematch(c, p, pi, ep):
		if p[pi] == '.':
			return True
		elif p[pi] == self._L_ESC:
			return MatchState.match_class(c, p[pi + 1])
		elif p[pi] == '[':
			return MatchState.matchbracketclass(c, p, pi, ep - 1)
		else:
			return p[pi] == c

	singlematch = staticmethod(singlematch)

	def matchbalance(self, si, p, pi):
		if pi + 1 >= p.Length:
			self._L.error("unbalanced pattern")
		if si >= self._end or self._src[si] != p[pi]:
			return -1
		b = p[pi]
		e = p[pi + 1]
		cont = 1
		while si += 1 < self._end:
			if self._src[si] == e:
				if cont -= 1 == 0:
					return si + 1
			elif self._src[si] == b:
				cont += 1
		return -1

	def max_expand(self, si, p, pi, ep):
		i = 0
		while si + i < self._end and self.singlematch(self._src[si + i], p, pi, ep):
			i += 1
		while i >= 0:
			res = self.match(si + i, p, ep + 1)
			if res >= 0:
				return res
			i -= 1
		return -1

	def min_expand(self, si, p, pi, ep):
		while True:
			res = self.match(si, p, ep + 1)
			if res >= 0:
				return res
			elif si < self._end and self.singlematch(self._src[si], p, pi, ep):
				si += 1
			else:
				return -1

	def start_capture(self, si, p, pi, what):
		self._capture_Renamed.Capacity = self._level + 1
		self._capture_Renamed[self._level] = Array[int]((si, what))
		self._level += 1
		res = self.match(si, p, pi)
		if res < 0:
			self._level -= 1
		return res

	def end_capture(self, si, p, pi):
		l = self.capture_to_close()
		self.capture(l)[1] = si - self.captureInit(l)
		res = self.match(si, p, pi)
		if res < 0:
			self.capture(l)[1] = self._CAP_UNFINISHED
		return res

	def match_capture(self, si, l):
		l = self.check_capture(l)
		len = self.captureLen(l)
		if self._end - si >= len:
			return si + len
		return -1

	def match(self, si, p, pi):
		""" <param name="si">  index of subject at which to attempt match. </param>
		 <param name="p">   pattern string. </param>
		 <param name="pi">  index into pattern (from which to being matching). </param>
		 <returns> the index of the end of the match, -1 for no match. </returns>
		"""
		# This code has been considerably changed in the transformation
		# from C to Java.  There are the following non-obvious changes:
		# - The C code routinely relies on NUL being accessible at the end of
		#   the pattern string.  In Java we can't do this, so we use many
		#   more explicit length checks and pull error cases into this
		#   function.  :todo: consider appending NUL to the pattern string.
		# - The C code uses a "goto dflt" which is difficult to transform in
		#   the usual way.
		# optimize tail recursion.
		while True:
			if p.Length == pi: # end of pattern
				return si # match succeeded
			if p[pi] == '(':
				if p.Length == pi + 1:
					return self.capUnfinished()
				if p[pi + 1] == ')': # position capture?
					return self.start_capture(si, p, pi + 2, self._CAP_POSITION)
				return self.start_capture(si, p, pi + 1, self._CAP_UNFINISHED)
			elif p[pi] == ')': # end capture
				return self.end_capture(si, p, pi + 1)
			elif p[pi] == self._L_ESC:
				if p.Length == pi + 1:
					return self.malEsc()
				if p[pi + 1] == 'b': # balanced string?
					si = self.matchbalance(si, p, pi + 2)
					if si < 0:
						return si
					pi += 4
					# else return match(ms, s, p+4); # goto init
				elif p[pi + 1] == 'f': # frontier
					pi += 2
					if p.Length == pi or p[pi] != '[':
						return self._L.error("missing '[' after '%f' in pattern")
					ep = self.classend(p, pi) # indexes what is next
					previous = '\0' if (si == 0) else self._src[si - 1]
					at = '\0' if (si == self._end) else self._src[si]
					if self.matchbracketclass(previous, p, pi, ep - 1) or not self.matchbracketclass(at, p, pi, ep - 1):
						return -1
					pi = ep
					# else return match(ms, s, ep);
				else: # goto init
					if Syntax.isdigit(p[pi + 1]): # capture results (%0-%09)?
						si = self.match_capture(si, p[pi + 1])
						if si < 0:
							return si
						pi += 2
						# else return match(ms, s, p+2); # goto init
				# We emulate a goto dflt by a fallthrough to the next
				# case (of the outer switch) and making sure that the
				# next case has no effect when we fallthrough to it from here.
				# goto dflt; #FIXME:
				# FALLTHROUGH
				#FIXME:
			elif p[pi] == '$':
				if p[pi] == '$':
					if p.Length == pi + 1: # is the '$' the last char in pattern?
						return si if (si == self._end) else -1 # check end of string
				# else goto dflt;
			else: #FIXME:
				# FALLTHROUGH # it is a pattern item
				ep = self.classend(p, pi) # indexes what is next
				m = si < self._end and self.singlematch(self._src[si], p, pi, ep)
				if p.Length > ep:
					if p[ep] == '?': # optional
						if m:
							res = self.match(si + 1, p, ep + 1)
							if res >= 0:
								return res
						pi = ep + 1
						# else return match(s, ep+1); # goto init
					elif p[ep] == '*': # 0 or more repetitions
						return self.max_expand(si, p, pi, ep)
					elif p[ep] == '+': # 1 or more repetitions
						return self.max_expand(si + 1, p, pi, ep) if m else -1
					elif p[ep] == '-': # 0 or more repetitions (minimum)
						return self.min_expand(si, p, pi, ep)
				# else or default:
				if not m:
					return -1
				si += 1
				pi = ep
				# return match(ms, s+1, ep);

	def onecapture(self, i, s, e):
		""" <param name="s">  index of start of match. </param>
		 <param name="e">  index of end of match. </param>
		"""
		if i >= self._level:
			if i == 0: # level == 0, too
				return self._src.Substring(s, e - s)
			else: # add whole match
				self.capInvalid()
		# NOTREACHED;
		l = self.captureLen(i)
		if l == self._CAP_UNFINISHED:
			self.capUnfinished()
		if l == self._CAP_POSITION:
			return Lua.valueOfNumber(self.captureInit(i) + 1)
		return self._src.Substring(self.captureInit(i), l)

	def push_onecapture(self, i, s, e):
		self._L.push(self.onecapture(i, s, e))

	def push_captures(self, s, e):
		""" <param name="s">  index of start of match. </param>
		 <param name="e">  index of end of match. </param>
		"""
		nlevels = 1 if (self._level == 0 and s >= 0) else self._level
		i = 0
		while i < nlevels:
			self.push_onecapture(i, s, e)
			i += 1
		return nlevels
 # number of strings pushed
	def adds(self, b, si, ei):
		""" <summary>
		 A helper for gsub.  Equivalent to add_s from lstrlib.c. </summary>
		"""
		news = self._L.toString(self._L.value(3))
		l = news.Length
		i = 0
		while i < l:
			if news[i] != self._L_ESC:
				b.Append(news[i])
			else:
				i += 1 # skip L_ESC
				if not Syntax.isdigit(news[i]):
					b.Append(news[i])
				elif news[i] == '0':
					b.Append(self._src.Substring(si, ei - si))
				else:
					# add capture to accumulated result
					b.Append(self._L.toString(self.onecapture(news[i] - '1', si, ei)))
			i += 1

	def addvalue(self, b, si, ei):
		""" <summary>
		 A helper for gsub.  Equivalent to add_value from lstrlib.c. </summary>
		"""
		if self._L.type(3) == Lua.TNUMBER or self._L.type(3) == Lua.TSTRING:
			self.adds(b, si, ei)
			return 
		elif self._L.type(3) == Lua.TFUNCTION:
			self._L.pushValue(3)
			n = self.push_captures(si, ei)
			self._L.call(n, 1)
		elif self._L.type(3) == Lua.TTABLE:
			self._L.push(self._L.getTable(self._L.value(3), self.onecapture(0, si, ei)))
		else:
			self._L.argError(3, "string/function/table expected")
			return 
		if not self._L.toBoolean(self._L.value(-1)): # nil or false
			self._L.pop(1)
			self._L.pushString(self._src.Substring(si, ei - si))
		elif not self._L.isString(self._L.value(-1)):
			self._L.error("invalid replacement value (a " + Lua.typeName(self._L.type(-1)) + ")")
		b.Append(self._L.toString(self._L.value(-1))) # add result to accumulator
		self._L.pop(1)

class FormatItem(object): # '-' flag # '+' flag # ' ' flag # '#' flag # '0' flag # minimum field width # precision, -1 when no precision specified. # the type of the conversion # length of the format item in the format string.
	# <summary>
	# Character used in formatted output when %e or %g format is used.
	# </summary>
	# <summary>
	# Character used in formatted output when %E or %G format is used.
	# </summary>
	def __init__(self, L, s):
		""" <summary>
		 Parse a format item (starting from after the <code>L_ESC</code>).
		 If you promise that there won't be any format errors, then
		 <var>L</var> can be <code>null</code>.
		 </summary>
		"""
		self._precision = -1
		self._E_LOWER = 'E'
		self._E_UPPER = 'E'
		self._L = L
		i = 0
		l = s.Length
		# parse flags
		while True:
			if i >= l:
				L.error("invalid format")
			if s[i] == '-':
				self._left = True
			elif s[i] == '+':
				self._sign = True
			elif s[i] == ' ':
				self._space = True
			elif s[i] == '#':
				self._alt = True
			elif s[i] == '0':
				self._zero = True
			else:
			i += 1 # flag
		# parse width
		widths = i # index of start of width specifier
		while True:
			if i >= l:
				L.error("invalid format")
			if Syntax.isdigit(s[i]):
				i += 1
			else:
				break
		if widths < i:
			try:
				self._width = Convert.ToInt32(s.Substring(widths, i - widths))
			except NumberFormatException, :
			finally:
		# parse precision
		if s[i] == '.':
			i += 1
			precisions = i # index of start of precision specifier
			while True:
				if i >= l:
					L.error("invalid format")
				if Syntax.isdigit(s[i]):
					i += 1
				else:
					break
			if precisions < i:
				try:
					self._precision = Convert.ToInt32(s.Substring(precisions, i - precisions))
				except NumberFormatException, :
				finally:
		if s[i] == 'c' or s[i] == 'd' or s[i] == 'i' or s[i] == 'o' or s[i] == 'u' or s[i] == 'x' or s[i] == 'X' or s[i] == 'e' or s[i] == 'E' or s[i] == 'f' or s[i] == 'g' or s[i] == 'G' or s[i] == 'q' or s[i] == 's':
			self._type_Renamed = s[i]
			self._length_Renamed = i + 1
			return 
		L.error("invalid option to 'format'")

	def length(self):
		return self._length_Renamed

	def type(self):
		return self._type_Renamed

	def format(self, b, s):
		""" <summary>
		 Format the converted string according to width, and left.
		 zero padding is handled in either <seealso cref="FormatItem#formatInteger"/>
		 or <seealso cref="FormatItem#formatFloat"/>
		 (and width is fixed to 0 in such cases).  Therefore we can ignore
		 zero.
		 </summary>
		"""
		l = s.Length
		if l >= self._width:
			b.Append(s)
			return 
		pad = StringBuilder()
		while l < self._width:
			pad.Append(' ')
			l += 1
		if self._left:
			b.Append(s)
			b.Append(pad)
		else:
			b.Append(pad)
			b.Append(s)

	# All the format* methods take a StringBuffer and append the
	# formatted representation of the value to it.
	# Sadly after a format* method has been invoked the object is left in
	# an unusable state and should not be used again.
	def formatChar(self, b, c):
		s = Convert.ToString(c)
		self.format(b, s)

	def formatInteger(self, b, i):
		# :todo: improve inefficient use of implicit StringBuffer
		if self._left:
			self._zero = False
		if self._precision >= 0:
			self._zero = False
		radix = 10
		if self._type_Renamed == 'o':
			radix = 8
		elif self._type_Renamed == 'd' or self._type_Renamed == 'i' or self._type_Renamed == 'u':
			radix = 10
		elif self._type_Renamed == 'x' or self._type_Renamed == 'X':
			radix = 16
		else:
			self._L.error("invalid format")
		s = Convert.ToString(i, radix)
		if self._type_Renamed == 'X':
			s = s.ToUpper()
		if self._precision == 0 and s.Equals("0"):
			s = ""
		# form a prefix by strippping possible leading '-',
		# pad to precision,
		# add prefix,
		# pad to width.
		# extra wart: padding with '0' is implemented using precision
		# because this makes handling the prefix easier.
		prefix = ""
		if s.StartsWith("-"):
			prefix = "-"
			s = s.Substring(1)
		if self._alt and radix == 16:
			prefix = "0x"
		if prefix == "":
			if self._sign:
				prefix = "+"
			elif self._space:
				prefix = " "
		if self._alt and radix == 8 and not s.StartsWith("0"):
			s = "0" + s
		l = s.Length
		if self._zero:
			self._precision = self._width - prefix.Length
			self._width = 0
		if l < self._precision:
			p = StringBuilder()
			while l < self._precision:
				p.Append('0')
				l += 1
			p.Append(s)
			s = p.ToString()
		s = prefix + s
		self.format(b, s)

	def formatFloat(self, b, d):
		if self._type_Renamed == 'g' or self._type_Renamed == 'G':
			self.formatFloatG(b, d)
			return 
		elif self._type_Renamed == 'f':
			self.formatFloatF(b, d)
			return 
		elif self._type_Renamed == 'e' or self._type_Renamed == 'E':
			self.formatFloatE(b, d)
			return 

	def formatFloatE(self, b, d):
		s = self.formatFloatRawE(d)
		self.format(b, s)

	def formatFloatRawE(self, d):
		""" <summary>
		 Returns the formatted string for the number without any padding
		 (which can be added by invoking <seealso cref="FormatItem#format"/> later).
		 </summary>
		"""
		m = Math.Abs(d)
		offset = 0
		if m >= 1e-3 and m < 1e7:
			d *= 1e10
			offset = 10
		s = Convert.ToString(d)
		t = StringBuilder(s) # Exponent value
		if d == 0:
			e = 0
		else:
			ei = s.IndexOf('E')
			e = Convert.ToInt32(s.Substring(ei + 1))
			t.Remove(ei, int.MaxValue)
		self.precisionTrim(t)
		e -= offset
		if Char.IsLower(self._type_Renamed):
			t.Append(self._E_LOWER)
		else:
			t.Append(self._E_UPPER)
		if e >= 0:
			t.Append('+')
		t.Append(Convert.ToString(e))
		self.zeroPad(t)
		return t.ToString()

	def formatFloatF(self, b, d):
		s = self.formatFloatRawF(d)
		self.format(b, s)

	def formatFloatRawF(self, d):
		""" <summary>
		 Returns the formatted string for the number without any padding
		 (which can be added by invoking <seealso cref="FormatItem#format"/> later).
		 </summary>
		"""
		s = Convert.ToString(d)
		t = StringBuilder(s)
		di = s.IndexOf('.')
		ei = s.IndexOf('E')
		if ei >= 0:
			t.Remove(ei, int.MaxValue)
			e = Convert.ToInt32(s.Substring(ei + 1))
			z = StringBuilder()
			i = 0
			while i < Math.Abs(e):
				z.Append('0')
				i += 1
			if e > 0:
				t.Remove(di, 1)
				t.Append(z)
				t.Insert(di + e, '.')
			else:
				t.Remove(di, 1)
				at = 1 if t[0] == '-' else 0
				t.Insert(at, z)
				t.Insert(di, '.')
		self.precisionTrim(t)
		self.zeroPad(t)
		return t.ToString()

	def formatFloatG(self, b, d):
		if self._precision == 0:
			self._precision = 1
		if self._precision < 0:
			self._precision = 6
		# Decide whether to use %e or %f style.
		m = Math.Abs(d)
		if m == 0:
			# :todo: Could test for -0 and use "-0" appropriately.
			s = "0"
		elif m < 1e-4 or m >= Lua.iNumpow(10, self._precision):
			# %e style
			self._precision -= 1
			s = self.formatFloatRawE(d)
			di = s.IndexOf('.')
			if di >= 0:
				# Trim trailing zeroes from fractional part
				ei = s.IndexOf('E')
				if ei < 0:
					ei = s.IndexOf('e')
				i = ei - 1
				while s[i] == '0':
					i -= 1
				if s[i] != '.':
					i += 1
				a = StringBuilder(s)
				a.Remove(i, ei)
				s = a.ToString()
		else:
			# %f style
			# For %g precision specifies the number of significant digits,
			# for %f precision specifies the number of fractional digits.
			# There is a problem because it's not obvious how many fractional
			# digits to format, it could be more than precision
			# (when .0001 <= m < 1) or it could be less than precision
			# (when m >= 1).
			# Instead of trying to work out the correct precision to use for
			# %f formatting we use a worse case to get at least all the
			# necessary digits, then we trim using string editing.  The worst
			# case is that 3 zeroes come after the decimal point before there
			# are any significant digits.
			# Save the required number of significant digits
			required = self._precision
			self._precision += 3
			s = self.formatFloatRawF(d)
			fsd = 0 # First Significant Digit
			while s[fsd] == '0' or s[fsd] == '.':
				fsd += 1
			# Note that all the digits to the left of the decimal point in
			# the formatted number are required digits (either significant
			# when m >= 1 or 0 when m < 1).  We know this because otherwise 
			# m >= (10**precision) and so formatting falls under the %e case.
			# That means that we can always trim the string at fsd+required
			# (this will remove the decimal point when m >=
			# (10**(precision-1)).
			a = StringBuilder(s)
			a.Remove(fsd + required, int.MaxValue)
			if s.IndexOf('.') < a.Length:
				# Trim trailing zeroes
				i = a.Length - 1
				while a[i] == '0':
					a.Remove(i, 1)
					i -= 1
				if a[i] == '.':
					a.Remove(i, 1)
			s = a.ToString()
		self.format(b, s)

	def formatString(self, b, s):
		p = s
		if self._precision >= 0 and self._precision < s.Length:
			p = s.Substring(0, self._precision)
		self.format(b, p)

	def precisionTrim(self, t):
		if self._precision < 0:
			self._precision = 6
		s = t.ToString()
		di = s.IndexOf('.')
		l = t.Length
		if 0 == self._precision:
			t.Remove(di, int.MaxValue)
		elif l > di + self._precision:
			t.Remove(di + self._precision + 1, int.MaxValue)
		else:
			while l <= di + self._precision:
				t.Append('0')
				l += 1

	def zeroPad(self, t):
		if self._zero and t.Length < self._width:
			at = 1 if t[0] == '-' else 0
			while t.Length < self._width:
				t.Insert(at, '0')