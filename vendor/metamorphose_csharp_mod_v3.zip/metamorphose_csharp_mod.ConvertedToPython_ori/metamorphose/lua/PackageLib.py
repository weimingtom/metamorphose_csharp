﻿from System.Text import *
from metamorphose.java import *
# $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/PackageLib.java#1 $
# * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
# * All rights reserved.
# *
# * Permission is hereby granted, free of charge, to any person obtaining
# * a copy of this software and associated documentation files (the
# * "Software"), to deal in the Software without restriction, including
# * without limitation the rights to use, copy, modify, merge, publish,
# * distribute, sublicense, and/or sell copies of the Software, and to
# * permit persons to whom the Software is furnished to do so, subject
# * to the following conditions:
# *
# * The above copyright notice and this permission notice shall be
# * included in all copies or substantial portions of the Software.
# *
# * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
# * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# 
class PackageLib(LuaJavaCallback):
	""" <summary>
	 Contains Lua's package library.
	 The library
	 can be opened using the <seealso cref="#open"/> method.
	 </summary>
	"""
	# Each function in the library corresponds to an instance of
	# this class which is associated (the 'which' member) with an integer
	# which is unique within this class.  They are taken from the following
	# set.
	# <summary>
	# Which library function this object represents.  This value should
	# be one of the "enums" defined in the class.
	# </summary>
	# <summary>
	# Module Environment; a reference to the package table so that
	# package functions can access it without using the global table.
	# In PUC-Rio this reference is stored in the function's environment.
	# Not all instances (Lua Java functions) require this member, but
	# another subclass would be too wasteful.
	# </summary>
	def __init__(self, which, me):
		""" <summary>
		 Constructs instance, filling in the 'which' member. </summary>
		"""
		self._MODULE = 1
		self._REQUIRE = 2
		self._SEEALL = 3
		self._LOADER_PRELOAD = 4
		self._LOADER_LUA = 5
		# <summary>
		# Implements all of the functions in the Lua package library.  Do not
		# call directly. </summary>
		# <param name="L">  the Lua state in which to execute. </param>
		# <returns> number of returned parameters, as per convention. </returns>
		# <summary>
		# Opens the library into the given Lua state.  This registers
		# the symbols of the library in the global table. </summary>
		# <param name="L">  The Lua state into which to open. </param> # set field 'path'
		# set field 'loaded'
		# <summary>
		# Register a function. </summary>
		# <summary>
		# Register a function in the global table. </summary>
		# <summary>
		# Register a loader in package.loaders. </summary>
		self._DIRSEP = "/"
		self._PATHSEP = ';'
		self._PATH_MARK = "?"
		self._PATH_DEFAULT = "?.lua;?/init.lua"
		self._SENTINEL = System.Object()
		self._which = which
		self._me = me

	def __init__(self, which, me):
		self._MODULE = 1
		self._REQUIRE = 2
		self._SEEALL = 3
		self._LOADER_PRELOAD = 4
		self._LOADER_LUA = 5
		self._DIRSEP = "/"
		self._PATHSEP = ';'
		self._PATH_MARK = "?"
		self._PATH_DEFAULT = "?.lua;?/init.lua"
		self._SENTINEL = System.Object()
		self._which = which
		self._me = me

	def luaFunction(self, L):
		if self._which == self._MODULE:
			return self.module(L)
		elif self._which == self._REQUIRE:
			return self.require(L)
		elif self._which == self._SEEALL:
			return self.seeall(L)
		elif self._which == self._LOADER_LUA:
			return self.loaderLua(L)
		elif self._which == self._LOADER_PRELOAD:
			return self.loaderPreload(L)
		return 0

	def open(L):
		t = L.register("package")
		PackageLib.g(L, t, "module", self._MODULE)
		PackageLib.g(L, t, "require", self._REQUIRE)
		PackageLib.r(L, "seeall", self._SEEALL)
		L.setField(t, "loaders", L.newTable())
		PackageLib.p(L, t, self._LOADER_PRELOAD)
		PackageLib.p(L, t, self._LOADER_LUA)
		PackageLib.setpath(L, t, "path", self._PATH_DEFAULT)
		L.findTable(L.Registry, Lua.LOADED, 1)
		L.setField(t, "loaded", L.value(-1))
		L.pop(1)
		L.setField(t, "preload", L.newTable())

	open = staticmethod(open)

	def r(L, name, which):
		f = PackageLib(which)
		L.setField(L.getGlobal("package"), name, f)

	r = staticmethod(r)

	def g(L, t, name, which):
		f = PackageLib(which, t)
		L.setGlobal(name, f)

	g = staticmethod(g)

	def p(L, t, which):
		f = PackageLib(which, t)
		loaders = L.getField(t, "loaders")
		L.rawSetI(loaders, L.objLen(loaders) + 1, f)

	p = staticmethod(p)

	def loaderPreload(self, L):
		""" <summary>
		 Implements the preload loader.  This is conventionally stored
		 first in the package.loaders table.
		 </summary>
		"""
		name = L.checkString(1)
		preload = L.getField(self._me, "preload")
		if not L.isTable(preload):
			L.error("'package.preload' must be a table")
		loader = L.getField(preload, name)
		if L.isNil(loader): # not found?
			L.pushString("\n\tno field package.preload['" + name + "']")
		L.push(loader)
		return 1

	def loaderLua(self, L):
		""" <summary>
		 Implements the lua loader.  This is conventionally stored second in
		 the package.loaders table.
		 </summary>
		"""
		name = L.checkString(1)
		filename = self.findfile(L, name, "path")
		if filename == None:
			return 1 # library not found in this path
		if L.loadFile(filename) != 0:
			self.loaderror(L, filename)
		return 1
 # library loaded successfully
	def module(self, L):
		""" <summary>
		 Implements module. </summary>
		"""
		modname = L.checkString(1)
		loaded = L.getField(self._me, "loaded")
		module = L.getField(loaded, modname)
		if not L.isTable(module): # not found?
			# try global variable (and create one if it does not exist)
			if L.findTable(L.Globals, modname, 1) != None:
				return L.error("name conflict for module '" + modname + "'")
			module = L.value(-1)
			L.pop(1)
			# package.loaded = new table
			L.setField(loaded, modname, module)
		# check whether table already has a _NAME field
		if L.isNil(L.getField(module, "_NAME")):
			self.modinit(L, module, modname)
		self.setfenv(L, module)
		self.dooptions(L, module, L.Top)
		return 0

	def require(self, L):
		""" <summary>
		 Implements require. </summary>
		"""
		name = L.checkString(1)
		L.Top = 1
		# PUC-Rio's use of lua_getfield(L, LUA_REGISTRYINDEX, "_LOADED");
		# (package.loaded is kept in the registry in PUC-Rio) is translated
		# into this:
		loaded = L.getField(self._me, "loaded")
		module = L.getField(loaded, name)
		if L.toBoolean(module): # is it there?
			if module == self._SENTINEL: # check loops
				L.error("loop or previous error loading module '" + name + "'")
			L.push(module)
			return 1
		# else must load it; iterate over available loaders.
		loaders = L.getField(self._me, "loaders")
		if not L.isTable(loaders):
			L.error("'package.loaders' must be a table")
		L.pushString("") # error message accumulator
		i = 1
		while :
			loader = L.rawGetI(loaders, i) # get a loader
			if L.isNil(loader):
				L.error("module '" + name + "' not found:" + L.toString(L.value(-1)))
			L.push(loader)
			L.pushString(name)
			L.call(1, 1) # call it
			if L.isFunction(L.value(-1)): # did it find module?
				break # module loaded successfully
			elif L.isString(L.value(-1)): # loader returned error message?
				L.concat(2)
			else: # accumulate it
				L.pop(1)
			i += 1
		L.setField(loaded, name, self._SENTINEL) # package.loaded[name] = sentinel
		L.pushString(name) # pass name as argument to module
		L.call(1, 1) # run loaded module
		if not L.isNil(L.value(-1)): # non-nil return?
			# package.loaded[name] = returned value
			L.setField(loaded, name, L.value(-1))
		module = L.getField(loaded, name)
		if module == self._SENTINEL: # module did not set a value?
			module = Lua.valueOfBoolean(True) # use true as result
			L.setField(loaded, name, module) # package.loaded[name] = true
		L.push(module)
		return 1

	def seeall(L):
		""" <summary>
		 Implements package.seeall. </summary>
		"""
		L.checkType(1, Lua.TTABLE)
		mt = L.getMetatable(L.value(1))
		if mt == None:
			mt = L.createTable(0, 1)
			L.setMetatable(L.value(1), mt)
		L.setField(mt, "__index", L.Globals)
		return 0

	seeall = staticmethod(seeall)

	def setfenv(L, module):
		""" <summary>
		 Helper for module.  <var>module</var> parameter replaces PUC-Rio
		 use of passing it on the stack.
		 </summary>
		"""
		ar = L.getStack(1)
		L.getInfo("f", ar)
		L.setFenv(L.value(-1), module)
		L.pop(1)

	setfenv = staticmethod(setfenv)

	def dooptions(L, module, n):
		""" <summary>
		 Helper for module.  <var>module</var> parameter replaces PUC-Rio
		 use of passing it on the stack.
		 </summary>
		"""
		i = 2
		while i <= n:
			L.pushValue(i) # get option (a function)
			L.push(module)
			L.call(1, 0)
			i += 1

	dooptions = staticmethod(dooptions)

	def modinit(L, module, modname):
		""" <summary>
		 Helper for module.  <var>module</var> parameter replaces PUC-Rio
		 use of passing it on the stack.
		 </summary>
		"""
		L.setField(module, "_M", module) # module._M = module
		L.setField(module, "_NAME", modname)
		dot = modname.LastIndexOf('.') # look for last dot in module name
		# Surprisingly, ++dot works when '.' was found and when it wasn't.
		dot += 1
		# set _PACKAGE as package name (full module name minus last part)
		L.setField(module, "_PACKAGE", modname.Substring(0, dot))

	modinit = staticmethod(modinit)

	def loaderror(L, filename):
		L.error("error loading module '" + L.toString(L.value(1)) + "' from file '" + filename + "':\n\t" + L.toString(L.value(-1)))

	loaderror = staticmethod(loaderror)

	def readable(filename):
		f = SystemUtil.getResourceAsStream(filename)
		if f == None:
			return False
		try:
			f.close()
		except IOException, :
		finally:
		return True

	readable = staticmethod(readable)

	def pushnexttemplate(L, path):
		i = 0
		# skip seperators
		while i < path.Length and path[i] == self._PATHSEP:
			i += 1
		if i == path.Length:
			return None # no more templates
		l = path.IndexOf(self._PATHSEP, i)
		if l < 0:
			l = path.Length
		L.pushString(path.Substring(i, l - i)) # template
		return path.Substring(l)

	pushnexttemplate = staticmethod(pushnexttemplate)

	def findfile(self, L, name, pname):
		name = self.gsub(name, ".", self._DIRSEP)
		path = L.toString(L.getField(self._me, pname))
		if path == None:
			L.error("'package." + pname + "' must be a string")
		L.pushString("") # error accumulator
		while True:
			path = self.pushnexttemplate(L, path)
			if path == None:
				break
			filename = self.gsub(L.toString(L.value(-1)), self._PATH_MARK, name)
			if self.readable(filename): # does file exist and is readable?
				return filename # return that file name
			L.pop(1) # remove path template
			L.pushString("\n\tno file '" + filename + "'")
			L.concat(2)
		return None
 # not found
	def gsub(s, p, r):
		""" <summary>
		 Almost equivalent to luaL_gsub. </summary>
		"""
		b = StringBuilder()
		# instead of incrementing the char *s, we use the index i
		i = 0
		l = p.Length
		while True:
			wild = s.IndexOf(p, i)
			if wild < 0:
				break
			b.Append(s.Substring(i, wild - i)) # add prefix
			b.Append(r) # add replacement in place of pattern
			i = wild + l # continue after 'p'
		b.Append(s.Substring(i))
		return b.ToString()

	gsub = staticmethod(gsub)

	def setpath(L, t, fieldname, def):
		# :todo: consider implementing a user-specified path via
		# javax.microedition.midlet.MIDlet.getAppProperty or similar.
		# Currently we just use a default path defined by Jill.
		L.setField(t, fieldname, def)

	setpath = staticmethod(setpath)