﻿from System import *
from System.Collections.Generic import *
from System.Text import *

class HashtableEnum(Enumeration):
	def __init__(self):

	def hasMoreElements(self):
		return self.__idx < self.__len

	def nextElement(self):
		return self.__arr[self.__idx += 1]

	#注意：仅暴露给Hashtable使用的方法
	def setArr(self, arr):
		if arr != None:
			self.__arr = arr
			self.__idx = 0
			self.__len = self.__arr.Length