﻿from System import *
from System.Collections.Generic import *
from System.Text import *
from metamorphose.java import *
from System.Diagnostics import *

class PrintStream(object):
	#TODO:
	def print(self, str):
		Debug.WriteLine(str)

	#TODO:
	def println(self):
		Debug.WriteLine("\n")

	#TODO
	def print(self, str):
		Debug.WriteLine(str.ToString())