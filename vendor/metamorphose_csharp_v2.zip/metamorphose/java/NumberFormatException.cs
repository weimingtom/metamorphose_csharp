﻿using System;
using System.Collections.Generic;
using System.Text;

namespace metamorphose.java
{
    public class NumberFormatException : Exception
    {
        public NumberFormatException(String str)
        : base(str)
        {
            
        }
    }
}
