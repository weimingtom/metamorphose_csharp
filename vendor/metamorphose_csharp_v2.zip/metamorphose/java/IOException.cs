﻿using System;
using System.Collections.Generic;
using System.Text;

namespace metamorphose.java
{
    public class IOException : Exception
    {
        public IOException()
        {

        }

        public IOException(String str)
        : base(str)
        {
            
        }
    }
}
